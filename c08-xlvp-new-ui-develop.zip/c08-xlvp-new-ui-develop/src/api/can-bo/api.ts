import { iamHttp } from '/@/utils/http/axios';

import { IamEndPoint } from '../apiConst';
import { BaseApi } from '../baseApi';
import { BasePagination } from '../types';
import { ICanBoDto } from './dto';
import { ICanBo, ISearchListCanBoQueryParams } from './model';

export class CanBoApi extends BaseApi<ICanBo> {
  constructor() {
    super(iamHttp, IamEndPoint.CanBo);
  }

  async getAll(params?: ISearchListCanBoQueryParams): Promise<BasePagination<ICanBo>> {
    const res = await this.http.get<{ result: ICanBoDto[]; totalElements: number }>({
      url: this.url,
      params: {
        status: 1,
        ...params,
      },
    });
    return {
      items: res.result?.map((item) => this.fromDto(item)),
      total: res.totalElements,
    };
  }

  fromDto(dto: ICanBoDto): ICanBo {
    return {
      ten: dto.fullname,
      donVi: dto.orgCode,
      ma: dto.username,
      soHieu: dto.idCard,
      maCapBac: dto.depCode,
      maChucVu: dto.posCode,
    };
  }
}
