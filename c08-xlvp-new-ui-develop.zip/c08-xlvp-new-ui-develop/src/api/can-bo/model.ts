import { BaseInfo } from '../types';

export interface ICanBo extends BaseInfo {
  ten: string;
  ma: string;
  donVi: string;
  maCapBac?: string;
  maChucVu?: string;
  capBac?: string;
  chucVu?: string;
  soHieu?: string;
  email?: string;
  tenDonVi?: string;
}

export interface ISearchListCanBoQueryParams {
  status?: number;
  orgCode?: string;
  isThamQuyenRaQuyetDinh?: number;
  page?: number;
  size?: number;
}
