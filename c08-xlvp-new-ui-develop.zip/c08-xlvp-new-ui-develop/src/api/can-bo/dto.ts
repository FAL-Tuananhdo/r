import { BaseInfo } from '../types';

export interface ICanBoDto extends BaseInfo {
  fullname: string;
  orgCode: string;
  username: string;
  posCode: string; //Chuc vu
  depCode: string; //Cap bac
  idCard?: string;
}

export interface ICanBoPagination {
  result: ICanBoDto[];
  total: number;
}
