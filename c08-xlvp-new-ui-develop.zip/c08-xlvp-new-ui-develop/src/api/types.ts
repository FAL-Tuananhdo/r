interface ICanBo {
  ten: string;
  userName: string;
  capBac?: string;
  donVi?: string;
  email?: string;
}

export interface BasicPageParams {
  page: number;
  pageSize: number;
}

export interface BaseInfo {
  ngaySua?: Date;
  ngayTao?: Date;
  nguoiSua?: string;
  nguoiTao?: string;
  canBoTao?: ICanBo;
  canBoSua?: ICanBo;
}

export interface IBaseSearchListQueryParams {
  timKiemNhanh?: string;
  page?: number;
  pageSize?: number;
  isFetchAll?: boolean;
}

export interface BasePagination<T> {
  items: T[];
  total: number;
}

declare global {
  type PartialSearchListQueryParams<T> = Omit<Partial<T>, keyof BaseInfo> &
    Partial<IBaseSearchListQueryParams>;
}
