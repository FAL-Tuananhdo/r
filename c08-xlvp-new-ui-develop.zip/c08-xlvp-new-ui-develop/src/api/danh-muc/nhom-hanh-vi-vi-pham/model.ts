import { ILinhVuc } from '/@/const';

import { BaseInfo } from '../../types';
import { IDanhMucHanhViViPham } from '../hanh-vi-vi-pham/model';

export interface INhomHanhViViPham extends BaseInfo {
  ma: string;
  ten: string;
  trangThai: boolean;
  hanhViViPham: IDanhMucHanhViViPham;
  linhVuc: ILinhVuc;
}

export type ISearchNhomHanhViViPham = PartialSearchListQueryParams<
  Pick<INhomHanhViViPham, 'ma' | 'ten' | 'trangThai'>
>;

export type IViewNhomHanhViViPham = PartialSearchListQueryParams<
  Pick<IDanhMucHanhViViPham, 'kyHieuThongTuNghiDinh' | 'ma' | 'noiDungHanhViViPham'>
>;
