import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { INhomHanhViViPham, ISearchNhomHanhViViPham } from './model';

export class NhomHanhViViPhamApi extends BaseApi<INhomHanhViViPham> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.NhomHanhViViPham);
  }

  exportExcel = async (params: ISearchNhomHanhViViPham): Promise<void> => {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  };
}
