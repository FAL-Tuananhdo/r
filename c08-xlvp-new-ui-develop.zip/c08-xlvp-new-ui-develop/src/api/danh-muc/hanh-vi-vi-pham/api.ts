import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IDanhMucHanhViViPham, ISearchHanhViViPham } from './model';

export class HanhViViPhamApi extends BaseApi<IDanhMucHanhViViPham> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.HanhViViPham);
  }
  async exportExcel(params: ISearchHanhViViPham): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
