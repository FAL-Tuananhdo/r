import { BaseInfo } from '../../types';

export interface IDanhMucHanhViViPham extends BaseInfo {
  ma: string;
  kyHieuThongTuNghiDinh: string;
  maVanBanPhapLuat: string;
  noiDungHanhViViPham: string;
  noiDungVanBanPhapLuat: string;
  maNhomHanhViViPham?: string;
  soTienPhatCaNhanNhoNhat?: number;
  soTienPhatCaNhanLonNhat?: number;
  soTienPhatCaNhanMacDinh?: number;
  soTienPhatToChucNhoNhat?: number;
  soTienPhatToChucLonNhat?: number;
  soTienPhatToChucMacDinh?: number;
  vanBanPhapLuat?: {
    ngayHieuLuc?: Date;
    ngayHetHieuLuc?: Date;
  };
  dieu?: string;
  khoan?: string;
  diem?: string;
}

export type ISearchHanhViViPham = PartialSearchListQueryParams<
  Pick<
    IDanhMucHanhViViPham,
    | 'ma'
    | 'kyHieuThongTuNghiDinh'
    | 'maVanBanPhapLuat'
    | 'noiDungHanhViViPham'
    | 'maNhomHanhViViPham'
  >
>;

export type IRequestBodyHVVP = Pick<
  IDanhMucHanhViViPham,
  | 'kyHieuThongTuNghiDinh'
  | 'maVanBanPhapLuat'
  | 'maNhomHanhViViPham'
  | 'soTienPhatCaNhanNhoNhat'
  | 'soTienPhatCaNhanLonNhat'
  | 'soTienPhatCaNhanMacDinh'
  | 'soTienPhatToChucNhoNhat'
  | 'soTienPhatToChucLonNhat'
  | 'soTienPhatToChucMacDinh'
> & {
  noiDung: string;
  ngayHieuLuc?: Date;
  ngayHetHieuLuc?: Date;
};

export type IRequestUpdateBodyHVVP = Omit<IRequestBodyHVVP, 'ngayHieuLuc' | 'ngayHetHieuLuc'>;
