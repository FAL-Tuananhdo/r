import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IMauBbQd, ISearchMauBbQd } from './model';

export class MauBienBanQuyetDinhApi extends BaseApi<IMauBbQd> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.MauBbQd);
  }

  async getBbQdLienQuan(ma: string): Promise<IMauBbQd[]> {
    return xlvpHttp.get<IMauBbQd[]>({
      url: `${this.url}/${ma}/bb-qd-lien-quan`,
    });
  }

  async exportExcel(params: ISearchMauBbQd): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
