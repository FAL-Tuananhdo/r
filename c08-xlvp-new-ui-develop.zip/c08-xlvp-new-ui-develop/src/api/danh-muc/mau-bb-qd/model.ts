import { ILoaiBieuMau } from '/@/const/type';
import { BaseInfo } from '../../types';

export type ISearchMauBbQd = Omit<
  PartialSearchListQueryParams<IMauBbQd>,
  'ma' | 'maCon' | 'maCha' | 'kyHieuTTND'
>;

export interface IMauBbQd extends BaseInfo {
  ma: string;
  maTTND: string;
  ten: string;
  maBBQD: string;
  loai: ILoaiBieuMau;
  ngayHieuLuc: Date;
  kyHieu: string;
  trangThai: boolean;
  isChuKySo: boolean;
  isLapTuVuViec: boolean;
  isLapLai: boolean;
  kyHieuTTND?: string;
  maCon?: string[];
  maCha?: string[];
  ngayHetHieuLuc?: Date;
}

export type ICreateRequestBody = Pick<
  IMauBbQd,
  | 'ten'
  | 'maBBQD'
  | 'loai'
  | 'kyHieu'
  | 'isLapTuVuViec'
  | 'isChuKySo'
  | 'isLapLai'
  | 'maCha'
  | 'trangThai'
  | 'maTTND'
>;

export type IUpdateRequestBody = Omit<ICreateRequestBody, 'maTTND' | 'maBBQD' | 'loai'>;
