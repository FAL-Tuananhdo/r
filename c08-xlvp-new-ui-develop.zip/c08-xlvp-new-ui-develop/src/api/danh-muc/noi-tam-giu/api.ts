import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IDanhMucNoiTamGiu } from './model';

export class NoiTamGiuApi extends BaseApi<IDanhMucNoiTamGiu> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.NoiTamGiu);
  }
}
