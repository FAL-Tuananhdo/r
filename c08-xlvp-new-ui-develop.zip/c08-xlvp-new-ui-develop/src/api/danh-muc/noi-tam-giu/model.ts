import { BaseInfo } from '../../types';

export interface IDanhMucNoiTamGiu extends BaseInfo {
  ma: string;
  maDonViCsgt: string;
  ten: string;
  diaChi: string;
  maTinhThanh: string;
  maQuanHuyen?: string;
  maPhuongXa?: string;
  soDienThoai?: string;
  trangThai?: boolean;
  ghiChu?: string;
}

export type ISearchNoiTamGiu = PartialSearchListQueryParams<
  Pick<IDanhMucNoiTamGiu, 'ten' | 'maDonViCsgt'>
>;
