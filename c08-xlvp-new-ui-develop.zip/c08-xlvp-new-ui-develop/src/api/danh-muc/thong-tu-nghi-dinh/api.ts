import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { ISearchThongTuNghiDinh, IThongTuNghiDinh } from './model';

export class ThongTuNghiDinhApi extends BaseApi<IThongTuNghiDinh> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.ThongTuNghiDinh);
  }

  exportExcelThongTuNghiDinh = async (params: ISearchThongTuNghiDinh): Promise<void> => {
    xlvpHttp.downloadFile({
      url: `${DanhMucXlvpEndPoint.ThongTuNghiDinh}/export/excel`,
      params: params,
    });
  };
}
