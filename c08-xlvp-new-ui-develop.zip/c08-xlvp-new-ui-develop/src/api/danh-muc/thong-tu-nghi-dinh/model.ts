import { IHinhThucBoSung, ILinhVuc } from '/@/const/type';

import { BaseInfo } from '../../types';

export interface IThongTuNghiDinhBoSung {
  kyHieu: string;
  canCu: string;
}

export interface IThongTuNghiDinh extends BaseInfo {
  kyHieu: string;
  ma: string;
  ngayCoHieuLuc: Date;
  so?: string;
  ngayHetHieuLuc?: Date;
  noiDung?: string;
  ngayBanHanh: Date;
  ttndBoSung?: IThongTuNghiDinhBoSung[];
  hinhThucBoSung: IHinhThucBoSung;
  linhVuc?: ILinhVuc;
}

export type IRequestCreateThongTuNghiDinh = Pick<
  IThongTuNghiDinh,
  | 'kyHieu'
  | 'ngayCoHieuLuc'
  | 'ngayHetHieuLuc'
  | 'noiDung'
  | 'ngayBanHanh'
  | 'hinhThucBoSung'
  | 'ttndBoSung'
>;

export type IRequestUpdateThongTuNghiDinh = Omit<IRequestCreateThongTuNghiDinh, 'kyHieu'>;

export interface ISearchThongTuNghiDinh
  extends PartialSearchListQueryParams<
    Omit<IThongTuNghiDinh, 'so' | 'hinhThucBoSung' | 'ttndBoSung'>
  > {
  isConHieuLuc?: boolean;
}
