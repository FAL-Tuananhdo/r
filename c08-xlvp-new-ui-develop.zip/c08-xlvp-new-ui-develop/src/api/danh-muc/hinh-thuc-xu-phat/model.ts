import { IDonViThoiGian, ILoaiHinhPhatBoSung, ILoaiHinhThucXuPhat } from '/@/const/type';

import { BaseInfo } from '../../types';

export interface IHinhThucXuPhat extends BaseInfo {
  ma: string;
  noiDung: string;
  loai: ILoaiHinhThucXuPhat;
  maLoaiTangVat?: string;
  tiLePhat?: number;
  thoiHan?: number;
  loaiBoSung?: ILoaiHinhPhatBoSung;
  loaiThoiHan?: IDonViThoiGian;
  noiDungIn?: string;
  maVBPL?: string[];
  trangThai: boolean;
}

export type ISearchHinhThucXuPhat = PartialSearchListQueryParams<
  Pick<IHinhThucXuPhat, 'ma' | 'loai' | 'noiDung' | 'trangThai'>
>;

export interface ISearchHinhPhatBoSung {
  maHvvp: string;
}

export type IRequestBody = Pick<
  IHinhThucXuPhat,
  | 'loai'
  | 'loaiBoSung'
  | 'maLoaiTangVat'
  | 'trangThai'
  | 'noiDung'
  | 'tiLePhat'
  | 'thoiHan'
  | 'loaiThoiHan'
  | 'noiDungIn'
  | 'maVBPL'
>;
