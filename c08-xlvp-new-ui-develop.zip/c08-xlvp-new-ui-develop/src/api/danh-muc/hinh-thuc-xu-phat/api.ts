import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IHinhThucXuPhat, ISearchHinhPhatBoSung, ISearchHinhThucXuPhat } from './model';

export class HinhThucXuPhatApi extends BaseApi<IHinhThucXuPhat> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.HinhThucXuPhat);
  }

  async exportExcel(params: ISearchHinhThucXuPhat): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
  async getAllNoiDungHTXPBS(): Promise<string[]> {
    return xlvpHttp.get<string[]>({
      url: `/danh-muc/hinh-thuc-xu-phat/bo-sung/noi-dung-in`,
    });
  }

  async getHtxpBoSung(params: ISearchHinhPhatBoSung): Promise<IHinhThucXuPhat[]> {
    return xlvpHttp.get<IHinhThucXuPhat[]>({
      url: `${this.url}/bo-sung`,
      params: params,
    });
  }
}
