import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IDanhMucNoiCapGiayTo, ISearchNoiCapGiayTo } from './model';

export class NoiCapGiayToApi extends BaseApi<IDanhMucNoiCapGiayTo> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.NoiCapGiayTo);
  }
  async exportExcel(params: ISearchNoiCapGiayTo): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
