import { BaseInfo } from '../../types';

export interface IDanhMucNoiCapGiayTo extends BaseInfo {
  ten: string;
  ma: string;
  maLoaiGiayTo: string[];
  trangThai: boolean;
  maDiaDanhHanhChinh: string;
  isDonViCsgt: boolean;
  diaChi?: string;
  soDienThoai?: string;
  email?: string;
  ghiChu?: string;
}

export interface ISearchNoiCapGiayTo
  extends PartialSearchListQueryParams<
    Pick<IDanhMucNoiCapGiayTo, 'ma' | 'ten' | 'diaChi' | 'maDiaDanhHanhChinh' | 'trangThai'>
  > {
  maGiayTo?: string;
  maTinhThanh?: string;
  maQuanHuyen?: string;
}

export type IRequestBodyNoiCapGiayTo = Omit<IDanhMucNoiCapGiayTo, keyof BaseInfo>;
