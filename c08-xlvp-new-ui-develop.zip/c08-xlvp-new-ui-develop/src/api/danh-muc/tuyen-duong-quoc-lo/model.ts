import { ILoaiHinhTuyenDuongQuocLo } from '/@/const';

import { BaseInfo } from '../../types';

export interface IDanhMucTuyenDuongQuocLo extends BaseInfo {
  ma: string;
  loai: ILoaiHinhTuyenDuongQuocLo;
  ten: string;
  diemBatDau: string;
  diemKetThuc: string;
  chieuDai?: number;
  maTinhThanh?: string;
  quaKhuDacBiet?: boolean;
  trangThai?: boolean;
  ghiChu?: string;
}

export type ISearchTuyenDuongQuocLo = PartialSearchListQueryParams<
  Pick<IDanhMucTuyenDuongQuocLo, 'loai' | 'ma' | 'ten' | 'diemBatDau' | 'diemKetThuc' | 'trangThai'>
>;

export type IRequestTuyenDuongQuocLo = Pick<
  IDanhMucTuyenDuongQuocLo,
  | 'ten'
  | 'loai'
  | 'diemBatDau'
  | 'diemKetThuc'
  | 'chieuDai'
  | 'quaKhuDacBiet'
  | 'trangThai'
  | 'ghiChu'
  | 'maTinhThanh'
>;
