import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IDanhMucTuyenDuongQuocLo, ISearchTuyenDuongQuocLo } from './model';

export class TuyenDuongQuocLoApi extends BaseApi<IDanhMucTuyenDuongQuocLo> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.TuyenDuongQuocLo);
  }
  async exportExcel(params: ISearchTuyenDuongQuocLo): Promise<void> {
    await xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
