import { ILinhVuc, ILoaiTangVat } from '/@/const';

import { BaseInfo } from '../../types';

export interface ILoaiGiayTo extends BaseInfo {
  ma: string;
  nhom: ILoaiTangVat;
  ten: string;
  linhVuc: ILinhVuc[];
  trangThai: boolean;
}

export interface ISearchLoaiGiayTo
  extends PartialSearchListQueryParams<Pick<ILoaiGiayTo, 'nhom' | 'ten' | 'trangThai'>> {
  linhVuc?: string;
}

export type IRequestBodyLoaiGiayTo = Pick<ILoaiGiayTo, 'nhom' | 'ten' | 'linhVuc' | 'trangThai'>;
