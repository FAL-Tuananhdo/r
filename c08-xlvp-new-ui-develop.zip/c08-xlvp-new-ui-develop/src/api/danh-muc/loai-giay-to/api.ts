import { xlvpHttp } from '/@/utils/http/axios';

import { BaseApi } from '../../baseApi';
import { DanhMucXlvpEndPoint } from '../../apiConst';
import { ILoaiGiayTo, ISearchLoaiGiayTo } from './model';

export class LoaiGiayToApi extends BaseApi<ILoaiGiayTo> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.LoaiGiayTo);
  }
  async exportExcel(params: ISearchLoaiGiayTo): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
