import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { ISearchParamsVanBanPhapLuat, IVanBanPhapLuat } from './model';

export class VanBanPhapLuatApi extends BaseApi<IVanBanPhapLuat> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.VanBanPhapLuat);
  }

  async exportExcel(params: ISearchParamsVanBanPhapLuat): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
