import { ILinhVuc } from '/@/const';

import { BaseInfo } from '../../types';

export interface ISuaDoiVanBanPhapLuat {
  ma: string;
  ghiChu?: string;
}

export interface IVanBanPhapLuat extends BaseInfo {
  ma: string;
  maTTND: string;
  dieu: string;
  noiDung: string;
  linhVuc: ILinhVuc[];
  maThamChieu?: string;
  tuNgay?: Date;
  denNgay?: Date;
  khoan?: string;
  diem?: string;
  suaDoiBoSung?: ISuaDoiVanBanPhapLuat[];
}

export type IRequestCreateBodyVbpl = Pick<
  IVanBanPhapLuat,
  'maTTND' | 'dieu' | 'khoan' | 'diem' | 'noiDung' | 'linhVuc' | 'suaDoiBoSung'
>;

export type IRequestUpdateBodyVbpl = IRequestCreateBodyVbpl & Pick<IVanBanPhapLuat, 'ma'>;

export interface ISearchParamsVanBanPhapLuat
  extends PartialSearchListQueryParams<
    Pick<IVanBanPhapLuat, 'maTTND' | 'dieu' | 'khoan' | 'diem' | 'noiDung'>
  > {
  linhVuc?: string;
  tuNgay?: Date;
  denNgay?: Date;
}
