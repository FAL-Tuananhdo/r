import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IPhuongTien } from './model';

export class PhuongTienApi extends BaseApi<IPhuongTien> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.PhuongTien);
  }
}
