import { ILinhVuc, INhomPhuongTien } from '/@/const';

import { BaseInfo } from '../../types';

export interface IPhuongTien extends BaseInfo {
  ma: string;
  ten: string;
  linhVuc: ILinhVuc;
  nhomPhuongTien: INhomPhuongTien;
  trangThai: boolean;
  hasChild: boolean;
  maCha?: string;
  moTa?: string;
}

export interface ISearchPhuongTien
  extends PartialSearchListQueryParams<
    Pick<IPhuongTien, 'ma' | 'nhomPhuongTien' | 'ten' | 'trangThai' | 'linhVuc'>
  > {
  layDanhSachPhuongTienCapNhoNhat?: boolean;
}
