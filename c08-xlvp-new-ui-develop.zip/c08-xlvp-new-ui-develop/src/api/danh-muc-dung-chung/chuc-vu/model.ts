import { BaseInfo } from '../../types';

export interface IChucVu extends BaseInfo {
  maChucVu: string;
  maTaoQuyetDinh: number;
  tenChucVu: string;
  trangThai: boolean;
}

export type ISearchChucVu = PartialSearchListQueryParams<Pick<IChucVu, 'maChucVu' | 'tenChucVu'>>;
