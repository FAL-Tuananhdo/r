import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IChucVu } from './model';

export class ChucVuApi extends BaseApi<IChucVu> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.ChucVu);
  }
}
