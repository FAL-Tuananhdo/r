import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { ICapBac } from './model';

export class CapBacApi extends BaseApi<ICapBac> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.CapBac);
  }
}
