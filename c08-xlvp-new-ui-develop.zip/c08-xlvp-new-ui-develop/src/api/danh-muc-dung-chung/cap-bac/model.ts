import { BaseInfo } from '../../types';

export interface ICapBac extends BaseInfo {
  trangThai: boolean;
  tenCapBac: string;
  maCapBac: string;
  loaiCapBac?: number;
  moTa?: string;
}
