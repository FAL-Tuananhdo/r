import { BaseInfo } from '../../types';

export interface INgheNghiep extends BaseInfo {
  ma: string;
  ten: string;
  trangThai: boolean;
  moTa?: number;
}

export type IRequestBodyNgheNghiep = Omit<INgheNghiep, 'ma'>;

export type ISearchNgheNghiep = PartialSearchListQueryParams<Omit<INgheNghiep, 'moTa'>>;
