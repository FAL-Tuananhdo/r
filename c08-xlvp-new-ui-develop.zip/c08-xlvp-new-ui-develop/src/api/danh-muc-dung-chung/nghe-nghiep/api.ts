import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { INgheNghiep, ISearchNgheNghiep } from './model';

export class NgheNghiepApi extends BaseApi<INgheNghiep> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.NgheNghiep);
  }

  async exportExcel(params: ISearchNgheNghiep): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${this.url}/export/excel`,
      params: params,
    });
  }
}
