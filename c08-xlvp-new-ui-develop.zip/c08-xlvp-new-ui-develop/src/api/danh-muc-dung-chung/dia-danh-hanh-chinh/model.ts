import { BaseInfo } from '../../types';

export interface IDiaDanhHanhChinh extends BaseInfo {
  id: string;
  ma: string;
  tenDiaDanh: string;
  maTinhThanh?: string;
  maQuanHuyen?: string;
  maPhuongXa?: string;
  capHanhChinh?: string;
  maDiaDanhHanhChinhCapTren?: string;
  maBCA?: string;
  diaDanhHcCon?: IDiaDanhHanhChinh[];
  trangThai: boolean;
}

export type ISearchDiaDanhHanhChinh = PartialSearchListQueryParams<
  Pick<IDiaDanhHanhChinh, 'maTinhThanh' | 'maPhuongXa' | 'maQuanHuyen' | 'trangThai'>
>;

export interface ITinhThanh extends Pick<IDiaDanhHanhChinh, 'maTinhThanh'> {
  diaDanhHcId: number;
  tenTinhThanh: string;
}

export interface ISearchTinhThanh {
  tinhThanh?: string;
}

export interface IQuanHuyen extends Pick<IDiaDanhHanhChinh, 'maQuanHuyen'> {
  diaDanhHcId: number;
  tenQuanHuyen: string;
}

export interface ISearchQuanHuyen extends Pick<ISearchDiaDanhHanhChinh, 'maTinhThanh'> {
  quanHuyen?: string;
}

export interface IPhuongXa extends Pick<IDiaDanhHanhChinh, 'maPhuongXa'> {
  diaDanhHcId: number;
  tenPhuongXa: string;
}

export interface ISearchPhuongXa
  extends Pick<ISearchDiaDanhHanhChinh, 'maTinhThanh' | 'maQuanHuyen'> {
  phuongXa?: string;
}
