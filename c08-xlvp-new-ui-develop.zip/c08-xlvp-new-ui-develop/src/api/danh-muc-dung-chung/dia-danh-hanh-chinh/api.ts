import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import {
  IDiaDanhHanhChinh,
  IPhuongXa,
  IQuanHuyen,
  ISearchPhuongXa,
  ISearchQuanHuyen,
  ISearchTinhThanh,
  ITinhThanh,
} from './model';

export class DiaDanhHanhChinhApi extends BaseApi<IDiaDanhHanhChinh> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.DiaDanhHanhChinh);
  }

  getListTinhThanh = async (params: ISearchTinhThanh): Promise<ITinhThanh[]> => {
    return await this.http.get({
      url: `${this.url}/search/tinh-thanh`,
      params,
    });
  };

  getListQuanHuyen = async (params: ISearchQuanHuyen): Promise<IQuanHuyen[]> => {
    return await this.http.get({
      url: `${this.url}/search/quan-huyen`,
      params,
    });
  };

  getListPhuongXa = async (params: ISearchPhuongXa): Promise<IPhuongXa[]> => {
    return await this.http.get({
      url: `${this.url}/search/phuong-xa`,
      params,
    });
  };
}
