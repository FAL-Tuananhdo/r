import { RequestOptions } from '/#/axios';

import { danhMucHttp } from '/@/utils/http/axios';
import { VAxios } from '/@/utils/http/axios/Axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { IDanhMucTongHop, ISearchDanhMucTongHop } from '../../common';

export class DanhMucTongHopApi {
  http: VAxios;
  url: string;
  constructor() {
    this.http = danhMucHttp;
    this.url = DanhMucDungChungEndPoint.DanhMucTongHop;
  }

  async getHangGplx(
    params?: ISearchDanhMucTongHop,
    options?: RequestOptions,
  ): Promise<IDanhMucTongHop[]> {
    const res = await this.http.get<IDanhMucTongHop[]>(
      {
        url: `${this.url}/hang-gplx`,
        params: params,
      },
      options,
    );
    return res;
  }

  async getLyDoTamGiuNguoi(params?: ISearchDanhMucTongHop): Promise<IDanhMucTongHop[]> {
    const res = await this.http.get<IDanhMucTongHop[]>({
      url: `${this.url}/ly-do-tam-giu-nguoi`,
      params: params,
    });
    return res;
  }
}
