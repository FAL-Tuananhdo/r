import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { INgayNghi } from './model';

export class NgayNghiApi extends BaseApi<INgayNghi> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.NgayNghi);
  }
}
