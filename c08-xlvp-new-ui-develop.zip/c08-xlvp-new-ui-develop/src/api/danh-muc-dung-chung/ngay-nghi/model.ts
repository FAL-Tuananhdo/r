import { BaseInfo } from '../../types';

export interface INgayNghi extends BaseInfo {
  maNgayNghi: string;
  tenNgayNghi: string;
  thoiGianNghi: string;
  thoiGianBatDau: Date;
  thoiGianKetThuc: Date;
}

export type ISearchNgayNghi = PartialSearchListQueryParams<
  Omit<INgayNghi, 'tenNgayNghi' | 'thoiGianNghi'>
>;
