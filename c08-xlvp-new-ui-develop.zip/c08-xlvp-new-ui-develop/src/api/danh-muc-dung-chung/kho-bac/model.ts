import { BaseInfo } from '../../types';

export interface IKhoBac extends BaseInfo {
  ten: string;
  ma: string;
  ma8So: string;
  maTinhThanh: string;
  isDefault: boolean;
  maCha?: string;
  maQuanHuyen?: string;
  maPhuongXa?: string;
  diaChi?: string;
  trangThai?: boolean;
}

export type ISearchKhoBac = PartialSearchListQueryParams<Omit<IKhoBac, 'ten' | 'ma'>>;
