import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IKhoBac } from './model';

export class KhoBacApi extends BaseApi<IKhoBac> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.KhoBac);
  }
}
