import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IDMCanCu } from './model';

export class CanCuApi extends BaseApi<IDMCanCu> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.CanCu);
  }
}
