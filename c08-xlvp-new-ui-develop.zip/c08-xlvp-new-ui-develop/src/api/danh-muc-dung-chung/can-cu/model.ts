import { BaseInfo } from '../../types';

export interface IDMCanCu extends BaseInfo {
  ten: string;
  ma: string;
  trangThai: boolean;
  ghiChu?: string;
}

export type ISearchCanCu = PartialSearchListQueryParams<Omit<IDMCanCu, 'ghiChu'>>;

export type IRequestCreateBodyCanCu = Omit<IDMCanCu, 'ma'>;
