import { xlvpHttp } from '/@/utils/http/axios';

import { DanhMucXlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { INoiTamGiu } from './model';

export class NoiTamGiuApi extends BaseApi<INoiTamGiu> {
  constructor() {
    super(xlvpHttp, DanhMucXlvpEndPoint.NoiTamGiu);
  }
}
