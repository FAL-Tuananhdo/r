import { BaseInfo } from '../../types';

export interface INoiTamGiu extends BaseInfo {
  maDonViCsgt: string[];
  ma: string;
  ten: string;
  diaChi: string;
  maDiaDanhHanhChinh: string;
  soDienThoai?: string;
  email?: string;
  trangThai: boolean;
  ghiChu?: string;
}

export type ISearchNoiTamGiu = PartialSearchListQueryParams<
  Omit<INoiTamGiu, 'ghiChu' | 'soDienThoai' | 'email'>
>;

export type IRequestBodyNoiTamGiu = Omit<INoiTamGiu, 'ma'>;
