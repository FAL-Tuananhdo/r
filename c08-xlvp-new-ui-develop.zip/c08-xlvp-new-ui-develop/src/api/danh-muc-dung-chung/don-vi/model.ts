import { ICapDonViCsgt, ILinhVuc } from '/@/const';

import { BaseInfo } from '../../types';
import { IKhoBac } from '../kho-bac/model';

export type IDiaDiemNopPhat = Pick<IKhoBac, 'ten' | 'ma' | 'ma8So' | 'isDefault'>;

export interface IDiaChiCsgt {
  id: number;
  diaChi: string;
  diaDanh: string;
  maDiaDanhHanhChinh: string;
  soDienThoai?: string;
  email?: string;
}

export interface IDonViCsgt extends BaseInfo {
  capDonVi: ICapDonViCsgt;
  linhVuc: ILinhVuc[];
  ma: string;
  maCap1: string;
  maCap2: string;
  maCap3: string;
  maCap4: string;
  tenDayDu: string;
  tenVietTat: string;
  trangThai: boolean;
  isNhapHoDonViCsgtNgangCap: boolean;
  diaDiemNopPhat: IDiaDiemNopPhat[];
  diaChiDonViCsgt: IDiaChiCsgt[];
  maCha?: string;
  donViCha?: IDonViCsgt;
  hasChild?: boolean;
  children?: IDonViCsgt[];
}

export interface ISearchDonViCsgt
  extends PartialSearchListQueryParams<
    Pick<IDonViCsgt, 'linhVuc' | 'maCap2' | 'maCap3' | 'maCap4' | 'maCha' | 'trangThai'>
  > {
  tenDonVi?: string;
  isWithPermission?: boolean;
}

export interface IParamsLevelDonViCsgt {
  levelUp?: number;
  levelDown?: number;
}

export type ISearchDonViCsgtTreeLevel = PartialSearchListQueryParams<IParamsLevelDonViCsgt>;
