import { danhMucHttp } from '/@/utils/http/axios';

import { RequestOptions } from '/#/axios';
import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IDonViCsgt, ISearchDonViCsgtTreeLevel } from './model';
import { BasePagination } from '../../types';

export class DonViCsgtApi extends BaseApi<IDonViCsgt> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.DonViCsgt_v2);
  }

  async getTree(
    params?: ISearchDonViCsgtTreeLevel,
    options?: RequestOptions,
  ): Promise<BasePagination<IDonViCsgt>> {
    return this.http.get<BasePagination<IDonViCsgt>>(
      {
        url: `${this.url}/tree-level`,
        params: params,
      },
      options,
    );
  }
}
