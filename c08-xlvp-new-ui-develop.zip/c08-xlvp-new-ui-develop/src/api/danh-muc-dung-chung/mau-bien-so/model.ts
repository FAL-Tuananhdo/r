import { BaseInfo } from '../../types';

export interface IMauBienSo extends BaseInfo {
  maMau: string;
  tenMau: string;
  moTa?: string;
  trangThai?: boolean;
}

export type ISearchMauBienSo = PartialSearchListQueryParams<
  Pick<IMauBienSo, 'maMau' | 'tenMau' | 'trangThai' | 'moTa'>
>;
