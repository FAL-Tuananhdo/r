import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IMauBienSo } from './model';

export class MauBienSoApi extends BaseApi<IMauBienSo> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.MauBien);
  }
}
