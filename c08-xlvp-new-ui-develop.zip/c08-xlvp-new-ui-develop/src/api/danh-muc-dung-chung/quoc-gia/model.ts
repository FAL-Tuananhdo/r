import { BaseInfo } from '../../types';

export interface IQuocGia extends BaseInfo {
  maQuocGia: string;
  tenTiengViet: string;
  trangThai: boolean;
  tenTiengAnh: string;
  tenDayDu: string;
}

export type ISearchQuocGia = PartialSearchListQueryParams<
  Pick<IQuocGia, 'maQuocGia' | 'tenTiengViet' | 'trangThai'>
>;
