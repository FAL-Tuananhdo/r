import { danhMucHttp } from '/@/utils/http/axios';

import { DanhMucDungChungEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { IQuocGia } from './model';

export class QuocGiaApi extends BaseApi<IQuocGia> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.QuocGia);
  }
}
