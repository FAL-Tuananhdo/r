import { INguoiViPham } from '../common';

export interface ISearchParamsDanCuC06 extends Pick<INguoiViPham, 'ten'> {
  soDinhDanh: string;
}
