import { xlvpHttp } from '/@/utils/http/axios';

import { XlvpEndPoint } from '../apiConst';
import { INguoiViPham } from '../common';
import { ISearchParamsDanCuC06 } from './model';

export class TraCuuDanCuApi {
  async get(params: ISearchParamsDanCuC06): Promise<INguoiViPham[]> {
    return await xlvpHttp.get<INguoiViPham[]>({
      url: XlvpEndPoint.TraCuuDanCu,
      params: {
        soDinhDanh: params.soDinhDanh,
        ten: params.ten,
      },
    });
  }
}
