import { BaseInfo } from '/@/api';
import {
  ITrangThaiChuyenPhat,
  ITrangThaiDangKy,
  ITrangThaiTangVat,
  ITrangThaiTaoDon,
} from '/@/const';
import { IFormChuyenTrangThai } from '/@/views/buu-dien/theo-doi-chuyen-phat-giay-to/component/modal-chuyen-trang-thai-tra';

export interface IBuuDien extends BaseInfo {
  soQuyetDinh: string;
  maBieuMau: string;
  maGiayTo: string;
  nguoiViPham?: string;
  bienSo?: string;
  loaiGiayTo?: string;
  noiCapGiayTo?: string;
  tuocTuNgay?: Date;
  tuocDenNgay?: Date;
  trangThaiDangKy?: ITrangThaiDangKy;
  trangThaiChuyenPhat?: ITrangThaiChuyenPhat;
  thongTinGiayTo?: BbQdMaDto;
  trangThaiGiayTo?: ITrangThaiTangVat;
  ngayTamGiu?: Date;
  ngayTraLai?: Date;
  donViCsgtGiu?: string;
  maDon?: string;
}

export interface ISearchBuuDien
  extends PartialSearchListQueryParams<
    Pick<
      IBuuDien,
      | 'nguoiViPham'
      | 'bienSo'
      | 'trangThaiDangKy'
      | 'loaiGiayTo'
      | 'tuocTuNgay'
      | 'tuocDenNgay'
      | 'trangThaiChuyenPhat'
    >
  > {
  noiCap?: string;
  tamGiuTuNgay?: Date;
  tamGiuDenngay?: Date;
  maDonViCsgt?: string;
  trangThaiTaoDon?: ITrangThaiTaoDon;
}

export type BbQdMaDto = {
  ma: string;
  maBieuMau: string;
  maGiayTo: string;
};

export interface DtoChuyenTrangThai extends IFormChuyenTrangThai {
  lstBbQdMaDto: BbQdMaDto[];
}
