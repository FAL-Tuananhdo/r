import { xlvpHttp } from '/@/utils/http/axios';

import { IBuuDien, ISearchBuuDien, DtoChuyenTrangThai } from './model';
import { XlvpEndPoint } from '../apiConst';
import { BasePagination } from '../types';

export class BuuDienApi {
  getAll(params?: ISearchBuuDien): Promise<BasePagination<IBuuDien>> {
    return xlvpHttp.get<BasePagination<IBuuDien>>({
      url: XlvpEndPoint.BuuDien,
      params: params,
    });
  }

  async exportExcel(params?: ISearchBuuDien): Promise<void> {
    xlvpHttp.downloadFile({
      url: `${XlvpEndPoint.BuuDien}/export/excel`,
      params: params,
    });
  }

  async confirmChangeStatus(body: DtoChuyenTrangThai): Promise<DtoChuyenTrangThai> {
    return xlvpHttp.put<DtoChuyenTrangThai>({
      url: `${XlvpEndPoint.BuuDien}/confirm-status`,
      params: body,
    });
  }
}
