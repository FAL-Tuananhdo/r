export interface IResultKySo {
  totalSuccess: number;
  totalFailed: number;
  details: [
    {
      fileName: string;
      message: string;
    },
  ];
}
