export interface IBasePhuongTienViPham {
  maPhuongTien: string;
  isDkxData: boolean;
  tenChuPt?: string;
  maDiaDanhHanhChinh?: string;
  soDangKy?: string;
  diaChiChuPt?: string;
  noiCap?: string;
  ngayCap?: Date;
}

export interface IPhuongTienViPhamDuongBo extends Omit<IBasePhuongTienViPham, 'bienSo'> {
  mauBien?: string;
  bienSo?: string;
  bienSo2?: string;
  dungTich?: string;
  soKhung?: string;
  soMay?: string;
  nhanHieu?: string;
  mauSon?: string;
  soLoai?: string;
}

export interface IPhuongTienViPhamDuongThuy extends Omit<IBasePhuongTienViPham, 'bienSo'> {
  trongTai?: string;
  trongTai2?: string;
  congSuat?: string;
  congSuat2?: string;
  soDangKy2?: string;
}

export interface IPhuongTienViPhamDuongSat
  extends Omit<IBasePhuongTienViPham, 'soDangKy' | 'noiCap'> {
  noiCap: string;
  bienSo?: string;
  bienSo2?: string;
}

export type IPhuongTienViPham =
  | IPhuongTienViPhamDuongBo
  | IPhuongTienViPhamDuongThuy
  | IPhuongTienViPhamDuongSat;

export interface ISearchParamsThongTinPhuongTien {
  maPhuongTien?: string;
  mauBien?: string;
  bienSo?: string;
  soMay?: string;
  soKhung?: string;
}
