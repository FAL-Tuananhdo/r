import { BaseInfo } from '../types';

export interface IDanhMucTongHop extends BaseInfo {
  key: string;
  value: string;
  type: string;
  description?: string;
}

export type ISearchDanhMucTongHop = PartialSearchListQueryParams<
  Pick<IDanhMucTongHop, 'value' | 'key'>
>;
