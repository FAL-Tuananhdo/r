import { IBaseSearchListQueryParams } from '../types';

export interface IHanhViViPham {
  maHVVP: string;
  maTTND: string;
  soLanVp?: number;
  thoiGianVp?: Date;
  diaDiemVp?: string;
  mucTienPhat?: number;
  boSungHvvp?: string;
  soTienPhatCaNhanLonNhat?: number;
  soTienPhatCaNhanMacDinh?: number;
  soTienPhatToChucLonNhat?: number;
  soTienPhatToChucMacDinh?: number;
  diem?: string;
  dieu?: string;
  khoan?: string;
  maBBQD?: string;
  maBieuMau?: string;
  ngayBanHanhTTND?: string;
  noiDungHanhViViPham?: string;
  noiDungThongTuNghiDinh?: string;
  noiDungTTND?: string;
  soTTND?: string;
}

export interface ISearchParamsHanhViViPham extends IBaseSearchListQueryParams {
  loai: string;
  soDinhDanh: string;
}

export interface IKiemTraSoLanViPham {
  maHvvp: string;
  noiDungHvvp: string;
  soLanVp: number;
  thoiGianVp: Date[];
}
