import { ILoaiNgaySinh } from '/@/const';

export interface INguoiViPham extends IDoiTuongViPhamBase {
  isC06Data: boolean;
  ngaySinh?: Date;
  quocTich?: string;
  noiSinh?: string;
  soDinhDanh?: string;
  gioiTinh?: string;
  ngheNghiep?: string;
  soDienThoai?: string;
  email?: string;
  noiOHienTai?: string;
  loaiNgaySinh?: ILoaiNgaySinh;
}

export interface IToChucViPham extends IDoiTuongViPhamBase {
  maSoDn?: string;
  soGcn?: string;
  tenNguoiDaiDien?: string;
  chucDanhNguoiDaiDien?: string;
  gioiTinhNguoiDaiDien?: string;
}

interface IDoiTuongViPhamBase {
  ten: string;
  ngayCap?: Date;
  noiCap?: string;
  diaChi?: { maDiaDanh: string; chiTiet?: string };
}
