export interface IDiaBanViPham {
  maTinhThanh: string;
  tenTinhThanh: string;
  maQuanHuyen: string;
  tenQuanHuyen: string;
  maPhuongXa: string;
  tenPhuongXa: string;
}
