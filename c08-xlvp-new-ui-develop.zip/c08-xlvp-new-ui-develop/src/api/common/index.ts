export type { INguoiViPham, IToChucViPham } from './doi-tuong-vi-pham';
export type { IPhuongTienViPham } from './phuong-tien-vi-pham';
export type { IDanhMucTongHop, ISearchDanhMucTongHop } from './danh-muc-tong-hop';
export type { IDiaBanViPham } from './dia-ban-vi-pham';
export type { IHanhViViPham } from './hanh-vi-vi-pham';
