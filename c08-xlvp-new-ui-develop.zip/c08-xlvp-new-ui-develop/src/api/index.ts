import { DanhMucDungChungApi } from './dmdcApi';
import { IamApi } from './iamApi';
import { XlvpApi } from './xlvpApi';
import { XuLyPhatNguoiApi } from './phatNguoiApi';
import { BctkApi } from './bctkApi';
import { ESignApi } from './e-sign/api';

export * from './types';

let apiXlvpInstance: InstanceType<typeof XlvpApi>;
let apiDanhMucDungChungInstance: InstanceType<typeof DanhMucDungChungApi>;
let apiIamInstance: InstanceType<typeof IamApi>;
let apiPhatNguoiInstance: InstanceType<typeof XuLyPhatNguoiApi>;
let apiBctkInstance: InstanceType<typeof BctkApi>;
let apiESignInstance: InstanceType<typeof ESignApi>;

export const useXlvpApi = (): XlvpApi => {
  if (!apiXlvpInstance) {
    apiXlvpInstance = new XlvpApi();
  }
  return apiXlvpInstance;
};

export const useDanhMucDungChungApi = (): DanhMucDungChungApi => {
  if (!apiDanhMucDungChungInstance) {
    apiDanhMucDungChungInstance = new DanhMucDungChungApi();
  }
  return apiDanhMucDungChungInstance;
};

export const useIamApi = (): IamApi => {
  if (!apiIamInstance) {
    apiIamInstance = new IamApi();
  }
  return apiIamInstance;
};

export const usePhatNguoiApi = (): XuLyPhatNguoiApi => {
  if (!apiPhatNguoiInstance) {
    apiPhatNguoiInstance = new XuLyPhatNguoiApi();
  }
  return apiPhatNguoiInstance;
};

export const useBctkApi = (): BctkApi => {
  if (!apiBctkInstance) {
    apiBctkInstance = new BctkApi();
  }
  return apiBctkInstance;
};

export const useESignApi = () => {
  if (!apiESignInstance) {
    apiESignInstance = new ESignApi();
  }
  return apiESignInstance;
};
