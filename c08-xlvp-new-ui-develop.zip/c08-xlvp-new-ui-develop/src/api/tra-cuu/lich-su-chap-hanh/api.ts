import { BaseApi } from '/@/api/baseApi';
import {
  IParamFetch,
  IResponseLichSuChapHanh,
  IresponseSoLanViPham,
} from '/@/api/tra-cuu/lich-su-chap-hanh/model';
import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { BctkBasePagination } from '/@/api/bao-cao-thong-ke/model';

export class TraCuuLichSuChapHanhApi extends BaseApi<IResponseLichSuChapHanh> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.Reporting);
  }

  async search(params: IParamFetch): Promise<BctkBasePagination<IResponseLichSuChapHanh>> {
    return this.http.get<BctkBasePagination<IResponseLichSuChapHanh>>({
      url: `${this.url}/search`,
      params: { ...params, reportCode: 'BCA_XLVP_08' },
    });
  }

  async exportExcel(params: IParamFetch): Promise<void> {
    baoCaoThongKeHttp.downloadFile({
      url: `${BaoCaoThongKeEndPoint.ExportExcel}`,
      params: { ...params, reportCode: 'BCA_XLVP_08' },
    });
  }

  async getSoLanViPham(params: IParamFetch): Promise<BctkBasePagination<IresponseSoLanViPham>> {
    return this.http.get<BctkBasePagination<IresponseSoLanViPham>>({
      url: `${this.url}/search`,
      params: { ...params, reportCode: 'BCA_XLVP_08_SUM' },
    });
  }
}
