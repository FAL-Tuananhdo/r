import { BaseInfo, IBaseSearchListQueryParams } from '/@/api';
import { RangeValue } from '/@/views/bao-cao-thong-ke/use/UseDisableRangeExport';

export interface IParamLichSuChapHanh extends Omit<IParamFetch, 'linhVuc'> {
  '[tuNgay, denNgay]'?: RangeValue;
  linhVuc?: Array<string>;
}

export interface IParamFetch extends IBaseSearchListQueryParams {
  reportCode: string;
  fileType?: string;
  donVi?: string;
  nguoiViPham?: string;
  bienSo?: string;
  soThongTu?: string;
  tangVat?: string;
  tuNgay?: string;
  denNgay?: string;
  trangThai?: string;
  maMauBien?: string;
  soDinhDanh?: string;
  maSoDN?: string;
  linhVuc?: string;
  username?: string;
}

export interface IResponseLichSuChapHanh extends BaseInfo {
  tenDtvp?: string;
  bienSo?: string;
  nhom?: string;
  ttTv?: string;
  donViGiu?: string;
  tuNgayTamGiu?: Date;
  denNgayTamGiu?: Date;
  tuNgayDangTuoc?: Date;
  denNgayDangTuoc?: Date;
  trangThai?: string;
  linhVuc?: string;
}

export interface IresponseSoLanViPham extends IResponseLichSuChapHanh {
  soLanViPham?: string;
}
