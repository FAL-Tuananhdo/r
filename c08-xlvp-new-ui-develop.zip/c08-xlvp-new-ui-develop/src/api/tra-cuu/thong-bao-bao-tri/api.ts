import { xlvpHttp } from '/@/utils/http/axios';

import { XlvpEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import { ISearchParamsThongBao, IThongBao } from './model';

export class ThongBaoBaoTriApi extends BaseApi<IThongBao> {
  constructor() {
    super(xlvpHttp, XlvpEndPoint.ThongBao);
  }

  getThongBaoPublic = async (): Promise<IThongBao[]> => {
    return this.http.get(
      {
        url: `${this.url}/public`,
      },
      {
        withToken: false,
      },
    );
  };

  exportExcel = async (params: ISearchParamsThongBao): Promise<void> => {
    return this.http.downloadFile({
      url: `${this.url}/excel`,
      params: params,
    });
  };
}
