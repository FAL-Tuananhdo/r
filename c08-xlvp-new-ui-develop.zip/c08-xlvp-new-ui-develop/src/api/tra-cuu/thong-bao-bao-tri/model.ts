import { BaseInfo, IBaseSearchListQueryParams } from '/@/api';
import { RangeValue } from '/@/views/bao-cao-thong-ke/use/UseDisableRangeExport';

export interface IParamThongBao {
  '[tuNgay, denNgay]'?: RangeValue;
  noiDung?: string;
}

export interface INoiDungThongBao {
  thuTuHienThi: number;
  noiDung: string;
}
export interface IThongBao extends BaseInfo {
  ma: string;
  noiDung: INoiDungThongBao[];
  thoiGianBat: Date;
  thoiGianTat: Date;
  isKhanCap: boolean;
}

export interface ISearchParamsThongBao extends IBaseSearchListQueryParams {
  noiDung?: string;
  tuNgay?: string;
  denNgay?: string;
}
