export enum XlvpEndPoint {
  BbQd = '/bb-qd',
  VuViec = '/vu-viec',
  QuyetDinh = '/quyet-dinh',
  GiaoQuyen = '/giao-quyen',
  BuuDien = '/chuyen-phat-buu-dien',
  TraCuuDanCu = '/thong-tin-dan-cu',
  TangVat = '/tang-vat',
  DiaDanh = '/dia-danh',
  LichSuThayDoi = '/lich-su-thay-doi',
  ChuKySo = '/chu-ky-so',
  ThongBao = '/thong-bao',
}

export enum PhatNguoiEndPoint {
  PhatNguoi = '/phat-nguoi/thong-tin',
  DanhMuc = '/phat-nguoi/danh-muc',
}

export enum IamEndPoint {
  CanBo = '/v1/user/search',
  DanhSachPhanQuyen = '/v1/menu/search',
  ChucNang = '/v1/menu',
  QuyenTruyCapApi = '/v1/menu/get-by-permission-api',
  DanhSachUngDung = '/v1/application/find-all-by-admin',
  ChucNangByParentCode = '/v1/menu/search-by-parent-code-tree',
  UserRouterMenu = '/api/auth/cas/menu-parent-child-for-router',
  UserButtonPermission = '/api/auth/cas/get-menu-group-by-parent-code',
}

export enum EsignEndPoint {
  SignPdf = '/signPDF',
  GetCertInToken = '/getListCertInToken',
}

export enum DanhMucXlvpEndPoint {
  VanBanPhapLuat = '/danh-muc/van-ban-phap-luat',
  HanhViViPham = '/danh-muc/hanh-vi-vi-pham',
  NhomHanhViViPham = '/danh-muc/nhom-hanh-vi-vi-pham',
  NgheNghiep = '/danh-muc/nghe-nghiep',
  ThongTuNghiDinh = '/danh-muc/thong-tu-nghi-dinh',
  MauBbQd = '/danh-muc/mau-bien-ban-quyet-dinh',
  LoaiGiayTo = '/danh-muc/loai-giay-to',
  HinhThucXuPhat = '/danh-muc/hinh-thuc-xu-phat',
  CanCu = '/danh-muc/can-cu',
  NoiTamGiu = '/danh-muc/noi-tam-giu',
  NoiCapGiayTo = '/danh-muc/noi-cap-giay-to',
  TuyenDuongQuocLo = '/danh-muc/tuyen-duong-quoc-lo',
}

export enum DanhMucDungChungEndPoint {
  PhuongTien = '/phuong-tien',
  DiaDanhHanhChinh = '/dia-danh-hanh-chinh',
  DonViCsgt_v1 = '/don-vi-canh-sat-giao-thong',
  DonViCsgt_v2 = '/don-vi-csgt',
  MauBien = '/danh-muc-ma-mau-bien',
  KhoBac = '/kho-bac',
  ChucVu = '/chuc-vu',
  QuocGia = '/quoc-gia',
  DanhMucTongHop = '/tong-hop',
  CapBac = '/cap-bac',
  NgayNghi = '/ngay-nghi',
}

/* CuongTM*/
export enum BaoCaoThongKeEndPoint {
  ExportExcel = '/reporting/view-report',
  Reporting = '/reporting',
  ThongKe = '/export/thong-ke',
  ThongBaoBaoTri = '/thong-bao-bao-tri',
  BaoCaoTongHop = '/export/bao-cao-tong-hop',
  HanhViViViPham = '/reporting/danh-muc',
  Dashboard = '/reporting/view-dash-board',
}

export enum ThongBaoQuyetDinhEndPoint {
  Tuoc = 'tuoc',
  XuPhatVphc = 'xu-phat-vphc',
}
