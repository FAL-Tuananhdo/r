import { xlvpHttp } from '/@/utils/http/axios';

import { XlvpEndPoint } from '../apiConst';
import { IDiaDanh, ICreateRequestDiaDanh } from './model';

export class DiaDanhApi {
  async get(): Promise<IDiaDanh> {
    return xlvpHttp.get<IDiaDanh>({
      url: XlvpEndPoint.DiaDanh,
    });
  }

  async create(body: ICreateRequestDiaDanh): Promise<IDiaDanh> {
    return xlvpHttp.post<IDiaDanh>({
      url: XlvpEndPoint.DiaDanh,
      params: body,
    });
  }
}
