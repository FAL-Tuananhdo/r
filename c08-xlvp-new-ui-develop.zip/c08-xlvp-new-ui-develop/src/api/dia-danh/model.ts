export interface IDiaDanh {
  maCanBo: string;
  maDonViCsgt: string;
  diaChiId: number;
  diaChi: string;
  diaDanh: string;
}

export type ICreateRequestDiaDanh = Pick<IDiaDanh, 'diaChiId'>;
