import { BcSlGiayToPhuongTien } from './bao-cao-thong-ke/sl-giay-to-phuong-tien/api';

export class SlGiayToPhuongTienApi {
  slGiayToPhuongTienApi: BcSlGiayToPhuongTien;
  constructor() {
    this.slGiayToPhuongTienApi = new BcSlGiayToPhuongTien();
  }
}
