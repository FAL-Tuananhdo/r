import { ICanCu } from '../../bb-qd/common/can-cu';
import { BaseInfo } from '../../types';
import { IBaseGiaoQuyen } from '../model';

export interface INoiDungQd34a {
  canCu: ICanCu;
  phamVi: string;
  noiDungGiaoQuyen: string;
  thamQuyen: string;
  trachNhiem: string;
}

export interface IQd34a extends IBaseGiaoQuyen {
  noiDung: INoiDungQd34a;
}

export type ICreateRequestBodyQd34a = Omit<
  IQd34a,
  'ma' | 'trangThai' | 'canBoSua' | 'canBoTao' | keyof BaseInfo
>;

export type IUpdateRequestBodyQd34a = Omit<ICreateRequestBodyQd34a, 'maBieuMau'>;
