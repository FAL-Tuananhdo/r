import { ICanCu } from '../../bb-qd/common/can-cu';
import { BaseInfo } from '../../types';
import { IBaseGiaoQuyen } from '../model';

export interface INoiDungQd36 {
  canCu: ICanCu;
  lyDo: string;
  trachNhiem: string;
}

export interface IQd36 extends IBaseGiaoQuyen {
  noiDung: INoiDungQd36;
}

export type ICreateRequestBodyQd36 = Omit<
  IQd36,
  'ma' | 'trangThai' | 'maDonViCsgt' | keyof BaseInfo
>;

export type IUpdateRequestBodyQd36 = Omit<ICreateRequestBodyQd36, 'maBieuMau'>;
