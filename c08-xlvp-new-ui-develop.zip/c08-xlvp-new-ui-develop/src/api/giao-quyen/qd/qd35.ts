import { ICanCu } from '../../bb-qd/common/can-cu';
import { BaseInfo } from '../../types';
import { IBaseGiaoQuyen } from '../model';

export interface INoiDungQd35 {
  canCu: ICanCu;
  trachNhiem: string;
}

export interface IQd35 extends IBaseGiaoQuyen {
  noiDung: INoiDungQd35;
}

export type ICreateRequestBodyQd35 = Omit<
  IQd35,
  'ma' | 'trangThai' | 'maDonViCsgt' | keyof BaseInfo
>;

export type IUpdateRequestBodyQd35 = Omit<ICreateRequestBodyQd35, 'maBieuMau'>;
