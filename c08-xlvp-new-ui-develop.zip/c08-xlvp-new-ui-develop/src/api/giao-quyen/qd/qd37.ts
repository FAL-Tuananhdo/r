import { ICanCu } from '../../bb-qd/common/can-cu';
import { IBaseGiaoQuyen } from '../model';

export interface IQd37 extends IBaseGiaoQuyen {
  noiDung: INoiDungQd37;
  maCha?: string;
  maBieuMauCha?: string;
}

export interface INoiDungQd37 {
  canCu: ICanCu;
  lyDo?: string;
  trachNhiem?: string;
}

export type ICreateRequestBodyQd37 = Pick<
  IQd37,
  | 'maCha'
  | 'maBieuMau'
  | 'maBieuMauCha'
  | 'linhVuc'
  | 'maNhapTay'
  | 'thoiGianLap'
  | 'canBoGiaoQuyen'
  | 'canBoNhanQuyen'
  | 'noiDung'
>;

export type IUpdateRequestBodyQd37 = Omit<
  ICreateRequestBodyQd37,
  'maCha' | 'maBieuMau' | 'maBieuMauCha'
>;
