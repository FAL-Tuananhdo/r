import { xlvpHttp } from '/@/utils/http/axios';
import { IKySoType } from '/@/const';

import {
  IBaseGiaoQuyen,
  IInfoNhanQuyen,
  IQdGiaoQuyenPheDuyet,
  IResultPheDuyetGiaoQuyen,
} from './model';
import { BaseApi } from '../baseApi';
import { XlvpEndPoint } from '../apiConst';
import { IResultKySo } from '../common/ky_so';

export class GiaoQuyenApi extends BaseApi<IBaseGiaoQuyen> {
  constructor() {
    super(xlvpHttp, XlvpEndPoint.GiaoQuyen);
  }

  async get<T>(maBieuMauCha: string, maCha: string): Promise<T> {
    return this.http.get<T>({
      url: `${this.url}/${maBieuMauCha}/${maCha}`,
    });
  }

  async print(type: string, code: string) {
    const url = `${this.url}/${type}/${code}/print`;
    return this.http.print({ url: url });
  }

  async update<T>(type: string, code: string, body: T): Promise<T> {
    const res = await this.http.put<T>({
      url: `${this.url}/${type}/${code}`,
      params: body,
    });
    return res as T;
  }

  async delete(type: string, code: string): Promise<Boolean> {
    return await this.http.delete<Boolean>({
      url: `${this.url}/${type}/${code}`,
    });
  }

  async getCanBoNhanQuyen(params: { maBieuMau: string }): Promise<IInfoNhanQuyen[]> {
    return this.http.get<IInfoNhanQuyen[]>({
      url: `${this.url}/can-bo-duoc-giao-quyen`,
      params,
    });
  }

  async pheDuyetGiaoQuyen(body: IQdGiaoQuyenPheDuyet[]) {
    return this.http.put<IResultPheDuyetGiaoQuyen>({
      url: `${this.url}/phe-duyet`,
      params: body,
    });
  }

  async downloadKySo(body: { list: IQdGiaoQuyenPheDuyet[] }) {
    return this.http.downloadFile({
      url: `${this.url}/download-compressed-file`,
      params: body,
      method: 'POST',
    });
  }

  async pheDuyetKySo(type: string, code: string, base64: string) {
    return this.http.post<IResultKySo>({
      url: `${this.url}/phe-duyet/${type}/${code}/ky-so`,
      params: { data: base64 },
    });
  }

  async uploadKySo<T>(file: File, loaiFileEnum: IKySoType) {
    return this.http.uploadFile<T>(
      {
        url: `${this.url}/phe-duyet/ky-so`,
        responseType: 'json',
      },
      {
        file: file,
        data: { loaiFileEnum },
      },
    );
  }
}
