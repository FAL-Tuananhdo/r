import { BaseInfo } from '../types';
import { ILinhVuc, IBbQdStatus } from '../../const';
import { ICanBo } from '../can-bo';

export interface IBaseGiaoQuyen extends BaseInfo {
  ma: string;
  maBieuMau: string;
  thoiGianLap: Date;
  ngayHieuLuc: Date;
  canBoGiaoQuyen: ICanBo;
  canBoNhanQuyen: ICanBo;
  donViThiHanh: string[];
  linhVuc: ILinhVuc;
  tuNgay: Date;
  trangThai: IBbQdStatus;
  denNgay?: Date;
  maDonViCsgt?: string;
  maNhapTay?: string;

  canBoPheDuyet?: ICanBo;
  ngayPheDuyet?: Date;
}

export interface ISearchGiaoQuyen
  extends PartialSearchListQueryParams<
    Pick<
      IBaseGiaoQuyen,
      'ma' | 'maBieuMau' | 'tuNgay' | 'denNgay' | 'maDonViCsgt' | 'trangThai' | 'linhVuc'
    >
  > {
  maNguoiGiaoQuyen?: string;
  maNguoiNhanQuyen?: string;
}

export interface IInfoNhanQuyen
  extends Pick<
    IBaseGiaoQuyen,
    'ma' | 'maBieuMau' | 'thoiGianLap' | 'canBoNhanQuyen' | 'maNhapTay'
  > {
  maNguoiNhanQuyen: string;
}

export type IQdGiaoQuyenPheDuyet = Pick<IBaseGiaoQuyen, 'ma' | 'maBieuMau'>;

export interface IResultPheDuyetGiaoQuyen {
  success: IQdGiaoQuyenPheDuyet[];
  error: IQdGiaoQuyenPheDuyet[];
}
