import { RouteMeta } from 'vue-router';

export interface IChucNang {
  appCode: string;
  isUpdateAccessApi?: boolean;
  status: boolean;
  type: number;
  name: string;
  redirect?: string;
  component: string;
  listAccessApi?: string[];
  path?: string;
  disabled?: boolean;
  meta: RouteMeta;
  parentName?: string;
  children?: IChucNang[];
}

export type IButtonPermission = Pick<IChucNang, 'appCode' | 'name' | 'parentName' | 'status'>;
