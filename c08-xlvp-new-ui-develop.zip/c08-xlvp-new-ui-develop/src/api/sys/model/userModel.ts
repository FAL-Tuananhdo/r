export interface RoleInfo {
  roleName: string;
  value: string;
}

export interface GetUserInfoModel {
  roles: RoleInfo[];
  userId: string | number;
  username: string;
  realName: string;
  avatar: string;
  desc?: string;
}
