export interface CaptchaInfo {
  captchaImage: string;
  captchaSecret: string;
  expirationTime: Number;
}

export interface TokenInfo {
  ufn: string;
  uid: string;
  orgName: string;
  posName: string;
  org: string;
}

export interface LoginParams {
  username: string;
  password: string;
  captchaKey?: string;
  captchaSecret?: string;
}

export interface LoginResult {
  accessToken: string;
  tokenType: string;
}

export interface TOtpResult {
  qrTotp: string;
}
