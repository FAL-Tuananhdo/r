interface IMetaChucNangDto extends Record<string | number | symbol, unknown> {
  redirect?: string;
}

interface IRouteMetaDto extends Record<string | number | symbol, unknown> {
  title: string;
  activeMenu?: string;
  redirect?: string;
}

export interface IChucNangDto {
  appCode: string;
  isUpdateAccessApi: boolean;
  menuCode: string;
  name: string;
  status: number;
  type: number;
  url: string;
  listAccessApi?: string[];
  orderNo?: number;
  parentCode?: string;
  activeMenu?: string;
  menuPath?: string;
  menuIcon?: string;
  hideMenu?: number;
  children?: IChucNangDto[];
  meta?: IMetaChucNangDto;
}

export interface IRouterMenuDto {
  path: string;
  name: string;
  redirect: string;
  component: string;
  hidden: boolean;
  meta: IRouteMetaDto;
  icon?: string;
}

export interface IButtonPermissionDto {
  lstMenu: IChucNangDto[];
  parentCode: string;
}
