import { omit } from 'lodash-es';

import { treeMapEach } from '/@/utils/helper/treeHelper';
import { iamHttp } from '/@/utils/http/axios';

import { AppRouteModule } from './../../router/types';
import { IButtonPermission } from './model';
import { IButtonPermissionDto, IRouterMenuDto } from './dto';

enum Api {
  GetPermission = '/api/auth/cas/get-menu-group-by-parent-code',
  GetMenuList = '/api/auth/cas/menu-parent-child-for-router',
}

export class PhanQuyenUngDungApi {
  async getMenuList(appCode: string): Promise<AppRouteModule[]> {
    const res = await iamHttp.get<IRouterMenuDto[]>({
      url: Api.GetMenuList,
      params: { appCode },
    });
    return res.map<AppRouteModule>((item) =>
      treeMapEach(item, {
        conversion: (route: IRouterMenuDto): AppRouteModule => ({
          path: route.path,
          name: route.name,
          redirect: route.meta.redirect,
          component: route.component,
          meta: {
            ...omit(route.meta, ['redirect', 'activeMenu']),
            currentActiveMenu: route.meta.activeMenu,
            title: route.meta.title,
            icon: route.icon,
            hideMenu: route.hidden,
          },
        }),
      }),
    );
  }

  async getPermission(appCode: string): Promise<IButtonPermission[]> {
    const res = await iamHttp.get<IButtonPermissionDto[]>({
      url: Api.GetPermission,
      params: { appCode, type: 5 },
    });

    return res
      .map((groupBtn) =>
        groupBtn.lstMenu.map(
          (item): IButtonPermission => ({
            appCode: item.appCode,
            name: item.menuCode,
            parentName: item.parentCode,
            status: !!item.status,
          }),
        ),
      )
      .flat();
  }
}
