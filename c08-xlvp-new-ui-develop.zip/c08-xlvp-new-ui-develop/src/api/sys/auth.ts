import { iamHttp } from '/@/utils/http/axios';

import { ErrorMessageMode } from '/#/axios';
import { CaptchaInfo, LoginParams, LoginResult, TokenInfo } from './model/authModel';

enum Api {
  Login = '/api/auth/cas/signin',
  GetTokenInfo = '/api/auth/cas/validate-jose',
  Captcha = '/api/auth/cas/get-captcha',
  Logout = '/api/auth/cas/signout',
}

export class AuthApi {
  async loginApi(params: LoginParams, mode: ErrorMessageMode = 'modal') {
    return iamHttp.post<LoginResult>(
      {
        url: Api.Login,
        params: {
          ...params,
          captchaSecret: '000000',
        } as LoginParams,
      },
      {
        errorMessageMode: mode,
      },
    );
  }

  async logout() {
    return iamHttp.post({ url: Api.Logout });
  }

  async getTokenInfo() {
    return iamHttp.get<TokenInfo>({ url: Api.GetTokenInfo }, { errorMessageMode: 'none' });
  }

  async getCaptcha(mode: ErrorMessageMode = 'message') {
    return iamHttp.get<CaptchaInfo>(
      {
        url: Api.Captcha,
      },
      {
        errorMessageMode: mode,
      },
    );
  }
}
