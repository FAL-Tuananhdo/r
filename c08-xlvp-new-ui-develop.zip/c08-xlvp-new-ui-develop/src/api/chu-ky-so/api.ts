import { xlvpHttp } from '/@/utils/http/axios';

import { XlvpEndPoint } from '../apiConst';
import { IChuKySo } from './model';
import { BaseApi } from '../baseApi';

export class ChuKySoApi extends BaseApi<IChuKySo> {
  constructor() {
    super(xlvpHttp, XlvpEndPoint.ChuKySo);
  }
}
