import { ITrangThaiChuKySo } from '/@/const';

import { BaseInfo } from '../types';

export interface IChuKySo extends BaseInfo {
  ma: number;
  maCanBo: string;
  tenCanBo: string;
  tenChungThu: string;
  nguoiCap: string;
  soSeri: string;
  maDonVi: string;
  hieuLucTu: Date;
  hieuLucDen: Date;
  trangThai: ITrangThaiChuKySo;
}

export interface IThongTinChiTietChuKySo {
  issuerCountry?: string;
  issuerOrgan?: string;
  issuerOU?: string;
  subjectOrgan?: string;
  subjectLocation?: string;
  subjectCountry?: string;
  subjectOU?: string;
  subjectCN: string;
}

export interface IRequestCreateChuKySo
  extends Pick<
    IChuKySo,
    'tenChungThu' | 'nguoiCap' | 'soSeri' | 'hieuLucTu' | 'hieuLucDen' | 'trangThai'
  > {
  publicKey: string;
  thongTinChiTiet: IThongTinChiTietChuKySo;
}

export type IRequestUpdateChuKySo = Pick<IChuKySo, 'tenChungThu' | 'trangThai'>;

export type ISearchChuKySo = PartialSearchListQueryParams<
  Pick<IChuKySo, 'tenChungThu' | 'soSeri' | 'hieuLucTu' | 'hieuLucDen' | 'trangThai'>
>;
