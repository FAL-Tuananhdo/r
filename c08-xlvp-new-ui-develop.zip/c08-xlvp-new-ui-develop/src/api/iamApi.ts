import { CanBoApi } from './can-bo/api';
import { PhanQuyenUngDungApi } from './sys/phan-quyen-ung-dung';
import { AuthApi } from './sys/auth';
import { QuanLyChucNangApi } from './iam/ql-chuc-nang/api';

export class IamApi {
  authApi: AuthApi;
  canBoApi: CanBoApi;
  phanQuyenUngDungApi: PhanQuyenUngDungApi;
  quanLyChucNangApi: QuanLyChucNangApi;

  constructor() {
    this.authApi = new AuthApi();
    this.canBoApi = new CanBoApi();
    this.phanQuyenUngDungApi = new PhanQuyenUngDungApi();
    this.quanLyChucNangApi = new QuanLyChucNangApi();
  }
}
