import qs from 'qs';

import { xlvpHttp } from '/@/utils/http/axios';

import { XlvpEndPoint } from '../apiConst';
import { BaseApi } from '../baseApi';
import { BasePagination } from '../types';
import {
  ILichSuThayDoiVuViec,
  ISearchLichSuVuViec,
  ISearchParamsVuViec,
  ISearchTangVat,
  ISearchTangVatBbQd,
  ISearchVuViecBbQd,
  IVuViec,
  IVuViecBbQd,
} from './model';
import { IPhuongTienViPham, ISearchParamsThongTinPhuongTien } from '../common/phuong-tien-vi-pham';
import { ITangVat, ITangVatVuViec } from '../bb-qd/common/tang-vat-giay-to';
import { ISearchParamsHanhViViPham } from '../common/hanh-vi-vi-pham';

export class VuViecApi extends BaseApi<IVuViec> {
  constructor() {
    super(xlvpHttp, XlvpEndPoint.VuViec);
  }

  async getBbQdByMaVuViec(ma: string, params?: ISearchVuViecBbQd): Promise<IVuViecBbQd[]> {
    return this.http.get<IVuViecBbQd[]>({
      url: `${this.url}/${ma}/bb-qd`,
      params: params,
    });
  }

  async getAll(params?: ISearchParamsVuViec): Promise<BasePagination<IVuViec>> {
    const res = await this.http.get<BasePagination<IVuViec>>({
      url: this.url,
      params: params,
    });
    res.items.forEach((item: IVuViec) => {
      item.bbqd = item.hasChild ? [] : undefined;
    });
    return res;
  }

  async getTangVatBbqd(
    vuViecId: string,
    params?: Partial<ISearchTangVatBbQd>,
  ): Promise<ITangVat[]> {
    const res = await this.http.get<ITangVat[]>({
      url: `${this.url}/${vuViecId}/tang-vat`,
      params: params,
    });
    return res;
  }

  async getTangVat(params?: ISearchTangVat): Promise<ITangVatVuViec[]> {
    const res = await this.http.get<BasePagination<ITangVatVuViec>>({
      url: XlvpEndPoint.TangVat,
      params: params,
      paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });

    return res.items;
  }

  async getThongTinPhuongTien(params: ISearchParamsThongTinPhuongTien): Promise<IPhuongTienViPham> {
    return await this.http.get<IPhuongTienViPham>({
      url: `${this.url}/thong-tin-phuong-tien`,
      params: params,
    });
  }

  async getSoLanViPham(params: ISearchParamsHanhViViPham): Promise<number> {
    return await this.http.get<number>({
      url: '/doi-tuong-vi-pham',
      params: params,
    });
  }

  async getLichSuByMaVuViec(
    maVuViec: string,
    params: ISearchLichSuVuViec,
  ): Promise<BasePagination<ILichSuThayDoiVuViec>> {
    return this.http.get<BasePagination<ILichSuThayDoiVuViec>>({
      url: `${this.url}/${maVuViec}/lich-su`,
      params,
      paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });
  }

  async downloadExcelLichSuVuViec(maVuViec: string, params: ISearchLichSuVuViec) {
    return this.http.downloadFile({
      url: `${this.url}/${maVuViec}/lich-su/export/excel`,
      params,
      paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });
  }
}
