import {
  IBbQdStatus,
  ILinhVuc,
  ILoaiDoiTuongViPham,
  INguonVuViec,
  IVuViecStatus,
  ILoaiHanhDong,
  ITrangThaiTangVat,
} from '/@/const';

import { ICanBo } from './../can-bo/model';
import { IPhuongTienViPham } from '../common';
import { INguoiViPham, IToChucViPham } from '../common/doi-tuong-vi-pham';
import { BaseInfo, IBaseSearchListQueryParams } from '../types';
import { IHanhViViPham } from '../common/hanh-vi-vi-pham';
import { IBbQd } from '../bb-qd/model';
import { ITangVatVuViec } from '../bb-qd/common/tang-vat-giay-to';

export interface IVuViec extends BaseInfo {
  ma: string;
  thoiGianLap: Date;
  loaiDoiTuong: ILoaiDoiTuongViPham;
  linhVuc: ILinhVuc;
  thoiGianVp: Date;
  diaDiemVp: string;
  doiTuongViPham: INguoiViPham | IToChucViPham;
  hanhViViPham: IHanhViViPham[];
  phuongTien?: Nullable<IPhuongTienViPham>;
  maDonViCsgt?: string;
  trangThai: IVuViecStatus;
  ten?: string;
  nguon?: INguonVuViec;
  bbqd?: IVuViecBbQd[];
  children?: string[];
  hasChild: boolean;
}

export interface IRequestBodyVuViec
  extends Omit<IVuViec, 'ma' | 'ten' | 'trangThai' | 'maDonViCsgt' | 'thoiGianLap' | 'thoiGianVp'> {
  thoiGianLap: Date;
  thoiGianVp: Date;
  ma?: string;
  ten?: string;
}

export interface ISearchParamsVuViec
  extends PartialSearchListQueryParams<
    Pick<IVuViec, 'ma' | 'ten' | 'maDonViCsgt' | 'trangThai' | 'linhVuc'>
  > {
  dinhDanhDtvp?: string;
  tenDtvp?: string;
  bienSo?: string;
  tuNgay?: Date;
  denNgay?: Date;
}

export interface IVuViecBbQd
  extends Pick<
      IBbQd,
      | 'ma'
      | 'tenBieuMau'
      | 'trangThai'
      | 'hasChild'
      | 'maVuViec'
      | 'maCha'
      | 'maBieuMauCha'
      | 'maNhapTay'
      | 'thoiGianLap'
      | 'nguon'
    >,
    BaseInfo {
  maBieuMau: string;
}

export interface ILichSuThayDoiVuViec {
  ma: string;
  loai: ILoaiHanhDong;
  chiTiet: string;
  noiDungCu?: DeepPartial<IVuViec>;
  noiDungMoi?: DeepPartial<IVuViec>;
  nguoiSua: string;
  canBoSua: ICanBo;
  ngaySua: Date;
}

export interface ISearchVuViecBbQd {
  ma?: string;
  maCha?: string;
  maBieuMauCha?: string;
  trangThai?: IBbQdStatus;
}

export interface ISearchTangVatBbQd {
  maBbqdCha: string;
  mauBbqdCha: string;
  daTraLai: boolean;
  trangThai: string;
}

export interface ISearchTangVat
  extends PartialSearchListQueryParams<
    Pick<ITangVatVuViec, 'ma' | 'maVuViec' | 'maBBQD' | 'maBieuMau'>
  > {
  so?: string;
  bienSo?: string;
  soDangKy?: string;
  trangThai?: ITrangThaiTangVat[];
  hang?: string[];
}

export interface ISearchLichSuVuViec extends IBaseSearchListQueryParams {
  loai?: ILoaiHanhDong[];
}
