import { xlvpHttp } from '/@/utils/http/axios';

import {
  IPhuongTienViPham,
  ISearchParamsThongTinPhuongTien,
} from '../../common/phuong-tien-vi-pham';
import { DanhMucDungChungEndPoint } from '../../apiConst';

export class PhuongTienViPhamApi {
  http = xlvpHttp;
  url = DanhMucDungChungEndPoint.PhuongTien;

  async getThongTinPhuongTien(params: ISearchParamsThongTinPhuongTien): Promise<IPhuongTienViPham> {
    return await this.http.get<IPhuongTienViPham>({
      url: `${this.url}/thong-tin`,
      params: params,
    });
  }
}
