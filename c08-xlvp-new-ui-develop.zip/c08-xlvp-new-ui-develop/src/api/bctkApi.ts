import { BcSlGiayToPhuongTien } from './bao-cao-thong-ke/sl-giay-to-phuong-tien/api';
import { BaoCaoThongKeApi } from '/@/api/bao-cao-thong-ke/api';
import { BctkSoLieu } from './bao-cao-thong-ke/so-lieu/api';
import { BctkVuViecApi } from '/@/api/bao-cao-thong-ke/vu-viec/api';
import { BctkBaoCaoTongHopApi } from '/@/api/bao-cao-thong-ke/bao-cao-tong-hop/api';
import { BcPhatNguoi } from './bao-cao-thong-ke/phat-nguoi/api';
import { TraCuuLichSuChapHanhApi } from '/@/api/tra-cuu/lich-su-chap-hanh/api';
import { BctkViPhamHanhChinhApi } from '/@/api/bao-cao-thong-ke/vi-pham-hanh-chinh/api';
import { DanhMucHanhViViPhamApi } from '/@/api/bao-cao-thong-ke/nhom-hanh-vi-vi-pham/api';
import { PhuongTienViPhamApi } from '/@/api/bao-cao-thong-ke/phuong-tien/api';
import { hanhViViPhamApi } from '/@/api/bao-cao-thong-ke/bao-cao-tong-hop/hanh-vi-vi-pham/api';
import { BctkA19 } from '/@/api/bao-cao-thong-ke/bao-cao-a19/api';
import { BctkDongBoDmApi } from '/@/api/bao-cao-thong-ke/dong-bo-danh-muc/api';
import { TrangChuApi } from '/@/api/trang-chu/api';

export class BctkApi {
  baoCaoThongKeApi: BaoCaoThongKeApi;
  bctkDongBoDmApi: BctkDongBoDmApi;

  /*DatNT*/
  // bctkThongKeApi: BctkThongKe;
  bctkBaoCaoTongHopApi: BctkBaoCaoTongHopApi;
  hanhViViPhamApi: hanhViViPhamApi;
  /*DatNT*/

  // Datdt
  bctkA19Api: BctkA19;
  bctkSolieuApi: BctkSoLieu;
  danhMucHanhViViPhamApi: DanhMucHanhViViPhamApi;
  phuongTienViPhamApi: PhuongTienViPhamApi;
  // Datdt

  /*AnhDT*/
  bctkViPhamHanhChinhApi: BctkViPhamHanhChinhApi;
  /*AnhDT*/

  /*DuyDM*/
  bctkSlPhuongTienGiayToApi: BcSlGiayToPhuongTien;
  bcPhatNguoiToApi: BcPhatNguoi;
  /*DuyDM*/

  /*DucNm*/
  bctkVuViecApi: BctkVuViecApi;
  traCuuLichSuChapHanhApi: TraCuuLichSuChapHanhApi;
  /*DucNm*/

  trangChuApi: TrangChuApi;

  constructor() {
    this.baoCaoThongKeApi = new BaoCaoThongKeApi();
    this.bctkDongBoDmApi = new BctkDongBoDmApi();

    /*DatNT*/
    // this.bctkThongKeApi = new BctkThongKe();
    this.bctkBaoCaoTongHopApi = new BctkBaoCaoTongHopApi();
    this.hanhViViPhamApi = new hanhViViPhamApi();

    /*DatNT*/

    /*DuyDM*/
    this.bctkSlPhuongTienGiayToApi = new BcSlGiayToPhuongTien();
    this.bcPhatNguoiToApi = new BcPhatNguoi();
    /*DuyDM*/

    /*AnhDT*/
    this.bctkViPhamHanhChinhApi = new BctkViPhamHanhChinhApi();
    /*AnhDT*/

    // Datdt
    this.bctkA19Api = new BctkA19();
    this.bctkSolieuApi = new BctkSoLieu();
    this.danhMucHanhViViPhamApi = new DanhMucHanhViViPhamApi();
    this.phuongTienViPhamApi = new PhuongTienViPhamApi();
    // Datdt

    /*DucNm*/
    this.bctkVuViecApi = new BctkVuViecApi();
    this.traCuuLichSuChapHanhApi = new TraCuuLichSuChapHanhApi();
    /*DucNm*/

    this.trangChuApi = new TrangChuApi();
  }
}
