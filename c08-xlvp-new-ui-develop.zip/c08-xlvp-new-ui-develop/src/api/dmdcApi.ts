import { DiaDanhHanhChinhApi } from './danh-muc-dung-chung/dia-danh-hanh-chinh/api';
import { DonViCsgtApi } from './danh-muc-dung-chung/don-vi/api';
import { PhuongTienApi } from './danh-muc-dung-chung/phuong-tien/api';
import { DanhMucTongHopApi } from './danh-muc-dung-chung/danh-muc-tong-hop/api';
import { QuocGiaApi } from './danh-muc-dung-chung/quoc-gia/api';
import { MauBienSoApi } from './danh-muc-dung-chung/mau-bien-so/api';
import { CapBacApi } from './danh-muc-dung-chung/cap-bac/api';
import { ChucVuApi } from './danh-muc-dung-chung/chuc-vu/api';
import { NgayNghiApi } from './danh-muc-dung-chung/ngay-nghi/api';
import { NoiTamGiuApi } from './danh-muc-dung-chung/noi-tam-giu/api';

export class DanhMucDungChungApi {
  ddhcApi: DiaDanhHanhChinhApi;
  donViCsgtApi: DonViCsgtApi;
  phuongTienApi: PhuongTienApi;
  danhMucTongHopApi: DanhMucTongHopApi;
  quocGiaApi: QuocGiaApi;
  mauBienSoApi: MauBienSoApi;
  capBacApi: CapBacApi;
  chucVuApi: ChucVuApi;
  ngayNghiApi: NgayNghiApi;
  noiTamGiuApi: NoiTamGiuApi;

  constructor() {
    this.mauBienSoApi = new MauBienSoApi();
    this.ddhcApi = new DiaDanhHanhChinhApi();
    this.donViCsgtApi = new DonViCsgtApi();
    this.phuongTienApi = new PhuongTienApi();
    this.danhMucTongHopApi = new DanhMucTongHopApi();
    this.quocGiaApi = new QuocGiaApi();
    this.capBacApi = new CapBacApi();
    this.chucVuApi = new ChucVuApi();
    this.ngayNghiApi = new NgayNghiApi();
    this.noiTamGiuApi = new NoiTamGiuApi();
  }
}
