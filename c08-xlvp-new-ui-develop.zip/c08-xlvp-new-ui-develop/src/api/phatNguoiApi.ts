import { PhatNguoiApi } from './phat-nguoi/thong-tin/api';
import { DanhMucPhatNguoiApi } from './phat-nguoi/danh-muc/api';

export class XuLyPhatNguoiApi {
  phatNguoiApi: PhatNguoiApi;
  danhMucPhatNguoiApi: DanhMucPhatNguoiApi;

  constructor() {
    this.phatNguoiApi = new PhatNguoiApi();
    this.danhMucPhatNguoiApi = new DanhMucPhatNguoiApi();
  }
}
