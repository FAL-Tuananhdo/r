import qs from 'qs';

import { phatNguoiHttp } from '/@/utils/http/axios';
import { IKySoType, IMediaType } from '/@/const';

import { PhatNguoiEndPoint } from '../../apiConst';
import { BaseApi } from '../../baseApi';
import {
  IPhatNguoi,
  ImportExcel,
  ISearchPhatNguoi,
  IPreviewImg,
  IUploadKySo,
  ISearchPhatNguoiTaoBienBan,
} from './model';
import { IBbQd } from '../../bb-qd/model';
import { IResultKySo } from '../../common/ky_so';

export class PhatNguoiApi extends BaseApi<IPhatNguoi> {
  constructor() {
    super(phatNguoiHttp, PhatNguoiEndPoint.PhatNguoi);
  }

  async updateTrangThaiHienTai(
    ma: string,
    body: { lyDoChuyen: number; lyDoBoSung: string },
  ): Promise<boolean> {
    return this.http.put<boolean>({
      url: `${this.url}/trang-thai-hien-tai/${ma}`,
      params: body,
    });
  }

  async updateTrangThaiPhatNguoi(ma: string, body: { loaiTrangThai: string }): Promise<boolean> {
    return this.http.put<boolean>({
      url: `${this.url}/chuyen-trang-thai/${ma}`,
      params: body,
    });
  }

  async uploadFile<T>(file: File, loaiFileEnum: IMediaType) {
    return this.http.uploadFile<T>(
      {
        url: `${this.url}/object-storage`,
        responseType: 'json',
      },
      {
        file: file,
        data: {
          ['loaiFileEnum']: loaiFileEnum,
        },
      },
    );
  }

  async uploadExcel<T>(body: ImportExcel) {
    return this.http.uploadFile<T>(
      {
        url: `${this.url}/import-excel`,
        responseType: 'blob',
      },
      {
        file: body.file,
        data: {
          username: body.username,
          idDonViPhatHienVp: body.idDonViPhatHienVp,
          tenDonViPhatHienVp: body.tenDonViPhatHienVp,
          linhVuc: body.linhVuc,
        },
      },
      { isReturnNativeResponse: true },
    );
  }

  async printListPhieuChuyen(params: { ma: string | string[] }) {
    const url = `${this.url}/in-mau/phieu-chuyen`;
    return this.http.print({ url: url, params: params });
  }

  async printPhieuChuyen(params: { ma: string | string[] }) {
    const url = `${this.url}/in-mau/${params.ma}/phieu-chuyen`;
    return this.http.print({ url: url });
  }

  async printThongBao(params: { ma: string | string[] }) {
    const url = `${this.url}/in-mau/thong-bao`;
    return this.http.print({ url: url, params: params });
  }

  async exportExcel(params: ISearchPhatNguoi): Promise<void> {
    phatNguoiHttp.downloadFile({
      url: `${this.url}/export-excel`,
      params: params,
    });
  }

  async downloadFileMau(): Promise<void> {
    phatNguoiHttp.downloadFile({
      url: `${this.url}/import-excel/download-file-mau`,
    });
  }

  async getImage(ma: string): Promise<IPreviewImg> {
    return this.http.get<IPreviewImg>({
      url: `${this.url}/hinh-anh/${ma}`,
    });
  }

  async updateMaVuViec(id: string, maVuViec: string): Promise<boolean> {
    return this.http.put<boolean>({
      url: `${this.url}/ma-vu-viec/${id}/${maVuViec}`,
    });
  }

  async createBbQd<P>(body: P): Promise<IBbQd> {
    return this.http.post<IBbQd>({
      url: `${this.url}/bb-qd`,
      params: body,
    });
  }

  async deleteBbQd(type: string, code: string): Promise<Boolean> {
    return this.http.delete<Boolean>({
      url: `${this.url}/bb-qd/${type}/${code}`,
    });
  }

  async pheDuyetKySo(ma: string, base64: string) {
    return this.http.post<IResultKySo>({
      url: `${this.url}/${ma}/ky-so`,
      params: { data: base64 },
    });
  }

  async uploadKySo(file: File, loaiFileEnum: IKySoType) {
    return this.http.uploadFile<IUploadKySo>(
      {
        url: `${this.url}/ky-so`,
        responseType: 'json',
      },
      {
        file: file,
        data: {
          loaiFileEnum: loaiFileEnum,
        },
      },
    );
  }

  async downloadKySo(params: { ma: string }) {
    return this.http.downloadFile({
      url: `${this.url}/in-mau/download-compressed-file`,
      params: params,
    });
  }

  async getAllTaoBienBan(params: ISearchPhatNguoiTaoBienBan): Promise<IPhatNguoi> {
    return this.http.get({
      url: `${this.url}/merge-vu-viec`,
      params: params,
    });
  }

  async getThongTinBienBan(body: { listMa: string[] }) {
    return this.http.get({
      url: `${this.url}/tt-tao-bb`,
      params: body,
      paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });
  }
}
