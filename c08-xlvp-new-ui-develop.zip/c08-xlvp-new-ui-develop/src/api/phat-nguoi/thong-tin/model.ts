import { ILinhVuc } from '/@/const/type';
import { ILoaiDoiTuongViPham } from '/@/const';

import { BaseInfo } from '../../types';
import { INguoiViPham, IToChucViPham, IDiaBanViPham } from '../../common';
import { ITrangThai } from '../danh-muc/model';

export interface IPhatNguoi extends BaseInfo {
  ma: string;
  thongTinChung: IThongTinChung;
  doiTuongViPham: INguoiViPhamPhatNguoi | ITenToChucViPhamPhatNguoi;
  hanhViViPham: IThongTinHanhViViPham;
  phuongTien: IPhuongTienViPhamPhatNguoi;
  thamQuyenKy: IThamQuyenKy;
  trangThaiHienTai: ITrangThai;
  trangThaiDangKiem: ITrangThai;
  trangThaiKySo: ITrangThai;
  listHanhViViPham: IHanhViViPham[];
  trangThaiTiepNhan: ITrangThai;
  maVuViec: string;
  vuViec?: number;
  bienSo?: string;
  tenNguoiViPham?: string;
  tenNguoiSua?: string;
  hasChild?: boolean;
}
export interface INguoiViPhamPhatNguoi extends Partial<Omit<INguoiViPham, 'ten' | 'diaChi'>> {
  tenNvp: string;
  loaiDoiTuongViPham: ILoaiDoiTuongViPham;
  diaChiNvpChiTiet?: string;
  maDiaChiNvp?: string;
}

export interface ITenToChucViPhamPhatNguoi
  extends Omit<
    IToChucViPham,
    | 'chucDanhNguoiDaiDien'
    | 'maSoDn'
    | 'soGcn'
    | 'noiCap'
    | 'gioiTinhNguoiDaiDien'
    | 'ngayCap'
    | 'ten'
  > {
  tenToChuc: string;
  loaiDoiTuongViPham: ILoaiDoiTuongViPham;
  chucDanhNguoiDaiDien?: string;
  maSoDn?: string;
  soGcn?: string;
  noiCap?: string;
  ngayCapSoGcn?: Date;
  gioiTinhNguoiDaiDien?: number;
  diaChiChiTietToChuc?: string;
  maDiaDanhToChuc?: string;
}

export interface IUpload {
  linkFile: string;
  nameFile: string;
  sizeFile: number;
  loaiFile: string;
  tailFile: string;
  dateFolder: string;
  status?: string;
  linkFileTemporary: string;
  url?: string;
}

export interface IThongTinChung {
  linhVuc: ILinhVuc;
  kyHieu: string;
  ngayTaoThongBao: Date;
  maDvcsgtPhatHien: string;
  thoiGianHenGiaiQuyetTaiDonViPh: Date;
  noiDungHanhViVp: string;
  ma?: string;
  tenVuViecPn?: string;
  soThongBao?: string;
  diaChiDonViPhatHien?: string;
  maDvcsgtTiepNhan?: string;
  thoiGianHenGiaiQuyetTaiDonViTn?: Date;
  diaChiDonViTiepNhan?: string;
  bienPhapNganChan?: string;
  maTrangThaiHienTai?: number;
}

export interface IThamQuyenKy {
  donVi: string;
  hoTenCanBoKy: string;
  capBacCanBoKy: string;
  chucVuCanBoKy: string;
}

export interface IThongTinHanhViViPham {
  thoiGianVp: Date;
  maThietBiPhatHien?: string;
  loaiDiaDiemViPham: string;
  maHVVP?: string;
  maTuyenDuongQuocLo: string;
  tenTuyenDuongQuocLo?: string;
  maPhuongXa?: string;
  viTri?: string;
  diaChiHvvp?: string;
  danhSachHvvp: {
    maTTND: string;
    maHVVP: string;
    dieu?: string;
    khoan?: string;
    diem?: string;
    noiDungThongTuNghiDinh?: string;
  }[];
}

export interface IPhuongTienViPhamPhatNguoi {
  soDangKy?: string;
  maLoaiPhuongTien: string;
  tenLoaiPhuongTien?: string;
  bienKiemSoat: string;
  maMauBien: string;
  tenMauBien?: string;
  tenChuPhuongTien: string;
  diaChiChuPhuongTien?: string;
  ngayCapChuPhuongTien: Date;
  noiCapChuPhuongTien: string;
  dungTich?: string;
  maDiaDanhHanhChinh: string;
  bienKiemSoatThu2?: string;
  nhanHieu?: string;
  mauSon?: string;
  soLoai?: string;
  traCuuC06?: number;
}

export interface ITenToChucViPhamPhatNguoi
  extends Omit<
    IToChucViPham,
    'chucDanhNguoiDaiDien' | 'maSoDn' | 'soGcn' | 'noiCap' | 'gioiTinhNguoiDaiDien'
  > {
  chucDanhNguoiDaiDien?: string;
  maSoDn?: string;
  soGcn?: string;
  noiCap?: string;
  gioiTinhNguoiDaiDien?: number;
}

export interface ImportExcel {
  file: File;
  username: string;
  idDonViPhatHienVp: string;
  tenDonViPhatHienVp: string;
  linhVuc: string;
}

export type IDoiTuongViPham = (INguoiViPhamPhatNguoi | ITenToChucViPhamPhatNguoi) & {
  loaiDoiTuongViPham: ILoaiDoiTuongViPham;
};
export interface ISearchPhatNguoi
  extends PartialSearchListQueryParams<Pick<IPhatNguoi, 'tenNguoiViPham' | 'bienSo' | 'vuViec'>> {
  isDefault: boolean;
  ngayViPhamTu?: Date;
  ngayViPhamDen?: Date;
  ngayGui?: Date;
  trangThaiKySo?: string;
  trangThaiDangKiem?: ITrangThai;
  maTrangThaiTiepNhan?: string;
  trangThaiGui?: string;
  trangThai?: string;
  maLoaiPhuongTien?: string;
  maDVPhatHien?: string;
  maDVTiepNhan?: string;
  isLoaiDanhSach?: number;
}

export interface IDiaChiViPham
  extends Pick<IDiaBanViPham, 'maPhuongXa' | 'maQuanHuyen' | 'maTinhThanh'>,
    Pick<IThongTinHanhViViPham, 'viTri' | 'maTuyenDuongQuocLo'> {
  diaChiChiTiet?: string;
}

export interface IPreviewImg
  extends Pick<
      IPhuongTienViPhamPhatNguoi,
      'maMauBien' | 'tenChuPhuongTien' | 'maLoaiPhuongTien' | 'diaChiChuPhuongTien' | 'bienKiemSoat'
    >,
    Partial<IDiaChiViPham> {
  listMedia: IUpload[];
  thoiGianViPham: Date;
}

export interface IHanhViViPham extends Pick<IThongTinHanhViViPham, 'maHVVP'> {
  noiDungThongTuNghiDinh?: string;
}

export interface IUploadKySo {
  details: {
    fileName: string;
    message: string;
  };
  totalFailed: number;
  totalSuccess: number;
}

export interface ISearchPhatNguoiTaoBienBan
  extends Pick<
    ISearchPhatNguoi,
    'tenNguoiViPham' | 'bienSo' | 'maDVPhatHien' | 'maDVTiepNhan' | 'ngayViPhamDen' | 'ngayViPhamTu'
  > {
  maMauBien?: string;
}
