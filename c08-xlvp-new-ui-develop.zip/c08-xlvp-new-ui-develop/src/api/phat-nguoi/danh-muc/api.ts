import { phatNguoiHttp } from '/@/utils/http/axios';

import { PhatNguoiEndPoint } from '../../apiConst';
import { IDanhMucPhatNguoi } from './model';

export class DanhMucPhatNguoiApi {
  async getAll(): Promise<IDanhMucPhatNguoi> {
    return await phatNguoiHttp.get<IDanhMucPhatNguoi>({
      url: `${PhatNguoiEndPoint.DanhMuc}/trang-thai`,
    });
  }
}
