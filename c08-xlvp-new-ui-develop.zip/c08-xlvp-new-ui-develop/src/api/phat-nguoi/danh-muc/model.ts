export interface ITrangThai {
  ma: number;
  ten: string;
}

export interface IDanhMucPhatNguoi {
  lyDoChuyenTrangThai: ITrangThai[];
  trangThaiDangKiem: ITrangThai[];
  trangThaiGui: ITrangThai[];
  trangThaiHienTai: ITrangThai[];
  trangThaiHienTaiPc: ITrangThai[];
  trangThaiKySo: ITrangThai[];
  trangThaiTiepNhan: ITrangThai[];
}
