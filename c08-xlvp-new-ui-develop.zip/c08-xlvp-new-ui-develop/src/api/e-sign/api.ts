import { eSignHttp } from '/@/utils/http/axios';

import { IEsign, IEsignResponse, ICertificateInfo } from './model';
import { EsignEndPoint } from '../apiConst';

export class ESignApi {
  async sign(data: IEsign): Promise<IEsignResponse> {
    return eSignHttp.post({
      url: EsignEndPoint.SignPdf,
      data,
    });
  }

  async getListCertInToken(data: { pin: string }): Promise<ICertificateInfo[] | undefined> {
    const res = await eSignHttp.post(
      {
        url: EsignEndPoint.GetCertInToken,
        data,
      },
      {
        errorMessageMode: 'none',
      },
    );
    return res.result;
  }
}
