/*
1 văn thư ký văn bản mới, chữ ký lãnh đạo (Dạng ảnh theo NĐ 30/2020)
2 ký sao y
3 ký sao lục
4 ký trích sao
5 ký phụ lục
*/
export type ILoaiKy = 1 | 2 | 3 | 4 | 5;

export interface IEsign {
  dataSign: string;
  X: number;
  Y: number;
  w: number;
  h: number;
  page: number;
  mode?: ILoaiKy;
}

export interface IEsignResponse {
  result: string;
}

export interface ICertificateInfo {
  listCertData?: ICertData[];
  serialNumber: string;
  subjectOrgan?: string;
  issuerOrgan?: string;
  validFrom: Date;
  validTo: Date;
  cert?: {
    type: string;
  };
  issuerCN?: string;
  rfc822Email?: string;
  issuerCountry?: string;
  subjectLocation?: string;
  subjectCountry?: string;
  subjectOU?: string;
  subjectCN: string;
  issuerOU?: string;
  purposeUsage?: string;
}

export interface ICertData {
  extension: boolean;
  name: string;
  value: string;
  extensionValue?: string;
}
