import {
  IBbQdStatus,
  ILinhVuc,
  ILoaiBieuMau,
  INguonBbQd,
  INguonQuyetDinhXPHC,
  ILoaiHanhDong,
} from '/@/const/type';

import { BaseInfo, IBaseSearchListQueryParams } from '../types';
import { IVuViec } from '../vu-viec/model';
import { ICanBo } from '../can-bo';

export type IVuViecInfo = Pick<
  IVuViec,
  'ma' | 'ten' | 'loaiDoiTuong' | 'phuongTien' | 'doiTuongViPham' | 'nguon' | 'linhVuc'
>;

export interface IBbQd extends BaseInfo {
  ma: string;
  maBieuMau: string;
  maVuViec: string;
  trangThai: IBbQdStatus;
  vuViec: IVuViecInfo;
  thoiGianLap: Date;
  tenBieuMau?: string;
  maDonViCsgt?: string;
  diaDiemLap?: string;
  maCha?: string;
  maBieuMauCha?: string;
  maNhapTay?: string;
  tuNgay?: Date;
  denNgay?: Date;
  hasChild?: boolean;
  children?: IBbQd[];
  nguon?: INguonQuyetDinhXPHC;
}

export interface ISearchParamsBbQd
  extends PartialSearchListQueryParams<
    Pick<
      IBbQd,
      'ma' | 'maVuViec' | 'maBieuMau' | 'maDonViCsgt' | 'trangThai' | 'maCha' | 'maBieuMauCha'
    >
  > {
  bienSo?: string;
  soDinhDanh?: string;
  tenDoiTuongViPham?: string;
  tuNgay?: Date;
  denNgay?: Date;
  loaiBieuMau?: ILoaiBieuMau;
  nguonBBQD?: INguonBbQd;
}

export interface IQdPheDuyet
  extends Pick<
    IBbQd,
    | 'ma'
    | 'maBieuMau'
    | 'maNhapTay'
    | 'tenBieuMau'
    | 'trangThai'
    | 'thoiGianLap'
    | 'canBoTao'
    | 'canBoSua'
    | 'ngayTao'
    | 'ngaySua'
  > {
  canBoPheDuyet?: ICanBo;
  bienSo?: string;
  bienSo2?: string;
  soDinhDanh?: string;
  tenDoiTuongViPham?: string;
  ngayPheDuyet?: Date;
}

export interface ISearchParamsQdPheDuyet
  extends PartialSearchListQueryParams<
    Pick<
      IQdPheDuyet,
      'ma' | 'maBieuMau' | 'trangThai' | 'bienSo' | 'soDinhDanh' | 'tenDoiTuongViPham'
    >
  > {
  linhVuc: ILinhVuc;

  maDonViCsgt?: string;
  tuNgay?: Date;
  denNgay?: Date;
  loaiBieuMau?: ILoaiBieuMau;
  isChuKySo?: boolean;
  nguonBBQD?: INguonBbQd;
  canApproval?: boolean;
}

export type IPheDuyetQuyetDinh = Pick<IBbQd, 'ma' | 'maBieuMau'>;
export interface IResultPheDuyetBbQd {
  success: IPheDuyetQuyetDinh[];
  error: IPheDuyetQuyetDinh[];
}

export interface ILIchSuThayDoiBbQd {
  ma: string;
  loai: ILoaiHanhDong;
  chiTiet: string;
  trangThaiCu: IBbQdStatus;
  trangThaiMoi: IBbQdStatus;
  oldData: DeepPartial<IVuViec>;
  newData: DeepPartial<IVuViec>;
  nguoiSua: string;
  canBoSua: ICanBo;
  ngaySua: Date;
}

export interface ISearchLichSuBbQd extends IBaseSearchListQueryParams {
  loai?: ILoaiHanhDong[];
}
