import { IThoiHan } from '/@/const/type';

import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ITangVat } from '../common/tang-vat-giay-to';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd21 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDo: string;
  thoiHan: IThoiHan;
  giaoCho: IGiaoCho;
  nhanThongBao?: string;
}

export interface IQd21 extends Omit<IBbQd, 'tuNgay'> {
  tuNgay: Date;
  noiDung: INoiDungQd21;
  tangVat?: ITangVat[];
}

export type ICreateRequestBodyQd21 = Omit<IQd21, 'ma' | 'trangThai' | 'vuViec'>;
export type IUpdateRequestBodyQd21 = Omit<ICreateRequestBodyQd21, 'maBieuMau' | 'maVuViec'>;
