import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';

export interface IQd40 extends IBbQd {
  noiDung: INoiDungQd40;
  thoiGianLap: Date;
}

export interface INoiDungQd40 {
  nguoiCoThamQuyen: ICanBo;
  lyDo: string;
  giaoCho: IGiaoCho;
  donViDeNghi: IXetDeNghi;
  canCu?: ICanCuQd40;
}

export interface IXetDeNghi {
  maDonViCsgt: string;
  maChucVu: string;
}

export type IRequestBodyCreateQd40 = Pick<
  IQd40,
  'maBieuMau' | 'maVuViec' | 'noiDung' | 'thoiGianLap' | 'ma' | 'maCha' | 'maBieuMauCha' | 'tuNgay'
>;

export type IRequestBodyUpdateQd40 = Pick<IQd40, 'noiDung' | 'thoiGianLap' | 'tuNgay'>;

export type ICanCuQd40 = Pick<ICanCu, 'qdGiaoQuyen'>;
