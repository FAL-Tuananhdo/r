import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { ITaiLieuBbQd } from '../common/bbqd-lien-quan';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';

export type IGiaoChoQd41 = Pick<IGiaoCho, 'thucHien'>;

interface IDoiTuongTcGd {
  ten: string;
  diaChi: string;
}
interface IThongTinGiamDinh {
  doiTuong: string;
  noiDung: string;
  thoiGian: Date;
}

export interface INoiDungQd41 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  giaoCho: IGiaoChoQd41;
  doiTuongTcGd: IDoiTuongTcGd;
  thongTinGiamDinh: IThongTinGiamDinh;
  taiLieuKemTheo: ITaiLieuBbQd;
}
export interface IQd41 extends IBbQd {
  noiDung: INoiDungQd41;
}

export interface IRequestCreateBodyQd41
  extends Pick<IQd41, 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'noiDung'> {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestUpdateBodyQd41 = Pick<IQd41, 'thoiGianLap' | 'noiDung'>;
