import { IThoiHan } from '/@/const/type';

import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IThongTinXacMinh } from '../common/thong-tin-xac-minh';

export interface INoiDungQd07 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  soTienKhauTru: number[];
  nopPhat: IThongTinNopPhatQd07;
  giaoCho: IGiaoChoQd07;
  thongTinXacMinh: IThongTinXacMinh[];
  soTienPhat: number;
  donViThucHienBpkp?: string;
}

export type IGiaoChoQd07 = Omit<IGiaoCho, 'nguoiNhan'>;

export interface IThongTinNopPhatQd07 {
  stk: string;
  ma: string;
  thoiHanNopPhat: number;
  thoiHan?: IThoiHan;
}

export interface IQd07 extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd07;
  tuNgay: Date;
}

export type ICreateRequestBodyQd07 = Pick<
  IQd07,
  'noiDung' | 'tuNgay' | 'maVuViec' | 'maCha' | 'maBieuMauCha' | 'thoiGianLap' | 'maBieuMau'
>;
export type IUpdateRequestBodyQd07 = Pick<
  ICreateRequestBodyQd07,
  'noiDung' | 'tuNgay' | 'thoiGianLap'
>;
