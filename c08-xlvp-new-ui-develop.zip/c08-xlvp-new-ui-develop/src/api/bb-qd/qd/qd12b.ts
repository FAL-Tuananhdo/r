import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho, IBienPhapKPHQ, IThucHienHoanTraKinhPhi, IThongTinPhoiHop } from './base';

interface IThucHienHoanTraKinhPhiQd12b extends IThucHienHoanTraKinhPhi {
  donViPhoiHop: string;
  diaDiem: string;
}

export interface INoiDungQd12b {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDoCuThe: string;
  thongTinKeBien: IThongTinPhoiHop;
  giaoCho: IGiaoCho;
  bienPhapKhacPhuc: IBienPhapKPHQ[];
  kinhPhiKhacPhucHauQua: IThucHienHoanTraKinhPhiQd12b;
  soTienPhat?: number;
  donViThucHienBpkp?: string;
}

export interface IQd12b extends Omit<IBbQd, 'tuNgay' | 'thoiGianLap'> {
  tuNgay: Date;
  thoiGianLap: Date;
  noiDung: INoiDungQd12b;
}

export type ICreateRequestBodyQd12b = Pick<
  IQd12b,
  'maVuViec' | 'maBieuMau' | 'maCha' | 'maBieuMauCha' | 'thoiGianLap' | 'noiDung' | 'tuNgay'
>;

export type IUpdateRequestBodyQd12b = Pick<
  ICreateRequestBodyQd12b,
  'noiDung' | 'thoiGianLap' | 'tuNgay'
>;
