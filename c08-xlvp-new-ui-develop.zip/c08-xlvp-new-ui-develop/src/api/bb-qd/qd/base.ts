import { ILoaiThayDoi, IThoiHan } from '/@/const/type';

export interface IKhacPhucHauQua {
  isKhacPhuc: boolean;
  lyDo?: string;
  bienPhap?: string;
  cuThe?: string;
  thoiHan?: IThoiHan;
  noiDung?: string;
  kinhPhi?: number;
  thucHien?: string;
}

export interface INopPhat {
  ma?: string;
  thoiHan?: IThoiHan;
  stk?: string;
}

export interface IGiaoCho {
  nguoiNhan: string;
  thucHien: string;
  khieuNai?: string;
  lienQuan?: string;
}

export interface IDonViDeNghi {
  maDonViCsgt?: string;
  maChucVu?: string;
}

export interface IBienPhapKPHQ {
  hauQua?: string;
  bienPhap?: string;
  thoiHan?: IThoiHan;
}

export interface IThucHienHoanTraKinhPhi {
  soTien: number;
  donViThucHien: string;
  donViPhoiHop?: string;
  diaDiem?: string;
}

export interface IThongTinPhoiHop {
  diaDiem: string;
  toChucPhoiHop: string;
  thoiHan: IThoiHan;
}

export interface INguoiGiamHo {
  loai: string;
  ten: string;
  diaChi: string;
}

export interface INoiDungThayDoiHvvp {
  loai: ILoaiThayDoi;
  maHanhViViPhamMoi: string;
  maHanhViViPhamCu: string;
}
