import { INoiDungChiTiet } from '/@/const';

import { IGiaoCho, IKhacPhucHauQua, INopPhat } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { IHanhViViPham } from '../../common/hanh-vi-vi-pham';
import { ICanCu, IQdGiaoQuyen } from '../common/can-cu';
import { IChiTietHpBs, IListHinhThucXuPhat } from '../common/hinh-thuc-xu-phat';
import { IThongBaoQuyetDinh } from '../common/thong-bao-quyet-dinh';
import { IThanhToan } from '../common/thanh-toan';

interface INopPhatQd02 extends Omit<INopPhat, 'thoiHan'> {
  thoiHan: Partial<INopPhat['thoiHan']>;
}

export interface ICanCuQd02 extends Omit<ICanCu, 'qdGiaoQuyen'> {
  qdGiaoQuyen?: Partial<IQdGiaoQuyen>;
}

export interface INguoiCoThamQuyenQd02 extends Partial<ICanBo> {
  diaDanh?: string;
}
export interface INoiDungQd02 {
  canCu: ICanCuQd02;
  nguoiCoThamQuyen: INguoiCoThamQuyenQd02;
  khacPhuc: IKhacPhucHauQua;
  giaoCho: IGiaoCho;
  chiTietHpBs: IChiTietHpBs;
  ttGiam?: string;
  ttTang?: string;
  nopPhat?: INopPhatQd02;
  kyHieuQd?: string;
}

export interface IQd02 extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd02;
  hanhViViPham: IHanhViViPham[];
  hinhThucXuPhat: IListHinhThucXuPhat;
  tuNgay: Date;
  thongBao: IThongBaoQuyetDinh[];
  noiDungChiTiet: INoiDungChiTiet[];
}

export interface IRequestCreateBodyQd02
  extends Pick<
    IQd02,
    | 'maNhapTay'
    | 'noiDung'
    | 'hanhViViPham'
    | 'hinhThucXuPhat'
    | 'tuNgay'
    | 'maBieuMau'
    | 'maVuViec'
    | 'maBieuMauCha'
    | 'maCha'
    | 'thoiGianLap'
    | 'noiDungChiTiet'
    | 'nguon'
    | 'trangThai'
  > {
  thongTinThanhToan?: Omit<IThanhToan, 'ma' | 'maBieuMau'>;
}

export type IRequestUpdateBodyQd02 = Omit<
  IRequestCreateBodyQd02,
  'maCha' | 'maBieuMauCha' | 'maBieuMau' | 'maVuViec' | 'nguon'
>;
