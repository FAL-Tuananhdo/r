import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd27 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  noiKham: string;
  diaChiCuThe: string;
  lyDo: string;
  phamVi: string;
  thoiGian: Date;
  giaoCho: IGiaoChoQd27;
}

interface IGiaoChoQd27 extends Omit<IGiaoCho, 'nguoiNhan' | 'thucHien'> {
  nguoiNhan: string;
  thucHien: string;
}

export interface IPhuongTienDoVatCanKham {
  loai: string;
  ten: string;
  soDangKy: string;
  ngayCap: Date;
  noiCap: string;
  bienSo: string;
  phamVi: string;
}

export interface IQd27 extends IBbQd {
  noiDung: INoiDungQd27;
}

export type ICreateRequestBodyQd27 = Pick<
  IQd27,
  'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec'
>;
export type IUpdateRequestBodyQd27 = Pick<ICreateRequestBodyQd27, 'noiDung' | 'thoiGianLap'>;
