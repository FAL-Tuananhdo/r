import { ICanBo } from '/@/api/can-bo';
import { ILoaiDoiTuongTiepTucThiHanhQd } from '/@/const';

import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';
import { INguoiViPham, IToChucViPham } from '../../common';

export interface IQd17 extends IBbQd {
  tuNgay: Date;
  noiDung: INoiDungQd17;
}

export type ICaNhanThiHanh = Omit<INguoiViPham, 'noiSinh' | 'diaChi'>;
export type IToChucThiHanh = Omit<IToChucViPham, 'maDiaDanh'>;

export interface INoiDungQd17 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDo: string;
  loaiDoiTuongThiHanhQd: ILoaiDoiTuongTiepTucThiHanhQd;
  doiTuongThiHanhQd: ICaNhanThiHanh | IToChucThiHanh;
  isHtxpTichThu: boolean;
  isBpkphq: boolean;
  giaoCho: IGiaoCho;
  soTienPhat?: number;
  caNhanToChucLienQuan?: string;
}

export type IRequestBodyCreateQd17 = Pick<
  IQd17,
  'maCha' | 'maBieuMauCha' | 'maBieuMau' | 'maVuViec' | 'tuNgay' | 'thoiGianLap' | 'noiDung'
>;

export type IRequestBodyUpdateQd17 = Omit<
  IRequestBodyCreateQd17,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
