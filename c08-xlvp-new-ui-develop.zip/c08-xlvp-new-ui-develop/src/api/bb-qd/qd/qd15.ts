import { ICanBo } from '../../can-bo';
import { IHanhViViPham } from '../../common';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IGiaoCho, IBienPhapKPHQ, IThucHienHoanTraKinhPhi } from './base';

export interface IQd15 extends Omit<IBbQd, 'thoiGianLap' | 'tangVat' | 'tuNgay'> {
  tuNgay: Date;
  noiDung: INoiDungQd15;
  thoiGianLap: Date;
  hanhViViPham: IHanhViViPham[];
}

export interface INoiDungQd15 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDoKhongRaQDXuPhat: string;
  bienPhapKhacPhuc: IBienPhapKPHQ[];
  kinhPhiKhacPhucHauQua: IThucHienHoanTraKinhPhi;
  giaoCho: IGiaoCho;
}

export interface IRequestBodyCreateQd15
  extends Pick<
    IQd15,
    'noiDung' | 'maVuViec' | 'maBieuMau' | 'maCha' | 'maBieuMauCha' | 'hanhViViPham' | 'tuNgay'
  > {
  thoiGianLap?: Date;
}
export interface IRequestBodyUpdateQd15
  extends Pick<IQd15, 'noiDung' | 'maNhapTay' | 'hanhViViPham' | 'tuNgay'> {
  thoiGianLap?: Date;
}
