import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IPhuongTienDoVatCanKham } from '../common/phuong-tien-do-vat';

export interface INoiDungQd26 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  chiTiet: IPhuongTienDoVatCanKham[];
  lyDo: string;
  diaDiem: string;
  giaoCho: IGiaoChoQd26;
}

interface IGiaoChoQd26 extends Omit<IGiaoCho, 'nguoiNhan' | 'thucHien'> {
  nguoiNhan: string;
  thucHien: string;
}

export interface IQd26 extends IBbQd {
  noiDung: INoiDungQd26;
}

export type ICreateRequestBodyQd26 = Pick<
  IQd26,
  'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec'
>;
export type IUpdateRequestBodyQd26 = Pick<ICreateRequestBodyQd26, 'noiDung' | 'thoiGianLap'>;
