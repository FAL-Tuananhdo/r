import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface ICanCuQd03 extends Pick<ICanCu, 'bbqd' | 'qdGiaoQuyen'> {
  donDeNghi: {
    nguoiLamDon?: string;
    ngay: Date;
    toChucXacNhan: string;
  };
}

export interface INoiDungQd03 {
  canCu: ICanCuQd03;
  nguoiCoThamQuyen: ICanBo;
  giaoCho: IGiaoCho;
}

export interface IQd03 extends IBbQd {
  noiDung: INoiDungQd03;
  tangVat: ITangVat[];
  maCha: string;
  maBieuMauCha: string;
}

export interface IRequestBodyCreateQd03
  extends Pick<
    IQd03,
    | 'maBieuMau'
    | 'maVuViec'
    | 'maNhapTay'
    | 'noiDung'
    | 'tangVat'
    | 'thoiGianLap'
    | 'tuNgay'
    | 'denNgay'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateQd03 = Pick<
  IQd03,
  'tuNgay' | 'denNgay' | 'noiDung' | 'tangVat' | 'thoiGianLap'
>;
