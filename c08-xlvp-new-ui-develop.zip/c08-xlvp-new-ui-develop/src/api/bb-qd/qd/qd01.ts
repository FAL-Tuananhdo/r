import { INoiDungChiTiet } from '/@/const/type';

import { IGiaoCho, IKhacPhucHauQua, INopPhat } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { IHanhViViPham } from '../../common';
import { ICanCu } from '../common/can-cu';
import { IChiTietHpBs, IListHinhThucXuPhat } from '../common/hinh-thuc-xu-phat';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface ICanCuQD01 extends Pick<ICanCu, 'boSung' | 'qdGiaoQuyen' | 'ttndNhapTay'> {
  maTTND: string;
}

export interface INoiDungQd01 {
  canCu: ICanCuQD01;
  chiTietHpBs: IChiTietHpBs;
  nguoiCoThamQuyen: ICanBo;
  tenDiaDiem: string;
  khacPhuc: IKhacPhucHauQua;
  nopPhat: INopPhat;
  giaoCho: IGiaoCho;
  tinhTietLienQuan?: string;
}

export interface IQd01 extends IBbQd {
  noiDung: INoiDungQd01;
  hanhViViPham: IHanhViViPham[];
  tangVat?: ITangVat[];
  hinhThucXuPhat: IListHinhThucXuPhat;
  noiDungChiTiet: INoiDungChiTiet[];
}

export type ICreateRequestQd01 = Pick<
  IQd01,
  | 'maNhapTay'
  | 'noiDung'
  | 'hanhViViPham'
  | 'hinhThucXuPhat'
  | 'tuNgay'
  | 'maBieuMau'
  | 'maVuViec'
  | 'maBieuMauCha'
  | 'maCha'
  | 'thoiGianLap'
  | 'noiDungChiTiet'
>;

export type IUpdateRequestQd01 = Omit<
  ICreateRequestQd01,
  'maCha' | 'maBieuMauCha' | 'maBieuMau' | 'maVuViec' | 'maNhapTay'
>;
