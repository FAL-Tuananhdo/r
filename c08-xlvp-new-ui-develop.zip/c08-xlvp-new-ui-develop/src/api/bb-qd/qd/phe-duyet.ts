export interface IDetailPheDuyetQuyetDinhRes {
  fileName: string;
  message: string;
}

export interface IPheDuyetQuyetDinhRes {
  details: IDetailPheDuyetQuyetDinhRes[];
  totalFailed: number;
  totalSuccess: number;
}
