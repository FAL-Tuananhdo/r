import { ILyDoTamGiu, IThoiHan } from '/@/const';

import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface IQd20 extends Omit<IBbQd, 'thoiGianLap' | 'tuNgay'> {
  noiDung: INoiDungQd20;
  thoiGianLap: Date;
  tangVat?: ITangVat[];
  tuNgay: Date;
}

export interface INoiDungQd20 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDo: ILyDoTamGiu[];
  thoiHan: IThoiHan;
  diaDiemTamGiu: string;
  giaoCho: IGiaoCho;
}

export type IRequestBodyCreateQd20 = Pick<
  IQd20,
  | 'noiDung'
  | 'thoiGianLap'
  | 'diaDiemLap'
  | 'maVuViec'
  | 'maBieuMau'
  | 'maCha'
  | 'maBieuMauCha'
  | 'tuNgay'
  | 'maNhapTay'
>;
export type IRequestBodyUpdateQd20 = Pick<
  IQd20,
  'noiDung' | 'thoiGianLap' | 'diaDiemLap' | 'tuNgay'
>;
