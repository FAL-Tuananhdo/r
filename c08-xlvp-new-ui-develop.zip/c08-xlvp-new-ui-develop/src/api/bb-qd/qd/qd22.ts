import { IThoiHan } from '/@/const';

import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface INoiDungQd22 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  isDatTienBaoLanh: boolean;
  thoiHanGiu: IThoiHan;
  giaoCho: IGiaoCho;
  tienDatBaoLanh?: number;
}

export interface IQd22 extends Omit<IBbQd, 'tuNgay' | 'thoiGianLap'> {
  thoiGianLap: Date;
  tuNgay: Date;
  noiDung: INoiDungQd22;
  tangVat: ITangVat[];
}

export type ICreateRequestBodyQd22 = Pick<
  IQd22,
  'maVuViec' | 'maBieuMau' | 'maCha' | 'maBieuMauCha' | 'thoiGianLap' | 'tuNgay' | 'noiDung'
>;

export type IUpdateRequestBodyQd22 = Pick<
  ICreateRequestBodyQd22,
  'noiDung' | 'thoiGianLap' | 'tuNgay'
>;
