import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface INoiDungQd33 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  tenCoQuan: string;
  giaoCho: IGiaoChoQd33;
}

export type IGiaoChoQd33 = Pick<IGiaoCho, 'lienQuan' | 'thucHien'>;

export interface IQd33 extends IBbQd {
  noiDung: INoiDungQd33;
  thoiGianLap: Date;
  tangVat: ITangVat[];
}

export interface ICreateRequestBodyQd33
  extends Pick<IQd33, 'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec' | 'tangVat'> {
  maCha: string;
  maBieuMauCha: string;
}
export type IUpdateRequestBodyQd33 = Pick<
  ICreateRequestBodyQd33,
  'noiDung' | 'thoiGianLap' | 'tangVat'
>;
