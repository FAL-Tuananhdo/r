import { ILyDoTraLai } from '/@/const';

import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';
import { ICanCu } from '../common/can-cu';

export interface IQd24 extends IBbQd {
  noiDung: INoiDungQd24;
}

export interface INoiDungQd24 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDo: ILyDoTraLai[];
  giaoCho: IGiaoCho;
}

export interface IRequestBodyQd24 extends Omit<IQd24, 'vuViec' | 'trangThai' | 'ma'> {
  ma?: string;
}
