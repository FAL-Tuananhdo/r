import { ICanBo } from '/@/api/can-bo';
import { IThoiHan } from '/@/const';

import { INguoiGiamHo } from './base';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';
import { ICanCu } from '../common/can-cu';

export interface IQd18 extends Omit<IBbQd, 'thoiGianLap'> {
  thoiGianLap: Date;
  tuNgay: Date;
  noiDung: INoiDungQd18;
}

export type IGiaoChoQd18 = Pick<IGiaoCho, 'khieuNai' | 'lienQuan'> &
  Required<Pick<IGiaoCho, 'thucHien'>>;

export interface INoiDungQd18 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  tinhTrang: string;
  nguoiGiamHo: INguoiGiamHo;

  maLyDo: string;
  thoiHan: IThoiHan;
  diaDiemTamGiu: string;

  giaoCho: IGiaoChoQd18;
  thongBaoCho: string;
}

export type IRequestBodyCreateQd18 = Pick<
  IQd18,
  'maBieuMau' | 'maVuViec' | 'tuNgay' | 'thoiGianLap' | 'noiDung'
>;

export type IRequestBodyUpdateQd18 = Omit<IRequestBodyCreateQd18, 'maBieuMau' | 'maVuViec'>;
