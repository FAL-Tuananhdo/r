import { IThoiHan } from '/@/const';

import { IDonViDeNghi, IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface INoiDungQd30 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  donViDeNghi: IDonViDeNghi;
  lyDo: string;
  thoiHanTamGiu: IThoiHan;
  giaoCho: IGiaoCho;
  diaDiemTamGiu: string;
}

export interface IQd30 extends IBbQd {
  noiDung: INoiDungQd30;
  thoiGianLap: Date;
  tuNgay: Date;
  tangVat: ITangVat[];
}

export interface ICreateRequestBodyQd30
  extends Pick<IQd30, 'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec' | 'tuNgay'> {
  maCha: string;
  maBieuMauCha: string;
}
export type IUpdateRequestBodyQd30 = Pick<
  ICreateRequestBodyQd30,
  'noiDung' | 'thoiGianLap' | 'tuNgay'
>;
