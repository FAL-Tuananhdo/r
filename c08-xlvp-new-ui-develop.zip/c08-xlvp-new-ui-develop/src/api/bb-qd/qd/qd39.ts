import { IDonViDeNghi, IGiaoCho, INoiDungThayDoiHvvp } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IHanhViViPham } from '../../common';

export interface INoiDungQd39 {
  canCu: ICanCu;
  donViDeNghi: IDonViDeNghi;
  nguoiCoThamQuyen: ICanBo;
  lyDo: string;
  hvvpSuaDoi: INoiDungThayDoiHvvp[];
  giaoCho: IGiaoCho;
  tenNguoiCoThamQuyenQdCha?: string;
  ngayLapQdCha?: Date;
}

export interface IQd39 extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd39;
  hanhViViPham: IHanhViViPham[];
  tuNgay: Date;
}

export interface ICreateRequestBodyQd39
  extends Pick<
    IQd39,
    'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec' | 'tuNgay' | 'hanhViViPham'
  > {
  maCha: string;
  maBieuMauCha: string;
}
export type IUpdateRequestBodyQd39 = Pick<
  ICreateRequestBodyQd39,
  'noiDung' | 'thoiGianLap' | 'tuNgay' | 'hanhViViPham'
>;
