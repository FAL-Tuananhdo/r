import { IThoiHan } from '/@/const/type';

import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export type IGiaoChoQd13 = Pick<IGiaoCho, 'khieuNai' | 'lienQuan' | 'thucHien'>;
export interface INoiDungQd13 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  diaDiemKeBien: string;
  lyDoCuThe: string;
  giaoCho: IGiaoChoQd13;
  coQuanThucHien?: string;
  soTienPhat?: number;
  thoiHanThucHien: IThoiHan;
}

export interface IQd13 extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd13;
  tuNgay: Date;
}

export type ICreateRequestBodyQd13 = Omit<IQd13, 'ma' | 'trangThai' | 'vuViec'>;
export type IUpdateRequestBodyQd13 = Pick<
  ICreateRequestBodyQd13,
  'noiDung' | 'tuNgay' | 'thoiGianLap'
>;
