import { IDonViDeNghi, IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd31 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  donViDeNghi: IDonViDeNghi;
  giaoCho: IGiaoCho;
}

export interface IQd31 extends IBbQd {
  noiDung: INoiDungQd31;
  thoiGianLap: Date;
}

export type ICreateRequestBodyQd31 = Pick<
  IQd31,
  'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
export type IUpdateRequestBodyQd31 = Pick<ICreateRequestBodyQd31, 'noiDung' | 'thoiGianLap'>;
