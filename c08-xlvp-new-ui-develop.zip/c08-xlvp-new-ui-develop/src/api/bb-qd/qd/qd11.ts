import { IBienPhapKPHQ, IGiaoCho, IThucHienHoanTraKinhPhi } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { IHanhViViPham } from '../../common/hanh-vi-vi-pham';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd11 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  bienPhapKhacPhucHauQua: IBienPhapKPHQ[];
  kinhPhiKhacPhucHauQua: IThucHienHoanTraKinhPhi;
  giaoCho: IGiaoCho;
}

export interface IQd11 extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd11;
  hanhViViPham: IHanhViViPham[];
  tuNgay: Date;
}

export type IRequestCreateBodyQd11 = Pick<
  IQd11,
  | 'noiDung'
  | 'hanhViViPham'
  | 'tuNgay'
  | 'maBieuMau'
  | 'maVuViec'
  | 'maBieuMauCha'
  | 'maCha'
  | 'thoiGianLap'
>;

export type IRequestUpdateBodyQd11 = Pick<
  IQd11,
  'thoiGianLap' | 'hanhViViPham' | 'noiDung' | 'tuNgay'
>;
