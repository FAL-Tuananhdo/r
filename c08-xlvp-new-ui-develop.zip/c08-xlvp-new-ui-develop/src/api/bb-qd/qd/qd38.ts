import { IDonViDeNghi, IGiaoCho, INoiDungThayDoiHvvp } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IHanhViViPham } from '../../common';

export interface INoiDungQd38 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  donViDeNghi: IDonViDeNghi;
  giaoCho: IGiaoCho;
  lyDo: string;
  hvvpSuaDoi: INoiDungThayDoiHvvp[];
  tenNguoiCoThamQuyenQdCha?: string;
  ngayLapQdCha?: Date;
}

export interface IQd38 extends Omit<IBbQd, 'tuNgay' | 'maBieuMauCha' | 'maCha'> {
  tuNgay: Date;
  noiDung: INoiDungQd38;
  hanhViViPham: IHanhViViPham[];
  maBieuMauCha: string;
  maCha: string;
}

export type ICreateRequestBodyQd38 = Pick<
  IQd38,
  | 'thoiGianLap'
  | 'noiDung'
  | 'maBieuMau'
  | 'maVuViec'
  | 'maCha'
  | 'maBieuMauCha'
  | 'tuNgay'
  | 'hanhViViPham'
>;
export type IUpdateRequestBodyQd38 = Pick<
  ICreateRequestBodyQd38,
  'noiDung' | 'thoiGianLap' | 'hanhViViPham' | 'tuNgay'
>;
