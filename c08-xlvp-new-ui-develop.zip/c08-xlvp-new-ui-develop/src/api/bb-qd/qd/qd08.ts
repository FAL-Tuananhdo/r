import { IThoiHan } from '/@/const';

import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';

export interface IQd08 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungQd08;
  tuNgay: Date;
}

export interface INoiDungQd08 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  giaoCho: IGiaoChoQd08;
  tinDung: IToChucTinDungViPhamQd08;
  soTienPhat: number;
  soTienKhauTru: number;
  nopPhat: INopPhatQd08;
  donViThucHienBpkp?: string;
}

export type ICreateRequestBodyQd08 = Pick<
  IQd08,
  'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha' | 'tuNgay'
>;
export type IUpdateRequestBodyQd08 = Pick<
  ICreateRequestBodyQd08,
  'noiDung' | 'thoiGianLap' | 'tuNgay'
>;

export type IGiaoChoQd08 = RequireAtLeastOne<
  Pick<IGiaoCho, 'khieuNai' | 'lienQuan' | 'thucHien'>,
  'thucHien'
>;

export interface IToChucTinDungViPhamQd08 {
  stk: string;
  toChuc: string;
  diaChi?: string;
}

export interface INopPhatQd08 {
  stk: string;
  ma: string;
  thoiHan: IThoiHan;
}
