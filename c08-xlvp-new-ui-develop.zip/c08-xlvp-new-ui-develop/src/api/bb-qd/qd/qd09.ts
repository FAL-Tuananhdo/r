import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho, IThongTinPhoiHop } from './base';

export type IGiaoChoQd09 = Pick<IGiaoCho, 'lienQuan' | 'thucHien'>;

export interface INoiDungQd09 {
  canCu: ICanCu;
  lyDoCuThe: string;
  nguoiCoThamQuyen: ICanBo;
  giaoCho: IGiaoChoQd09;
  soTienPhat?: number;
  thongTinKeBien: IThongTinPhoiHop;
  donViThucHienBpkp?: string;
}
export interface IQd09 extends Omit<IBbQd, 'thoiGianLap'> {
  noiDung: INoiDungQd09;
  thoiGianLap: Date;
  tuNgay: Date;
}

export interface IRequestBodyCreateQd09
  extends Pick<IQd09, 'noiDung' | 'maVuViec' | 'maBieuMau' | 'maCha' | 'maBieuMauCha' | 'tuNgay'> {
  thoiGianLap?: Date;
}
export interface IRequestBodyUpdateQd09 extends Pick<IQd09, 'noiDung' | 'maNhapTay' | 'tuNgay'> {
  thoiGianLap?: Date;
}
