import { IThoiHan } from '/@/const';

import { ICanBo } from '../../can-bo/model';
import { IGiaoCho } from './base';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface INoiDungQd05 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  tienNop: number[];
  tongTien: number;
  thoiHan: IThoiHan;
  giaoCho: IGiaoCho;
}

export interface IQd05 extends Omit<IBbQd, 'thoiGianLap'> {
  noiDung: INoiDungQd05;
  thoiGianLap: Date;
  tangVat: ITangVat[];
}

export type IRequestBodyCreateQd05 = Omit<IQd05, 'trangThai' | 'vuViec' | 'ma'>;

export type IRequestUpdateBodyQd05 = Omit<IQd05, 'trangThai' | 'vuViec'>;
