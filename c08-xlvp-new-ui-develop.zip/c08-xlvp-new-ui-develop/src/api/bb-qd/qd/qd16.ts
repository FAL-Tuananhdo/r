import { IThoiHan } from '/@/const';

import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IGiaoCho } from './base';

export interface ICoQuanThamGia {
  maTangVat: string;
  tenCoQuan: string;
}

export interface IThanhPhanThamGia {
  quanLyTangVat: ICoQuanThamGia[];
  lienQuan?: string;
}

export type IGiaoChoQd16 = Pick<IGiaoCho, 'thucHien' | 'lienQuan'>;

export interface INoiDungQd16 {
  canCu: Pick<ICanCu, 'bbqd' | 'qdGiaoQuyen'>;
  nguoiCoThamQuyen: ICanBo;
  lyDoTieuHuy: string;
  thoiHan: IThoiHan;
  diaDiemTieuHuy: string;
  thamGia: IThanhPhanThamGia;
  giaoCho: IGiaoChoQd16;
}

export interface IQd16 extends IBbQd {
  noiDung: INoiDungQd16;
  tangVat: ITangVat[];
}

export type IRequestBodyCreateQd16 = Pick<
  IQd16,
  'noiDung' | 'thoiGianLap' | 'maBieuMau' | 'maVuViec' | 'maBieuMauCha' | 'maCha' | 'tangVat'
>;

export type IRequestUpdateBodyQd16 = Pick<
  IRequestBodyCreateQd16,
  'noiDung' | 'thoiGianLap' | 'tangVat'
>;
