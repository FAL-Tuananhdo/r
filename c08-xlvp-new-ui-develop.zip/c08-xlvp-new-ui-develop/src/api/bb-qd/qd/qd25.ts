import { IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd25 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDo: string;
  giaoCho: IGiaoCho;
}

export interface IQd25 extends IBbQd {
  noiDung: INoiDungQd25;
}

export type ICreateRequestBodyQd25 = Pick<
  IQd25,
  'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec'
>;
export type IUpdateRequestBodyQd25 = Pick<ICreateRequestBodyQd25, 'noiDung' | 'thoiGianLap'>;
