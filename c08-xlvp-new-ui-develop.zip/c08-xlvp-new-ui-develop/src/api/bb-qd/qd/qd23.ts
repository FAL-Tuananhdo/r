import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';

export interface IGiaoChoQd23 {
  nguoiNhan: string;
  thucHien: string;
  nguoiQuanLy: string;
  soTaiKhoan: string;
  maKhoBac: string;
  khieuNai?: string;
  lienQuan?: string;
}

export interface INoiDungQd23 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  soTienKhauTru: number;
  giaoCho: IGiaoChoQd23;
}

export interface IQd23 extends Omit<IBbQd, 'tuNgay' | 'thoiGianLap'> {
  thoiGianLap: Date;
  noiDung: INoiDungQd23;
  maCha: string;
  maBieuMauCha: string;
}

export type ICreateRequestBodyQd23 = Pick<
  IQd23,
  'maVuViec' | 'maBieuMau' | 'maCha' | 'maBieuMauCha' | 'thoiGianLap' | 'noiDung'
>;

export type IUpdateRequestBodyQd23 = Pick<ICreateRequestBodyQd23, 'noiDung' | 'thoiGianLap'>;
