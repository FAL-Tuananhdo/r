import { IDonViDeNghi, IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd29 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  donViDeNghi: IDonViDeNghi;
  lyDoHuyBo: string;
  thoiGianHuyBo: Date;
  giaoCho: IGiaoCho;
}

export interface IQd29 extends IBbQd {
  noiDung: INoiDungQd29;
}

export interface ICreateRequestBodyQd29
  extends Pick<IQd29, 'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec'> {
  maCha: string;
  maBieuMauCha: string;
}
export type IUpdateRequestBodyQd29 = Pick<ICreateRequestBodyQd29, 'noiDung' | 'thoiGianLap'>;
