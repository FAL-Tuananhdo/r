import { ICanBo } from '/@/api/can-bo';
import { IThoiHan } from '/@/const';

import { INguoiGiamHo } from './base';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';

export interface IQd19 extends IBbQd {
  tuNgay: Date;
  noiDung: INoiDungQd19;
}
export type IGiaoChoQd19 = RequireAtLeastOne<
  Pick<IGiaoCho, 'khieuNai' | 'lienQuan' | 'thucHien'>,
  'thucHien'
>;

export interface INoiDungQd19 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  nguoiGiamHo: INguoiGiamHo;
  lyDo: string;
  thoiHan: IThoiHan;
  thoiHanKeoDai?: IThoiHan;
  giaoCho: IGiaoChoQd19;
  thongBaoCho: string;
}

export type IRequestBodyCreateQd19 = Pick<
  IQd19,
  'maCha' | 'maBieuMauCha' | 'maBieuMau' | 'maVuViec' | 'tuNgay' | 'thoiGianLap' | 'noiDung'
>;

export type IRequestBodyUpdateQd19 = Omit<IRequestBodyCreateQd19, 'maBieuMau' | 'maVuViec'>;
