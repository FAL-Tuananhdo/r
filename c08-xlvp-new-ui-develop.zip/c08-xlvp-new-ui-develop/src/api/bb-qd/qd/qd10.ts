import { IThoiHan } from '/@/const';

import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IGiaoCho } from './base';
import {
  IThongTinXacMinh,
  IThongTinXacMinhTaiSanBenThuBa,
  IThongTinXacMinhTienBenThuBa,
} from '../common/thong-tin-xac-minh';

export interface IThongTinXacMinhQd10 extends Omit<IThongTinXacMinh, 'noiDung'> {
  noiDung: IThongTinXacMinhTaiSanBenThuBa | IThongTinXacMinhTienBenThuBa;
}

export interface INoiDungQd10 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  phoiHop: string;
  diaDiemCuongChe: string;
  thoiHan: IThoiHan;
  giaoCho: IGiaoCho;
  thongTinXacMinh: IThongTinXacMinhQd10[];
  donViThucHienBpkp?: string;
}

export interface IQd10 extends Omit<IBbQd, 'thoiGianLap' | 'tuNgay'> {
  noiDung: INoiDungQd10;
  thoiGianLap: Date;
  tuNgay: Date;
}

export type IRequestBodyCreateQd10 = Omit<IQd10, 'trangThai' | 'vuViec' | 'ma'>;

export type IRequestUpdateBodyQd10 = Omit<IQd10, 'trangThai' | 'vuViec'>;
