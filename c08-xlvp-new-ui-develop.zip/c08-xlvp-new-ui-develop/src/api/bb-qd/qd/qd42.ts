import { ICanBo } from '../../can-bo';
import { IBbQdLienQuan } from '../common/bbqd-lien-quan';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';

export type IGiaoChoQd42 = Pick<IGiaoCho, 'thucHien' | 'lienQuan'>;

export interface IQd42 extends IBbQd {
  noiDung: INoiDungQd42;
  thoiGianLap: Date;
  tangVat: ITangVat[];
}

export interface INoiDungQd42 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDo: string;
  giaoCho: IGiaoChoQd42;
  taiLieuKemTheo: IBbQdLienQuan[];
}

export interface IRequestCreateBodyQd42
  extends Pick<IQd42, 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'noiDung' | 'tangVat'> {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestUpdateBodyQd42 = Pick<IQd42, 'thoiGianLap' | 'noiDung' | 'tangVat'>;
