import { IDonViDeNghi, IGiaoCho } from './base';
import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface INoiDungQd32 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  donViDeNghi: IDonViDeNghi;
  giaoCho: IGiaoCho;
  lyDo: string;
}

export interface IQd32 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungQd32;
}

export type ICreateRequestBodyQd32 = Pick<
  IQd32,
  'thoiGianLap' | 'noiDung' | 'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
export type IUpdateRequestBodyQd32 = Pick<ICreateRequestBodyQd32, 'noiDung' | 'thoiGianLap'>;
