import { ICanBo } from '../../can-bo';
import { ICanCu, ICanCuBBQD } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';

export type IGiaoChoQd14b = Pick<IGiaoCho, 'thucHien' | 'lienQuan'>;

export interface IQd14b extends IBbQd {
  noiDung: INoiDungQd14b;
  thoiGianLap: Date;
}

export interface INoiDungQd14b {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  giaoCho: IGiaoChoQd14b;
  taiLieuKemTheo: {
    bbqd: ICanCuBBQD[];
    boSung?: string[];
  };
  lyDoTichThu?: string;
}

export type ICreateRequestBodyQd14b = Pick<
  IQd14b,
  'noiDung' | 'thoiGianLap' | 'maBieuMau' | 'maVuViec' | 'maBieuMauCha' | 'maCha'
>;
export type IUpdateRequestBodyQd14b = Pick<ICreateRequestBodyQd14b, 'noiDung' | 'thoiGianLap'>;
