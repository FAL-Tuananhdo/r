import { IThoiHan } from '/@/const/type';

import { IBienPhapKPHQ, IGiaoCho } from './base';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IThongTinXacMinh } from '../common/thong-tin-xac-minh';

export interface INoiDungQd12a {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  soTienKhauTru: number[];
  nopPhat: IThongTinNopPhatQd12a;
  bienPhapKhacPhuc: IBienPhapKPHQ[];
  giaoCho: IGiaoCho;
  thongTinXacMinh: IThongTinXacMinh[];
  tongTien: number;
  thoiHan?: IThoiHan;
  kinhPhiKhacPhuc?: IHoanTraKinhPhiVaThucHienQd12a;
  donViThucHienBpkp?: string;
}

export interface IHoanTraKinhPhiVaThucHienQd12a {
  soTien?: number;
  donViThucHien?: string;
  donViPhoiHop?: string;
  diaDiem?: string;
}

export interface IThongTinNopPhatQd12a {
  stk: string;
  ma: string;
  thoiHan: IThoiHan;
}

export interface IQd12a extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd12a;
  tuNgay: Date;
}

export type ICreateRequestBodyQd12a = Pick<
  IQd12a,
  'noiDung' | 'tuNgay' | 'maVuViec' | 'maCha' | 'maBieuMauCha' | 'thoiGianLap' | 'maBieuMau'
>;
export type IUpdateRequestBodyQd12a = Pick<
  ICreateRequestBodyQd12a,
  'noiDung' | 'tuNgay' | 'thoiGianLap'
>;
