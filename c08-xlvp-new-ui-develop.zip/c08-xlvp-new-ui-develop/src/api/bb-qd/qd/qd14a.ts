import { ICanBo } from '../../can-bo';
import { ICanCu, ICanCuBBQD } from '../common/can-cu';
import { IBbQd } from '../model';
import { IGiaoCho } from './base';

export type IGiaoChoQd14a = Pick<IGiaoCho, 'thucHien' | 'lienQuan'>;

export interface IQd14a extends IBbQd {
  noiDung: INoiDungQd14a;
  thoiGianLap: Date;
}

export interface INoiDungQd14a {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lyDoKhongRaQDXuPhat: string;
  noiTiepNhan: string;
  giaoCho: IGiaoChoQd14a;
  taiLieuKemTheo: {
    bbqd: ICanCuBBQD[];
    boSung?: string[];
  };
}

export type ICreateRequestBodyQd14a = Pick<
  IQd14a,
  'noiDung' | 'thoiGianLap' | 'maBieuMau' | 'maVuViec' | 'maBieuMauCha' | 'maCha'
>;
export type IUpdateRequestBodyQd14a = Pick<ICreateRequestBodyQd14a, 'noiDung' | 'thoiGianLap'>;
