import { IGiaoCho } from './base';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { ICanBo } from '../../can-bo/model';
import { IBbQd } from '../model';

export interface INoiDungQd04 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  soTien: number;
  loaiMienGiam?: string;
  giaoCho: IGiaoCho;
}

export interface IQd04 extends IBbQd {
  noiDung: INoiDungQd04;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateQd04
  extends Pick<
    IQd04,
    'maBieuMau' | 'maVuViec' | 'noiDung' | 'tangVat' | 'thoiGianLap' | 'tuNgay' | 'denNgay'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateQd04 = Pick<
  IQd04,
  'tuNgay' | 'denNgay' | 'noiDung' | 'tangVat' | 'thoiGianLap'
>;
