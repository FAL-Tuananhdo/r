import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { IBienPhapKPHQ, IGiaoCho, IThucHienHoanTraKinhPhi, IThongTinPhoiHop } from './base';
import { IThongTinXacMinh } from '../common/thong-tin-xac-minh';

export interface IQd12c extends Omit<IBbQd, 'tuNgay'> {
  noiDung: INoiDungQd12c;
  tuNgay: Date;
}

export type IGiaoChoQd12c = Pick<IGiaoCho, 'khieuNai' | 'lienQuan' | 'thucHien'>;

export interface INoiDungQd12c {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  thongTinXacMinh: IThongTinXacMinh[];
  thongTinCuongChe: IThongTinPhoiHop;
  bienPhapKhacPhuc: IBienPhapKPHQ[];
  kinhPhiKhacPhucHauQua: IThucHienHoanTraKinhPhi;
  giaoCho: IGiaoChoQd12c;
  donViThucHienBpkp?: string;
}
export type IRequestBodyCreateQd12c = Pick<
  IQd12c,
  'noiDung' | 'maVuViec' | 'maBieuMau' | 'maCha' | 'maBieuMauCha' | 'tuNgay' | 'thoiGianLap'
>;

export type IRequestBodyUpdateQd12c = Pick<IQd12c, 'noiDung' | 'tuNgay' | 'thoiGianLap'>;
