export interface ITangVatPhatHien {
  ten: string;
  soLuong: string;
  donViTinh: string;
  nhanHieu?: string;
  chungLoai?: string;
  tinhTrang?: string;
  ghiChu?: string;
}
