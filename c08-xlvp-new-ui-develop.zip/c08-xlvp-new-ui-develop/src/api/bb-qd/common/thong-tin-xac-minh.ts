import { ILoaiTTXacMinh } from '/@/const/type';

export interface IThongTinXacMinh {
  loai: ILoaiTTXacMinh;
  noiDung: INoiDungThongTinXacMinh;
}

export type INoiDungThongTinXacMinh =
  | IThongTinXacMinhTienLuongThuNhap
  | IThongTinXacMinhTaiKhoan
  | IThongTinXacMinhTaiSan
  | IThongTinXacMinhTienBenThuBa
  | IThongTinXacMinhTaiSanBenThuBa;

export interface ISoTien {
  giaTri?: number;
  donVi?: string;
}
export interface IThongTinXacMinhTienLuongThuNhap {
  coQuan: string;
  soTien: ISoTien;
  diaChi?: string;
}

export interface IThongTinXacMinhTaiKhoan {
  stk: string;
  toChuc: string;
  diaChi?: string;
}

export interface IThongTinXacMinhTaiSan {
  ten: string;
  donViTinh: string;
  soLuong: number;
  tinhTrang?: string;
  ghiChu?: string;
}

export interface IThongTinXacMinhTienBenThuBa {
  loaiTien: string;
  soTien: ISoTien;
  doiTuongGiu: string;
  diaChi?: string;
}

export interface IThongTinXacMinhTaiSanBenThuBa extends IThongTinXacMinhTaiSan {
  doiTuongGiu: string;
  diaChi?: string;
}
