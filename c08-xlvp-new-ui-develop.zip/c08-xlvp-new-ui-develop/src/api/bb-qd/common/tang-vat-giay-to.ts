import { ILoaiTangVat, ITrangThaiTangVat } from '/@/const/type';

export interface IBaseTangVat {
  tinhTrang?: string;
  ghiChu?: string;
}

interface ITangVatPhuongTienBase extends IBaseTangVat {
  chungLoai: string;
  donViTinh: string;
  soLuong: number;
  donGia?: number;
}

export interface ITangVatPhuongTienDuongBo extends ITangVatPhuongTienBase {
  soKhung?: string;
  soMay?: string;
  bienSo?: string;
  bienSo2?: string;
  nhanHieu?: string;
  mauSon?: string;
  soLoai?: string;
}

export interface ITangVatPhuongTienDuongSat extends ITangVatPhuongTienBase {
  bienSo?: string;
  bienSo2?: string;
}
export interface ITangVatPhuongTienDuongThuy extends ITangVatPhuongTienBase {
  trongTai?: string;
  trongTai2?: string;
  congSuat?: string;
  congSuat2?: string;
  soDangKy?: string;
  soDangKy2?: string;
}

export type ITangVatPhuongTien =
  | ITangVatPhuongTienDuongBo
  | ITangVatPhuongTienDuongSat
  | ITangVatPhuongTienDuongThuy;

export interface ITangVatGPLX extends IBaseTangVat {
  hang: string[];
  so: number;
  soLuong: number;
  noiCap?: string;
  giaTriDen?: Date;
}

export interface ITangVatGiayTo extends IBaseTangVat {
  so: number;
  soLuong: number;
  giaTriDen?: Date;
  noiCap?: string;
}

export interface ITangVatKhac extends IBaseTangVat {
  ten: string;
  donViTinh: string;
  soLuong: number;
  donGia?: number;
}

export type IInfoTangVat = ITangVatPhuongTien | ITangVatGPLX | ITangVatGiayTo | ITangVatKhac;

export interface ITangVat {
  ma: string;
  thongTin: IInfoTangVat;
  nhomTangVat: ILoaiTangVat;
}

export interface ITangVatVuViec extends ITangVat {
  maVuViec: string;
  maBBQD: string;
  maBieuMau: string;
  maDonViCsgt: string;
  ten?: string;
  tuNgay?: Date;
  denNgay?: Date;
  trangThai?: ITrangThaiTangVat;
}
