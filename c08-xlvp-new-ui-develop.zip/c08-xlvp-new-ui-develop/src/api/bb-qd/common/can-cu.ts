export interface ICanCuBBQD {
  maBieuMau: string;
  so?: string;
  ngay?: Date;
  maNhapTay?: string;
  tenDonVi?: string;
}

export interface IQdGiaoQuyen {
  maBieuMau: string;
  maNhapTay?: string;
  so?: string;
  ngay?: Date;
  maCb?: string;
}

export interface ITtndNhapTay {
  dieu?: string;
  so?: string;
  ngay?: Date;
}

export interface IDonDeNghi {
  ngay: Date;
  toChucXacNhan: string;
}

export interface ICanCu {
  bbqd?: ICanCuBBQD[];
  maTTND?: string;
  maCanCu?: string[]; //danh muc can cu
  ttndNhapTay?: ITtndNhapTay;
  boSung?: string[];
  qdGiaoQuyen?: IQdGiaoQuyen;
  donDeNghi?: IDonDeNghi;
}
