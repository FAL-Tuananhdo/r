import { ICanCuBBQD } from './can-cu';

export interface IBbQdLienQuan {
  maBieuMau: string;
  so: string;
  ngay: Date;
}

export interface ITaiLieuKhac {
  noiDung: string;
  kyHieu?: string;
  soLuong: number;
}

export interface ITaiLieuBbQd {
  bbqd: ICanCuBBQD[];
  khac?: ITaiLieuKhac[];
}
