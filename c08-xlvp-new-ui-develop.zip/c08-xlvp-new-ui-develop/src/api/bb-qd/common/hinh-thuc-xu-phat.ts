import { ITangVatGiayTo, ITangVatGPLX, ITangVatKhac, ITangVatPhuongTien } from './tang-vat-giay-to';
import { ILoaiHinhPhatBoSung, ILoaiHinhThucXuPhat, ILoaiTangVat, IThoiHan } from '/@/const';

interface IBase {
  ma: string;
  loai: ILoaiHinhThucXuPhat;
}

export interface IChiTietHpBs {
  isPhat: boolean;
  lyDo?: string;
  thoiHan?: IThoiHan;
}

export type ITangVatPhuongTienHpbs = Omit<
  ITangVatPhuongTien,
  'tinhTrang' | 'ghiChu' | 'donViTinh' | 'soLuong' | 'donGia'
>;

export interface ITangVatGPLXHpbs
  extends Pick<ITangVatGPLX, 'hang' | 'so' | 'giaTriDen' | 'noiCap'> {
  ngayCap: Date;
}

export type ITangVatGiayToHpbs = Pick<ITangVatGiayTo, 'so' | 'giaTriDen' | 'noiCap'>;

export type ITangVatKhacHpbs = Pick<ITangVatKhac, 'ten'>;

export type IInfoTangVatHpbs =
  | ITangVatPhuongTienHpbs
  | ITangVatGPLXHpbs
  | ITangVatGiayToHpbs
  | ITangVatKhacHpbs;

export interface IHinhThucXuPhatBoSung extends IBase {
  thongTin: IInfoTangVatHpbs;
  maGiayTo: string;
  nhomGiayTo: ILoaiTangVat;
  loaiBoSung: ILoaiHinhPhatBoSung;
  maLoaiTangVat: string;
  soLuong?: number;
  tuNgay?: Date;
  denNgay?: Date;
  thoiHan?: IThoiHan;
}

export interface IHinhThucXuPhatChinh extends IBase {
  soTien: number;
}

export type IListHinhThucXuPhat = Array<IHinhThucXuPhatChinh | IHinhThucXuPhatBoSung>;

export type IHinhThucXuPhat = IHinhThucXuPhatChinh | IHinhThucXuPhatBoSung;
