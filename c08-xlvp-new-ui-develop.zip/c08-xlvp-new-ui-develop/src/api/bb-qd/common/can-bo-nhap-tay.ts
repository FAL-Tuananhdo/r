export interface ICanBoNhapTay {
  ten: string;
  chucVu: string;
  coQuan: string;
}
