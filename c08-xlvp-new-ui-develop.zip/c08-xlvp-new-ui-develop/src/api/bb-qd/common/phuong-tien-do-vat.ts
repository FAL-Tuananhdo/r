export interface IPhuongTienDoVatCanKham {
  loai: string;
  ten: string;
  soDangKy: string;
  ngayCap: Date;
  noiCap: string;
  bienSo: string;
  phamVi: string;
}
