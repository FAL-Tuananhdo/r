import { ILoaiDoiTuongChungKien } from '/@/const/type';

export interface IDoiTuongChungKien {
  loaiDoiTuong: ILoaiDoiTuongChungKien;
  ten: string;
  thongTin: {
    ngheNghiep?: string;
    diaChi?: string;
    chucVu?: string;
    coQuan?: string;
    gioiTinh?: string;
  };
}
