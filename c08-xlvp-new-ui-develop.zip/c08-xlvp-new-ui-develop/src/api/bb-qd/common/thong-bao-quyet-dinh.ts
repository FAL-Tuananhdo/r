import { LoaiThongBao } from '/@/const';

export interface INoiDungThongBaoTuoc {
  so?: string;
  soNhapTay?: string;
  kyHieu: string;
  thoiGianLap: Date;
}

export interface INoiDungThongBaoXuPhatVPHC {
  so?: string;
  soNhapTay?: string;
  kyHieu: string;
  donViNhan: string;
  diaDiemNhan: string;
}

export interface IThongBaoQuyetDinh {
  loai: LoaiThongBao;
  noiDung: INoiDungThongBaoTuoc | INoiDungThongBaoXuPhatVPHC;
}
