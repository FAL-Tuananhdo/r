export interface IThanhToan {
  ma: string;
  maBieuMau: string;
  hinhThuc: string;
  soBienLai: string;
  thoiGian: Date;
  maKhoBac: string;
  nganHang?: string;
}
