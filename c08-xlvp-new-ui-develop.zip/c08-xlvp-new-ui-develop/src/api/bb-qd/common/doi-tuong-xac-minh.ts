import { ILoaiDoiTuongXacMinh } from '/@/const/type';

export interface IDoiTuongXacMinh {
  loai: ILoaiDoiTuongXacMinh;
  ten: string;
  chucVu?: string;
  coQuan?: string;
  ngheNghiep?: string;
  diaChi?: string;
}
