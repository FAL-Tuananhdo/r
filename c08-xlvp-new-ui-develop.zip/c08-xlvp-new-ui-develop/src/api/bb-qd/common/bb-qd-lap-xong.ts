export interface IBbQdLapXong {
  thoiGian: Date;
  soTo: number;
  soBan: number;
}
