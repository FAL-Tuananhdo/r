export interface IDoiTuongThietHai {
  loaiDoiTuong: string;
  hoVaTen?: string;
  nguoiDaiDien?: string;
  chucVu?: string;
  tenToChuc?: string;
}
