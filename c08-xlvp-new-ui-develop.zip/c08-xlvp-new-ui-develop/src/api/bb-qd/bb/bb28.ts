import { ITaiLieuLienQuan } from '/@/views/components/tables/table-tai-lieu-lien-quan';

import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';

export interface IBb28 extends IBbQd {
  noiDung: INoiDungBb28;
}

export interface INoiDungBb28 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  bienBanLapXong: IBbQdLapXong;
  nhanBanGiao: ICanBoNhapTay;
  taiLieuKemTheo: ITaiLieuLienQuan;
}

export type IRequestBodyCreateBb28 = Pick<
  IBb28,
  | 'maCha'
  | 'maBieuMauCha'
  | 'maBieuMau'
  | 'maNhapTay'
  | 'thoiGianLap'
  | 'diaDiemLap'
  | 'maVuViec'
  | 'noiDung'
>;

export type IUpdateRequestBodyBb28 = Omit<
  IRequestBodyCreateBb28,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
