import { INoiDungChiTiet } from '/@/const/type';

import { ICanBo } from '../../can-bo';
import { IHanhViViPham } from '../../common/hanh-vi-vi-pham';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IDoiTuongThietHai } from '../common/doi-tuong-thiet-hai';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd, IVuViecInfo } from '../model';

export interface INoiDungBb01 {
  canCu: ICanCu;
  hoi: Date;
  tai: string;
  phuongTienViPham?: string;
  bienSo: string;
  nguoiCoThamQuyen: ICanBo;
  diaDiemGiaiTrinh: IGiaiTrinh;
  bienBanLapXongHoi: IBienBanLapXong;
  bienPhap?: string;
  lyDoLapBienBan?: string;
  maPhuongTien?: string;
  doiTuongChungKien?: IDoiTuongChungKien[];
  nguoiPhienDich?: INguoiPhienDich;
  doiTuongThietHai?: IDoiTuongThietHai[];
  lyDoKhongKyBienBanCaNhan?: string;
  lyDoKhongKyBienBanChungKien?: string;
  yKienBenViPham?: string;
  yKienBenChungKien?: string;
  yKienBenThietHai?: string;
}

interface INguoiPhienDich {
  hoVaTen?: string;
  maNgheNghiep?: string;
  tenNgheNghiep?: string;
  diaChi?: string;
}

interface IGiaiTrinh {
  loaiHinhThuc: string;
  maChucVu?: string;
  maDonVi: string;
  thoiGianGiaiTrinh: Date;
  tenChucVu?: string;
  tenDonVi?: string;
  diaChiId?: number;
}

interface IBienBanLapXong {
  thoiGian: Date;
  soTo: number;
  soBan: number;
}

export interface IBb01 extends Omit<IBbQd, 'maBieuMauCha' | 'maCha' | 'vuViec'> {
  noiDung: INoiDungBb01;
  tangVat: ITangVat[];
  hanhViViPham: IHanhViViPham[];
  vuViec: IVuViecInfo & { thoiGianVp: Date; diaDiemVp: string };
  noiDungChiTiet: INoiDungChiTiet[];
}

export interface IRequestBodyBb01
  extends Omit<IBb01, 'vuViec' | 'trangThai' | 'ma' | 'maBieuMau' | 'noiDung'> {
  ma?: string;
  maBieuMau?: string;
  noiDung: Omit<INoiDungBb01, 'hoi' | 'tai' | 'phuongTienViPham' | 'bienSo'>;
}
