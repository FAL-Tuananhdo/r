import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQd } from '../model';

export interface IBb23 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungBb23;
}

export interface ITangVatPhatHien {
  ten: string;
  soLuong: string;
  donViTinh: string;
  nhanHieu?: string;
  chungLoai?: string;
  tinhTrang?: string;
}

export interface INoiDungBb23 {
  canCu: ICanCu;
  maVuViec?: string;
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien: IDoiTuongChungKien[];
  yKienBenViPham?: string;
  yKienBoSung?: string;
  yKienNguoiBiKham?: string;
  yKienNguoiChungKien?: string;
  bienBanLapXongHoi?: IBbQdLapXong;
  tangVatPhatHien: ITangVatPhatHien[];
}

export interface IRequestBodyCreateBb23
  extends Pick<
    IBb23,
    'maBieuMau' | 'maVuViec' | 'diaDiemLap' | 'maNhapTay' | 'noiDung' | 'thoiGianLap'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb23 = Pick<
  IBb23,
  'diaDiemLap' | 'noiDung' | 'thoiGianLap' | 'maCha' | 'maBieuMauCha' | 'maNhapTay'
>;
