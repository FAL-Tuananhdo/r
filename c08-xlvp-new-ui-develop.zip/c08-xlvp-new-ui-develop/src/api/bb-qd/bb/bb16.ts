import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface INoiDungBb16 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBienBanLapXong;
  yKienBoSung?: string;
}

export interface IBienBanLapXong {
  thoiGian: Date;
  soTo: number;
  soBan: number;
}

export interface IBb16 extends IBbQd {
  diaDiemLap: string;
  thoiGianLap: Date;
  noiDung: INoiDungBb16;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateBb16
  extends Pick<
    IBb16,
    'maBieuMau' | 'maVuViec' | 'diaDiemLap' | 'maNhapTay' | 'noiDung' | 'tangVat' | 'thoiGianLap'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb16 = Pick<
  IBb16,
  'diaDiemLap' | 'noiDung' | 'tangVat' | 'thoiGianLap'
>;
