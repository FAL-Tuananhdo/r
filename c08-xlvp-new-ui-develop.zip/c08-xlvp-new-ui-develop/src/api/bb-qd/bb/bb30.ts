import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IBbQdLienQuan } from '../common/bbqd-lien-quan';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface INoiDungBb30 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  nguoiNhanBanGiao: ICanBoNhapTay;
  taiLieuKemTheo: IBbQdLienQuan[];
  bienBanLapXong: IBbQdLapXong;
}

export interface IBb30 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungBb30;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateBb30
  extends Pick<
    IBb30,
    'maVuViec' | 'maBieuMau' | 'maNhapTay' | 'diaDiemLap' | 'thoiGianLap' | 'noiDung' | 'tangVat'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IUpdateRequestBodyBb30 = Omit<
  IRequestBodyCreateBb30,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
