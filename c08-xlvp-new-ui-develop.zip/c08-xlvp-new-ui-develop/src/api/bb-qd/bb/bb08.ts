import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IBb08 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb08;
  tangVat: ITangVat[];
}

export interface INoiDungBb08 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  chungKien?: IDoiTuongChungKien[];
  yKienBenViPham?: string;
  lyDoKhongKyBB: string;
  lapXong?: {
    thoiGian: Date;
    soTo: number;
    soBan: number;
  };
}

export interface IRequestBodyCreateBb08
  extends Pick<
    IBb08,
    'maBieuMau' | 'maVuViec' | 'diaDiemLap' | 'maNhapTay' | 'noiDung' | 'tangVat' | 'thoiGianLap'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb08 = Pick<
  IBb08,
  'diaDiemLap' | 'noiDung' | 'tangVat' | 'thoiGianLap'
>;
