import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanCu } from '../common/can-cu';
import { ITangVat, ITangVatKhac, ITangVatPhuongTien } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IThongTinGiaTriTangVat {
  donGia: number;
  thanhTien?: number;
}

export interface ITangVatDinhGia extends Omit<ITangVat, 'thongTin'> {
  thongTin: ITangVatPhuongTien | ITangVatKhac;
}

export interface IHoiDongDinhGia {
  nguoiQuyetDinh: ICanBoNhapTay;
  daiDienBoPhan?: ICanBoNhapTay;
  daiDienCqLienQuan: ICanBoNhapTay;
  daiDienCqTaiChinh: ICanBoNhapTay;
}

export interface IBb04 extends IBbQd {
  noiDung: INoiDungBb04;
  tangVat: ITangVatDinhGia[];
}
export interface INoiDungBb04 {
  canCuXacDinh: string;
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  bienBanLapXong: IBbQdLapXong;
  hoiDongDinhGia: IHoiDongDinhGia;
}

export type IRequestBodyCreateBb04 = Pick<
  IBb04,
  | 'maNhapTay'
  | 'maCha'
  | 'maBieuMauCha'
  | 'maBieuMau'
  | 'maVuViec'
  | 'thoiGianLap'
  | 'diaDiemLap'
  | 'tangVat'
  | 'noiDung'
>;

export type IUpdateRequestBodyBb04 = Omit<
  IRequestBodyCreateBb04,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
