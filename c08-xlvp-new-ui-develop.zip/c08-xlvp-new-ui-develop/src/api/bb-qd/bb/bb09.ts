import { ILoaiDoiTuongXacMinh } from '/@/const/type';

import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IThongTinXacMinh } from '../common/thong-tin-xac-minh';

export interface INoiDungBb09 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  doiTuongXacMinh: INguoiXacMinh[];
  thongTinXacMinh: IThongTinXacMinh[];
  lapXong: IBbQdLapXong;
  lyDoKhongKy?: string;
  yKienBenViPham?: string;
  yKienBenXacMinh?: string;
  donViThucHienBpkp?: string;
}

export interface INguoiXacMinh {
  loai: ILoaiDoiTuongXacMinh;
  ten: string;
  ngheNghiep?: string;
  diaChi?: string;
  chucVu?: string;
  coQuan?: string;
}

export interface IBb09 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb09;
}

export interface IRequestBodyCreateBb09
  extends Pick<
    IBb09,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb09 = Pick<IBb09, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
