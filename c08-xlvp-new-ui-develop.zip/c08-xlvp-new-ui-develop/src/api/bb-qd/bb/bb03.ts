import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCuBBQD } from '../common/can-cu';
import { IBbQd } from '../model';

export interface IBb03 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb03;
}

export interface IYKienNguoiCoThamQuyen {
  yKienCcpl?: string;
  yKienTtlq?: string;
  yKienHtxp?: string;
}

export interface IThongBaoGiaiTrinh {
  so?: string;
  kyHieu?: string;
  ngayRaTb?: Date;
  nguoiCoThamQuyenTb?: string;
}

export interface ICanCuBb03 {
  bbqd?: ICanCuBBQD[];
  ngayLapVbgt?: Date;
  tbGiaiTrinh?: IThongBaoGiaiTrinh;
}

export interface INoiDungBb03 extends IYKienNguoiCoThamQuyen {
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBbQdLapXong;
  yKienNvp: string;
  canCu?: ICanCuBb03;
  lyDoKhongKyBienBan?: string;
}

export interface IRequestBodyCreateBb03
  extends Pick<
    IBb03,
    'maBieuMau' | 'diaDiemLap' | 'noiDung' | 'thoiGianLap' | 'maNhapTay' | 'maVuViec'
  > {
  maBieuMauCha: string;
  maCha: string;
}

export type IRequestBodyUpdateBb03 = Pick<IBb03, 'diaDiemLap' | 'noiDung' | 'thoiGianLap'>;
