import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { ICanBo } from '../../can-bo';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';

export interface IBb06 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb06;
}

export interface INoiDungBb06 {
  canCu: ICanCu;
  maVuViec?: string;
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien: IDoiTuongChungKien[];
  lapXong: IBbQdLapXong;
  lyDoKhongKyBb?: string;
}

export interface IRequestBodyCreateBb06
  extends Pick<
    IBb06,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb06 = Pick<
  IBb06,
  'diaDiemLap' | 'noiDung' | 'thoiGianLap' | 'maCha' | 'maBieuMauCha' | 'maNhapTay'
>;
