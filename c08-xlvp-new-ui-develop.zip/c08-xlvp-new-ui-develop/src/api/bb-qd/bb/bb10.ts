import { ICanBo } from '../../can-bo';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IThongTinXacMinh } from '../common/thong-tin-xac-minh';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';

export interface INoiDungBb10 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  thongTinXacMinh: IThongTinXacMinh[];
  doiTuongChungKien: IDoiTuongChungKien[];
  lapXong: IBbQdLapXong;
  lyDoKhongKy: string;
  coQuanPhoiHop: IDoiTuongChungKien;
}

export interface IBb10 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb10;
}

export interface IRequestBodyCreateBb10
  extends Pick<
    IBb10,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb10 = Pick<IBb10, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
