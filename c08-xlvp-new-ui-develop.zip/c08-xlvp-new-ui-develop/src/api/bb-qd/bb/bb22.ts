import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanBo } from '../../can-bo';
import { IHanhViViPham } from '../../common';

export interface INoiDungBb22 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  nguoiBanGiao: ICanBoNhapTay;
  doiTuongChungKien: IDoiTuongChungKien;
  doiTuongThietHai: IDoiTuongChungKien[];
  daiDienChinhQuyen: ICanBoNhapTay;
  lyDoKhongKy?: string;
  lapXong: IBbQdLapXong;
  tinhTrangSucKhoe: string;
  tangVatTaiSan?: string;
  noiDungSuViec?: string;
  tinhTietKhac?: string;
}

export interface IBb22 extends Omit<IBbQd, 'diaDiemLap'> {
  diaDiemLap: string;
  hanhViViPham: IHanhViViPham[];
  noiDung: INoiDungBb22;
}

export interface IRequestBodyCreateBb22
  extends Pick<
    IBb22,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb22 = Pick<IBb22, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
