import { IThongTinXacMinhTaiSan } from './../common/thong-tin-xac-minh';
import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQd } from '../model';

export interface IBb12 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb12;
}

export interface INoiDungBb12 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien: IDoiTuongChungKien[];
  nguoiPhoiHop: ICanBoNhapTay;
  taiSanKeBien: IThongTinXacMinhTaiSan[];
  lyDoKhongKy?: string;
  lapXong: IBbQdLapXong;
}

export interface IRequestBodyCreateBb12
  extends Pick<
    IBb12,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb12 = Pick<IBb12, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
