import { IThongTinXacMinhTaiSan } from './../common/thong-tin-xac-minh';
import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface IBb13 extends IBbQd {
  diaDiemLap: string;
  noiDung: INoiDungBb13;
}

export interface INoiDungBb13 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  doiTuongBaoQuan: IDoiTuongChungKien[];
  doiTuongChungKien: IDoiTuongChungKien[];
  taiSanKeBien: IThongTinXacMinhTaiSan[];
  lyDoKhongKy: string;
  lapXong: IBbQdLapXong;
}

export interface IRequestBodyCreateBb13
  extends Pick<
    IBb13,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb13 = Pick<IBb13, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
