import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface INoiDungBb19 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  bienBanLapXong: IBbQdLapXong;
  yKienBoSung?: string;
}

export interface IBb19 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb19;
  tangVat: ITangVat[];
}

export type IRequestBodyCreateBb19 = Pick<
  IBb19,
  | 'maBieuMau'
  | 'maVuViec'
  | 'diaDiemLap'
  | 'noiDung'
  | 'thoiGianLap'
  | 'maNhapTay'
  | 'maCha'
  | 'maBieuMauCha'
>;

export type IRequestBodyUpdateBb19 = Pick<
  IRequestBodyCreateBb19,
  'noiDung' | 'diaDiemLap' | 'thoiGianLap'
>;
