import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQd } from '../model';

export interface IBb18a extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb18a;
}

export interface INoiDungBb18a {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  soTien: number;
  lyDoDatTien?: string;
  yKienBoSung?: string;
  bienBanLapXongHoi?: {
    thoiGian: Date;
    soTo: number;
    soBan: number;
  };
}

export interface IRequestBodyCreateBb18a
  extends Pick<
    IBb18a,
    'maBieuMau' | 'maVuViec' | 'diaDiemLap' | 'maNhapTay' | 'noiDung' | 'thoiGianLap'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb18a = Pick<IBb18a, 'diaDiemLap' | 'noiDung' | 'thoiGianLap'>;
