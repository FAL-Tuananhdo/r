import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IBb17 extends Omit<IBbQd, 'diaDiemLap'> {
  noiDung: INoiDungBb17;
  tangVat: ITangVat[];
  diaDiemLap: string;
}

export interface INoiDungBb17 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  bienBanLapXongHoi: IBbQdLapXong;
  yKienBoSung?: string;
}

export type ICreateRequestBodyBb17 = Pick<
  IBb17,
  | 'maVuViec'
  | 'maBieuMau'
  | 'maCha'
  | 'maBieuMauCha'
  | 'maNhapTay'
  | 'thoiGianLap'
  | 'diaDiemLap'
  | 'tangVat'
  | 'noiDung'
>;
export type IUpdateRequestBodyBb17 = Omit<
  ICreateRequestBodyBb17,
  'maBieuMau' | 'maVuViec' | 'maBieuMau' | 'maBieuMauCha' | 'linhVuc'
>;
