import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IDoiTuongThietHai } from '../common/doi-tuong-thiet-hai';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IBb02 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb02;
  tangVat: ITangVat[];
}

export interface INoiDungBb02 {
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBbQdLapXong;
  dienBien: string;
  hienTruong: string;
  yKienBenLienQuan: string;
  doiTuongChungKien?: IDoiTuongChungKien[];
  doiTuongThietHai?: IDoiTuongThietHai[];
  thietHai?: string;
  yKienBenThietHai?: string;
  yKienBenChungKien?: string;
  bienPhap?: string;
  lyDoKhongKy?: string;
}

export type IRequestBodyCreateBb02 = Pick<
  IBb02,
  | 'maBieuMau'
  | 'maVuViec'
  | 'diaDiemLap'
  | 'noiDung'
  | 'thoiGianLap'
  | 'maNhapTay'
  | 'noiDung'
  | 'tangVat'
>;

export type IRequestBodyUpdateBb02 = Pick<
  IRequestBodyCreateBb02,
  'noiDung' | 'diaDiemLap' | 'thoiGianLap' | 'tangVat'
>;
