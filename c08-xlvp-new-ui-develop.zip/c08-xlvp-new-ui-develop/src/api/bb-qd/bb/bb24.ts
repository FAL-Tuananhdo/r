import { ITangVatPhatHien } from '../common/tang-vat-phat-hien';
import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQd } from '../model';
import { IPhuongTienDoVatCanKham } from '../common/phuong-tien-do-vat';

export interface INoiDungBb24 {
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien: IDoiTuongChungKien[];
  bienBanLapXongHoi: IBbQdLapXong;
  canCu: ICanCu;
  yKienBoSung?: string;
  yKienNguoiBiKham?: string;
  yKienNguoiChungKien?: string;
  phuongTienDoVat?: IPhuongTienDoVatCanKham[];
  tangVatPhatHien?: ITangVatPhatHien[];
}
export interface IBb24 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungBb24;
}

export interface IRequestBodyCreateBb24
  extends Pick<
    IBb24,
    'maVuViec' | 'maBieuMau' | 'maNhapTay' | 'diaDiemLap' | 'thoiGianLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IUpdateRequestBodyBb24 = Omit<
  IRequestBodyCreateBb24,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
