import { ICanBo } from '../../can-bo';
import { IHanhViViPham } from '../../common';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongThietHai } from '../common/doi-tuong-thiet-hai';
import { IDoiTuongXacMinh } from '../common/doi-tuong-xac-minh';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IBb05 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb05;
  tangVat: ITangVat[];
  hanhViViPham: Pick<IHanhViViPham, 'maHVVP' | 'maTTND'>[];
}
export interface INoiDungBb05 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBbQdLapXong;
  mucDoThietHai: string;
  lyDoKhongKyBienBan?: string;
  doiTuongXacMinh?: IDoiTuongXacMinh[];
  doiTuongThietHai?: IDoiTuongThietHai[];
  yKienBenViPham?: string;
  yKienBenChungKien?: string;
  yKienBenThietHai?: string;
  ttGiam?: string;
  ttTang?: string;
  ttKhac?: string;
}

export type IRequestBodyCreateBb05 = Pick<
  IBb05,
  | 'maBieuMau'
  | 'maVuViec'
  | 'diaDiemLap'
  | 'noiDung'
  | 'tangVat'
  | 'thoiGianLap'
  | 'maNhapTay'
  | 'hanhViViPham'
  | 'maCha'
  | 'maBieuMauCha'
>;

export type IRequestBodyUpdateBb05 = Pick<
  IRequestBodyCreateBb05,
  'noiDung' | 'diaDiemLap' | 'thoiGianLap' | 'tangVat' | 'hanhViViPham' | 'maNhapTay'
>;
