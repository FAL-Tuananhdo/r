import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';

export interface IBb07 extends IBbQd {
  diaDiemLap: string;
  noiDung: INoiDungBb07;
}

export interface INoiDungBb07 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien: IDoiTuongChungKien[];
  lapXong: IBbQdLapXong;
}

export interface IRequestBodyCreateBb07
  extends Pick<
    IBb07,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb07 = Pick<IBb07, 'diaDiemLap' | 'noiDung' | 'thoiGianLap'>;
