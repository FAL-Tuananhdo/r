import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IYKienTrinhBay {
  yKienBenViPham?: string;
  yKienBenChungKien?: string;
  yKienBoSung?: string;
}

export interface INoiDungBb15 extends IYKienTrinhBay {
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBbQdLapXong;
  lyDoKhongKyBB?: string;
  chungKien?: IDoiTuongChungKien[];
}

export interface IBb15 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungBb15;
  tangVat?: ITangVat[];
}

export interface IRequestBodyCreateBb15
  extends Pick<
    IBb15,
    'maBieuMau' | 'maVuViec' | 'diaDiemLap' | 'maNhapTay' | 'noiDung' | 'tangVat' | 'thoiGianLap'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb15 = Pick<
  IBb15,
  'diaDiemLap' | 'noiDung' | 'tangVat' | 'thoiGianLap'
>;
