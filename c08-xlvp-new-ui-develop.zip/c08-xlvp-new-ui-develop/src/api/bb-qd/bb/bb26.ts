import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface INoiDungBb26 {
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien: IDoiTuongChungKien[];
  bienBanLapXongHoi: IBbQdLapXong;
  canCu: ICanCu;
  nguoiBaoQuan: ICanBoNhapTay;
  yKienBoSung?: string;
}

export interface IBb26 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungBb26;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateBb26
  extends Pick<
    IBb26,
    'maVuViec' | 'maBieuMau' | 'maNhapTay' | 'diaDiemLap' | 'thoiGianLap' | 'noiDung' | 'tangVat'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IUpdateRequestBodyBb26 = Omit<
  IRequestBodyCreateBb26,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
