import { ICanBoNhapTay } from './../common/can-bo-nhap-tay';
import { IThongTinXacMinhTaiSan } from '../common/thong-tin-xac-minh';
import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';

export interface IBb14 extends IBbQd {
  diaDiemLap: string;
  noiDung: INoiDungBb14;
}

export interface INoiDungBb14 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  doiTuongBanGiao: IDoiTuongChungKien[];
  doiTuongTiepNhan: ICanBoNhapTay;
  taiSanKeBien: IThongTinXacMinhTaiSan[];
  lapXong: IBbQdLapXong;
  lyDoKhongKy?: string;
}

export interface IRequestBodyCreateBb14
  extends Pick<
    IBb14,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb14 = Pick<IBb14, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
