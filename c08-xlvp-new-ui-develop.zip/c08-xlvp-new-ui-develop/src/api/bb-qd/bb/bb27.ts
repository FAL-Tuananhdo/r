import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanCu } from '../common/can-cu';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface INoiDungBb27 {
  nguoiCoThamQuyen: ICanBo;
  bienBanLapXongHoi: IBbQdLapXong;
  canCu: ICanCu;
  nguoiBaoQuan: ICanBoNhapTay;
  yKienBoSung?: string;
}

export interface IBb27 extends IBbQd {
  thoiGianLap: Date;
  noiDung: INoiDungBb27;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateBb27
  extends Pick<
    IBb27,
    'maVuViec' | 'maBieuMau' | 'maNhapTay' | 'diaDiemLap' | 'thoiGianLap' | 'noiDung' | 'tangVat'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IUpdateRequestBodyBb27 = Omit<
  IRequestBodyCreateBb27,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha' | 'maNhapTay'
>;
