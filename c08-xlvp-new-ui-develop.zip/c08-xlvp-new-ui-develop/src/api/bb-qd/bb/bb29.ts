import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';
import { ICanCu } from '../common/can-cu';
import { ITaiLieuBbQd } from '../common/bbqd-lien-quan';
import { ITangVat } from '../common/tang-vat-giay-to';
import { IBbQd } from '../model';

export interface IBb29 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb29;
  tangVat?: ITangVat[];
}

export interface INoiDungBb29 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  nguoiBaoQuan: ICanBoNhapTay;
  bienBanLapXongHoi: IBbQdLapXong;
  taiLieuKemTheo: ITaiLieuBbQd;
}

export type IRequestBodyCreateBb29 = Pick<
  IBb29,
  | 'maBieuMau'
  | 'maVuViec'
  | 'diaDiemLap'
  | 'noiDung'
  | 'tangVat'
  | 'thoiGianLap'
  | 'maNhapTay'
  | 'maCha'
  | 'maBieuMauCha'
>;

export type IRequestBodyUpdateBb29 = Pick<
  IBb29,
  'diaDiemLap' | 'noiDung' | 'thoiGianLap' | 'tangVat'
>;
