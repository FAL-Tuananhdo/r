import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IBbQd } from '../model';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface INoiDungBb20 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBbQdLapXong;
  yKienTrinhBay: string;
  yKienBoSung?: string;
}

export interface IBb20 extends Omit<IBbQd, 'thoiGianLap' | 'diaDiemLap'> {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb20;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateBb20
  extends Pick<
    IBb20,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung' | 'tangVat'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb20 = Pick<
  IBb20,
  'thoiGianLap' | 'diaDiemLap' | 'noiDung' | 'tangVat'
>;
