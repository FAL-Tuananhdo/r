import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { IBbQd } from '../model';

export interface IYKienTrinhBay {
  yKienTrinhBayChu?: string;
  yKienNguoiChungKien?: string;
  yKienBoSung?: string;
}

export interface IBb25 extends IBbQd {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb25;
}

export interface INoiDungBb25 extends IYKienTrinhBay {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  bienBanLapXong: IBbQdLapXong;
  diaChiKham?: string;
  doiTuongChungKien: IDoiTuongChungKien[];
  tangVatPhatHiens: ITangVatPhatHienDuoc[];
}

export interface ITangVatPhatHienDuoc {
  ten: string;
  donViTinh: string;
  soLuong: number;
  tinhTrang?: string;
  ghiChu?: string;
  chungLoai?: string;
  nhanHieu?: string;
}

export type IRequestBodyCreateBb25 = Pick<
  IBb25,
  | 'maCha'
  | 'maBieuMauCha'
  | 'maNhapTay'
  | 'maVuViec'
  | 'maBieuMau'
  | 'thoiGianLap'
  | 'diaDiemLap'
  | 'noiDung'
>;

export type IUpdateRequestBodyBb25 = Omit<
  IRequestBodyCreateBb25,
  'maBieuMau' | 'maVuViec' | 'maCha' | 'maBieuMauCha'
>;
