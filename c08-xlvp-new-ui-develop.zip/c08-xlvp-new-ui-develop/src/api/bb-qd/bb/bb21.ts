import { ICanBo } from '../../can-bo';
import { ICanCu } from '../common/can-cu';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IBbQd } from '../model';
import { ITangVat } from '../common/tang-vat-giay-to';

export interface ICoQuanTieuHuy {
  maTangVat: string;
  tenCoQuan: string;
  bienPhapTieuHuy: string;
  tenNguoiDaiDien?: string;
  chucDanhNguoiDaiDien?: string;
}

export interface INoiDungBb21 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  lapXong: IBbQdLapXong;
  coQuanTieuHuy: ICoQuanTieuHuy[];
  yKienBoSung?: string;
}

export interface IBb21 extends Omit<IBbQd, 'thoiGianLap' | 'diaDiemLap'> {
  thoiGianLap: Date;
  diaDiemLap: string;
  noiDung: INoiDungBb21;
  tangVat: ITangVat[];
}

export interface IRequestBodyCreateBb21
  extends Pick<
    IBb21,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung' | 'tangVat'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb21 = Pick<
  IBb21,
  'thoiGianLap' | 'diaDiemLap' | 'noiDung' | 'tangVat'
>;
