import { IThoiHan } from '/@/const';

import { ICanBo } from '../../can-bo';
import { IBbQdLapXong } from '../common/bb-qd-lap-xong';
import { IBbQd } from '../model';
import { ICanCu } from '../common/can-cu';
import { IDoiTuongChungKien } from '../common/doi-tuong-chung-kien';
import { ICanBoNhapTay } from '../common/can-bo-nhap-tay';

export interface IBb11 extends IBbQd {
  diaDiemLap: string;
  noiDung: INoiDungBb11;
}

export interface IBienPhapKhacPhucHauQua {
  hauQua?: string;
  bienPhap: string;
  thoiHan?: IThoiHan;
}

export interface IKetQuaThucHien {
  bienPhapKhacPhucHauQua: IBienPhapKhacPhucHauQua;
  ketQua: string;
}

export interface INoiDungBb11 {
  canCu: ICanCu;
  nguoiCoThamQuyen: ICanBo;
  doiTuongChungKien?: IDoiTuongChungKien[];
  ketQuaBPKPHQS: IKetQuaThucHien[];
  lyDoKhongKy: string;
  lapXong: IBbQdLapXong;
  donViPhoiHop: ICanBoNhapTay;
}

export interface IRequestBodyCreateBb11
  extends Pick<
    IBb11,
    'maNhapTay' | 'maVuViec' | 'maBieuMau' | 'thoiGianLap' | 'diaDiemLap' | 'noiDung'
  > {
  maCha: string;
  maBieuMauCha: string;
}

export type IRequestBodyUpdateBb11 = Pick<IBb11, 'thoiGianLap' | 'diaDiemLap' | 'noiDung'>;
