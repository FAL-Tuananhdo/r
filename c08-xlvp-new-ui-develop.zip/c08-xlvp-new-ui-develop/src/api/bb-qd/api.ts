import qs from 'qs';

import { xlvpHttp } from '/@/utils/http/axios';
import { IKySoType } from '/@/const';

import { XlvpEndPoint } from '../apiConst';
import { BaseApi } from '../baseApi';
import {
  IBbQd,
  IPheDuyetQuyetDinh,
  ILIchSuThayDoiBbQd,
  IResultPheDuyetBbQd,
  ISearchLichSuBbQd,
  ISearchParamsBbQd,
  IQdPheDuyet,
} from './model';
import { BasePagination } from '../types';
import { IThanhToan } from './common/thanh-toan';
import { IResultKySo } from '../common/ky_so';

export class BienBanQuyetDinhApi extends BaseApi<IBbQd> {
  constructor() {
    super(xlvpHttp, XlvpEndPoint.BbQd);
  }

  async get<T = IBbQd>(type: string, code: string): Promise<T> {
    return await this.http.get<T>({
      url: `${this.url}/${type}/${code}`,
    });
  }

  async print(type: string, code: string) {
    const url = `${this.url}/${type}/${code}/print`;
    return this.http.print({ url: url });
  }

  async update<T>(type: string, code: string, body: T): Promise<T> {
    const res = await this.http.put<T>({
      url: `${this.url}/${type}/${code}`,
      params: body,
    });
    return res as T;
  }

  async delete(type: string, code: string): Promise<Boolean> {
    return await this.http.delete<Boolean>({
      url: `${this.url}/${type}/${code}`,
    });
  }

  async getAll(params?: ISearchParamsBbQd): Promise<BasePagination<IBbQd>> {
    const res = await this.http.get<BasePagination<IBbQd>>({
      url: this.url,
      params: params,
    });
    res.items.forEach((item: IBbQd) => {
      item.children = item.hasChild ? [] : undefined;
    });
    return res;
  }

  async thanhToan(
    type: string,
    code: string,
    body: Omit<IThanhToan, 'ma' | 'maBieuMau'>,
  ): Promise<IThanhToan> {
    const res = await this.http.put<IThanhToan>({
      url: `${this.url}/${type}/${code}/nop-phat`,
      params: body,
    });

    return res;
  }

  async getDetailThanhToan(type: string, code: string): Promise<IThanhToan> {
    return await this.http.get({
      url: `${this.url}/${type}/${code}/nop-phat`,
    });
  }

  async printBienLai(type: string, code: string) {
    const url = `${this.url}/${type}/${code}/nop-phat/print`;
    return this.http.print({ url: url });
  }

  async downloadKySo(body: { list: IPheDuyetQuyetDinh[] }) {
    return this.http.downloadFile({
      url: `${this.url}/download-compressed-file`,
      params: body,
      method: 'POST',
    });
  }

  async getAllQuyetDinhPheDuyet(params?: ISearchParamsBbQd): Promise<BasePagination<IQdPheDuyet>> {
    const res = await this.http.get<BasePagination<IQdPheDuyet>>({
      url: `${this.url}/phe-duyet`,
      params: params,
    });
    return res;
  }

  async pheDuyet(body: IPheDuyetQuyetDinh[]) {
    return this.http.put<IResultPheDuyetBbQd>({
      url: `${this.url}/phe-duyet`,
      params: body,
    });
  }

  async pheDuyetKySo(type: string, code: string, base64: string) {
    return this.http.post<IResultKySo>({
      url: `${this.url}/phe-duyet/${type}/${code}/ky-so`,
      params: { data: base64 },
    });
  }

  async uploadKySo<T>(file: File, loaiFileEnum: IKySoType) {
    return this.http.uploadFile<T>(
      {
        url: `${this.url}/phe-duyet/ky-so`,
        responseType: 'json',
      },
      {
        file: file,
        data: {
          ['loaiFileEnum']: loaiFileEnum,
        },
      },
    );
  }

  async createThongBao<T>(type: string, code: string, body: T) {
    const res = await this.http.post<T>({
      url: `${this.url}/${type}/${code}/thong-bao`,
      params: body,
    });
    return res as T;
  }

  async updateThongBao<T>(type: string, code: string, loaiThongBao: string, body: T) {
    const res = await this.http.put<T>({
      url: `${this.url}/${type}/${code}/thong-bao/${loaiThongBao}`,
      params: body,
    });
    return res as T;
  }

  async getThongBao<T>(type: string, code: string, loaiThongBao: string) {
    return await this.http.get<T>({
      url: `${this.url}/${type}/${code}/thong-bao/${loaiThongBao}`,
    });
  }

  async printThongBao(type: string, code: string, loaiThongBao: string) {
    const url = `${this.url}/${type}/${code}/thong-bao/${loaiThongBao}/print`;
    return this.http.print({ url: url });
  }

  async getLichSuBbQd(
    type: string,
    code: string,
    params?: ISearchLichSuBbQd,
  ): Promise<BasePagination<ILIchSuThayDoiBbQd>> {
    return this.http.get<BasePagination<ILIchSuThayDoiBbQd>>({
      url: `${this.url}/${type}/${code}/lich-su`,
      params: params,
      paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });
  }

  async downloadExcelLichSuBbQd(type: string, code: string, params?: ISearchLichSuBbQd) {
    return this.http.downloadFile({
      url: `${this.url}/${type}/${code}/lich-su/export/excel`,
      params,
      paramsSerializer: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
    });
  }
}
