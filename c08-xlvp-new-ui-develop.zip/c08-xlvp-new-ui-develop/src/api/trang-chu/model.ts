import { Dayjs } from 'dayjs';

export interface ISearchParamsThongKe {
  tuNgay: Dayjs;
  denNgay: Dayjs;
}

export interface IThongKe {
  key: string;
  label: string;
  value: number;
}

export interface ITrangChuResponse {
  dataResponse: IThongKe[];
}
