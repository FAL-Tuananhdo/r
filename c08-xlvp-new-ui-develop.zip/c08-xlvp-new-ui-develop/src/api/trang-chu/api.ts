import { baoCaoThongKeHttp } from '/@/utils/http/axios';

import { BaoCaoThongKeEndPoint } from '../apiConst';
import { ITrangChuResponse, ISearchParamsThongKe } from './model';

export class TrangChuApi {
  async searchGiayToHetHan(params: ISearchParamsThongKe): Promise<ITrangChuResponse> {
    return baoCaoThongKeHttp.get<ITrangChuResponse>({
      url: BaoCaoThongKeEndPoint.Dashboard,
      params: { ...params, reportCode: 'dashBoardHetHan' },
    });
  }

  async searchVphcDaThanhToan(params: ISearchParamsThongKe): Promise<ITrangChuResponse> {
    return baoCaoThongKeHttp.get<ITrangChuResponse>({
      url: BaoCaoThongKeEndPoint.Dashboard,
      params: { ...params, reportCode: 'dashBoardThanhToanChart' },
    });
  }

  async searchTongViPhamHanhChinh(params: ISearchParamsThongKe): Promise<ITrangChuResponse> {
    return baoCaoThongKeHttp.get<ITrangChuResponse>({
      url: BaoCaoThongKeEndPoint.Dashboard,
      params: { ...params, reportCode: 'dashBoardTongVPHC' },
    });
  }

  async searchThongKePhatNguoi(params: ISearchParamsThongKe): Promise<ITrangChuResponse> {
    return baoCaoThongKeHttp.get<ITrangChuResponse>({
      url: BaoCaoThongKeEndPoint.Dashboard,
      params: { ...params, reportCode: 'dashBoardPhatNguoi' },
    });
  }
}
