import { RequestOptions } from '/#/axios';

import { VAxios } from '../utils/http/axios/Axios';
import { BaseInfo, BasePagination, IBaseSearchListQueryParams } from './types';

export abstract class BaseApi<T extends BaseInfo> {
  constructor(protected http: VAxios, protected url: string) {}

  async getAll<P>(
    params = {} as IBaseSearchListQueryParams & P,
    options?: RequestOptions,
  ): Promise<BasePagination<T>> {
    return this.http.get<BasePagination<T>>(
      {
        url: this.url,
        params: params,
      },
      options,
    );
  }

  async getById(id: String): Promise<T> {
    return this.http.get<T>({
      url: `${this.url}/${id}`,
    });
  }

  async updateById<P>(id: String, body: P): Promise<T> {
    return this.http.put<T>({
      url: `${this.url}/${id}`,
      params: body,
    });
  }

  async create<P, R = T>(body: P): Promise<R> {
    return this.http.post<R>({
      url: `${this.url}`,
      params: body,
    });
  }

  async deleteById(id: String): Promise<Boolean> {
    return this.http.delete<Boolean>({
      url: `${this.url}/${id}`,
    });
  }
}
