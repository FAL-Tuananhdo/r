import { RangeValue } from '/@/views/bao-cao-thong-ke/use/UseDisableRangeExport';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';

export interface IBctkNopPhat
  extends Pick<
      IBaoCaoThongKe,
      | 'reportCode'
      | 'fileType'
      | 'linhVuc'
      | 'donVi'
      | 'donViTraGiayTo'
      | 'tuNgay'
      | 'denNgay'
      | 'trangThai'
    >,
    Omit<IBaoCaoThongKe, 'tuNgay' | 'denNgay'> {
  '[tuNgay, denNgay]': RangeValue;
  linhVucArray?: Array<number>;
}
