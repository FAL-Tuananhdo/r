import { BaseInfo } from '/@/api';

export interface IHanhViViPham extends BaseInfo {
  page?: string;
  size?: string;
  strParam?: string;
  name: string;
  code: string;
}
