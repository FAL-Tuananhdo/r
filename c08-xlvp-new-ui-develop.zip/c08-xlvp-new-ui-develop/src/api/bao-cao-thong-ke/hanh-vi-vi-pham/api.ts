import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaseApi } from '/@/api/baseApi';
import { INhomHanhViViPham } from '/@/api/bao-cao-thong-ke/nhom-hanh-vi-vi-pham/model';
import { RequestOptions } from '/#/axios';
import { BctkBasePagination } from '/@/api/bao-cao-thong-ke/model';

export class DanhMucHanhViViPhamApi extends BaseApi<INhomHanhViViPham> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.HanhViViViPham);
  }
  async getAllNhomHvvp<P>(
    params = {} as INhomHanhViViPham & P,
    options?: RequestOptions,
  ): Promise<BctkBasePagination<INhomHanhViViPham>> {
    return this.http.get<BctkBasePagination<INhomHanhViViPham>>(
      {
        url: this.url,
        params: params,
      },
      options,
    );
  }
}
