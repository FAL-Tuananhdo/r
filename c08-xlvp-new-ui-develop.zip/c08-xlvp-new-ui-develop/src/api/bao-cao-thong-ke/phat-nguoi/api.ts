import { baoCaoThongKeHttp } from '/@/utils/http/axios';

import { BaoCaoThongKeEndPoint } from '../../apiConst';
import { IBcPhatNguoi } from './model';

export class BcPhatNguoi {
  async exportExcel(params: IBcPhatNguoi): Promise<void> {
    baoCaoThongKeHttp.downloadFile({
      url: `${BaoCaoThongKeEndPoint.ExportExcel}`,
      params: params,
    });
  }
}
