import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';

export interface IBcPhatNguoi
  extends Pick<
    IBaoCaoThongKe,
    | 'reportCode'
    | 'fileType'
    | 'donVi'
    | 'tuNgay'
    | 'denNgay'
    | 'linhVuc'
    | 'trangThai'
    | 'username'
  > {
  loai?: string;
  diaDiem?: string;
  tuyenDuong: string;
  diaBanArray?: Array<string>;
}
