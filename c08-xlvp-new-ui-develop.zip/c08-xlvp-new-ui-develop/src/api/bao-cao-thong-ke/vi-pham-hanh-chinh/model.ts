import { BaseInfo } from '/@/api';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { IDanhMucHanhViViPham } from '/@/api/danh-muc/hanh-vi-vi-pham/model';

export interface IBctkViPhamHanhChinh
  extends Pick<
      IBaoCaoThongKe,
      | 'reportCode'
      | 'fileType'
      | 'tuNgay'
      | 'denNgay'
      | 'ngayViPhamTu'
      | 'ngayViPhamDen'
      | 'doTuoiTu'
      | 'doTuoiDen'
      | 'ngheNghiep'
      | 'donVi'
      | 'username'
    >,
    Omit<IBaoCaoThongKe, 'tangVat' | 'phuongTien' | 'hanhVi' | 'linhVuc'> {
  linhVuc?: Array<string>;
  phuongTien?: Array<string>;
  hanhVi?: Array<IDanhMucHanhViViPham>;
  tangVat?: Array<string>;
}

export interface IBctkViPhamHanhChinhGrid extends BaseInfo {
  maTongHopBaoCao: string;
  trangThaiTongHop: string;
  ngayBaoCao: Date;
}
