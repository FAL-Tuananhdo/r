import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { BaseApi } from '/@/api/baseApi';
import {
  IBctkViPhamHanhChinh,
  IBctkViPhamHanhChinhGrid,
} from '/@/api/bao-cao-thong-ke/vi-pham-hanh-chinh/model';
import { BasePagination } from '/@/api';

export class BctkViPhamHanhChinhApi extends BaseApi<IBctkViPhamHanhChinhGrid> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.Reporting);
  }
  async search(params: IBctkViPhamHanhChinh): Promise<BasePagination<IBctkViPhamHanhChinhGrid>> {
    return baoCaoThongKeHttp.get<BasePagination<IBctkViPhamHanhChinhGrid>>({
      url: `${this.url}/search`,
      params: params,
    });
  }

  async exportExcel(id: string): Promise<void> {
    baoCaoThongKeHttp.downloadFile({
      url: `${this.url}/report/${id}`,
    });
  }
}
