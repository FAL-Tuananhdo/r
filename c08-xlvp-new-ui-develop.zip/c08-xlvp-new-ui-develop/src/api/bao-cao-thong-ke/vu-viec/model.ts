import { BaseInfo } from '/@/api';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { IDanhMucHanhViViPham } from '/@/api/danh-muc/hanh-vi-vi-pham/model';

export interface IExportParamBctkVuViec
  extends Pick<IBaoCaoThongKe, 'fileType' | 'donVi' | 'tuNgay' | 'denNgay' | 'bienSo' | 'username'>,
    Omit<IBaoCaoThongKe, 'donViTraGiayTo' | 'phuongTien' | 'hanhVi' | 'linhVuc'> {
  linhVuc?: Array<number>;
  phuongTien?: Array<string>;
  hanhVi?: Array<IDanhMucHanhViViPham>;
}

export interface IBctkVuViec extends BaseInfo {
  maTongHopBc: string;
  tenTrangThaiTh: string;
  maTrangThaiTh: string;
  ngayBc: string | Date;
  reportFile?: string;
}
