import { IBctkVuViec, IExportParamBctkVuViec } from '/@/api/bao-cao-thong-ke/vu-viec/model';
import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { BaseApi } from '/@/api/baseApi';
import { BasePagination } from '/@/api';

export class BctkVuViecApi extends BaseApi<IBctkVuViec> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.Reporting);
  }
  async search(params: IExportParamBctkVuViec): Promise<BasePagination<IBctkVuViec>> {
    return baoCaoThongKeHttp.get<BasePagination<IBctkVuViec>>({
      url: `${this.url}/search`,
      params: params,
    });
  }
}
