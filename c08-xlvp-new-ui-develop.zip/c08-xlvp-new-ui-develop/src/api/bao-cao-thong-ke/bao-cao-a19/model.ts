import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { BaseInfo } from '/@/api';

import { IDanhMucHanhViViPham } from '../../danh-muc/hanh-vi-vi-pham/model';

export interface IBctkA19 extends BaseInfo {
  maTongHopBc: string;
  tenTrangThaiTh: string;
  maTrangThaiTh: string;
  ngayBc: string | Date;
  reportFile?: string;
}

export interface ISearchParamBctkA19
  extends Pick<
      IBaoCaoThongKe,
      | 'reportCode'
      | 'fileType'
      | 'tuNgay'
      | 'denNgay'
      | 'linhVuc'
      | 'nhomHanhVi'
      | 'username'
      | 'donVi'
    >,
    Omit<IBaoCaoThongKe, 'donViTraGiayTo' | 'phuongTien' | 'hanhVi' | 'tangVat'> {
  hanhVi?: Array<IDanhMucHanhViViPham>;
  phuongTien?: Array<string>;
  tangVat?: Array<string>;
}
