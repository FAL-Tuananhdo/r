import { BaseApi } from '/@/api/baseApi';
import { IBctkSoLieu } from '/@/api/bao-cao-thong-ke/so-lieu/model';
import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { IBctkA19, ISearchParamBctkA19 } from '/@/api/bao-cao-thong-ke/bao-cao-a19/model';

export class BctkA19 extends BaseApi<IBctkSoLieu> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.Reporting);
  }

  async search(params: ISearchParamBctkA19): Promise<IBctkA19[]> {
    return baoCaoThongKeHttp.get<IBctkA19[]>({
      url: `${this.url}/search`,
      params: params,
    });
  }
}
