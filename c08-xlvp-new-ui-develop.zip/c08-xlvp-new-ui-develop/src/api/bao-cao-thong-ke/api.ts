import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';

export class BaoCaoThongKeApi {
  async exportExcel(params: IBaoCaoThongKe): Promise<void> {
    await baoCaoThongKeHttp.downloadFile({
      url: `${BaoCaoThongKeEndPoint.ExportExcel}`,
      params: params,
    });
  }

  async getDmAppParams(): Promise<Array<never>> {
    return await baoCaoThongKeHttp.get({
      url: `${BaoCaoThongKeEndPoint.Reporting}/dm-app-params`,
    });
  }
}
