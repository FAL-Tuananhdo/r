import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { BaseApi } from '/@/api/baseApi';
import { BasePagination } from '/@/api';
import { IBcDongBoDM, IBcDongBoDmResponse } from '/@/api/bao-cao-thong-ke/dong-bo-danh-muc/model';

export class BctkDongBoDmApi extends BaseApi<IBcDongBoDmResponse> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.Reporting);
  }
  async search(params: IBcDongBoDM): Promise<BasePagination<IBcDongBoDmResponse>> {
    return baoCaoThongKeHttp.get<BasePagination<IBcDongBoDmResponse>>({
      url: `${this.url}/search`,
      params: params,
    });
  }
}
