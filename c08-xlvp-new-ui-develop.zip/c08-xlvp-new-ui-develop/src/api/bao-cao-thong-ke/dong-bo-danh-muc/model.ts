import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { BaseInfo } from '/@/api';

export interface IBcDongBoDM
  extends Pick<IBaoCaoThongKe, 'fileType' | 'reportCode' | 'tuNgay' | 'denNgay'>,
    Omit<IBaoCaoThongKe, 'tuNgay' | 'denNgay'> {
  loaiDoiSoat?: string;
  loaiDongBo?: string;
}

export interface IBcDongBoDmResponse extends BaseInfo {
  methodType: string;
  maUngdungRequest: string;
  maUngdungResponse: string;
  requestTime: Date;
  responseTime: Date;
  url: string;
}
