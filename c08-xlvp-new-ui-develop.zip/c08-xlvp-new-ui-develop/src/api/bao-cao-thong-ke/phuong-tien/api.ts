import { RequestOptions } from '/#/axios';

import { DanhMucDungChungEndPoint } from '/@/api/apiConst';
import { danhMucHttp } from '/@/utils/http/axios';
import { BaseApi } from '/@/api/baseApi';
import { INhomHanhViViPham } from '/@/api/bao-cao-thong-ke/nhom-hanh-vi-vi-pham/model';
import { BctkBasePagination } from '/@/api/bao-cao-thong-ke/model';

import { IPhuongTienViViPham } from './model';

export class PhuongTienViPhamApi extends BaseApi<INhomHanhViViPham> {
  constructor() {
    super(danhMucHttp, DanhMucDungChungEndPoint.PhuongTien);
  }
  async getPhuongTienViPham(
    params: {
      linhVuc?: string;
      trangThai?: boolean;
      isFetchAll?: boolean;
      layDanhSachPhuongTienCapNhoNhat?: boolean;
    },
    options?: RequestOptions,
  ): Promise<BctkBasePagination<IPhuongTienViViPham>> {
    return this.http.get<BctkBasePagination<IPhuongTienViViPham>>(
      {
        url: this.url,
        params: params,
      },
      options,
    );
  }
}
