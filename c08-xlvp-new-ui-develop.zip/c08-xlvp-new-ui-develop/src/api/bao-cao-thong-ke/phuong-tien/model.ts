import { BaseInfo } from '/@/api';
import { ILinhVuc } from '/@/const';

export interface IPhuongTienViViPham extends BaseInfo {
  page: string;
  size: string;
  strParam?: string;
  ten: string;
  ma: string;
  linhVuc?: ILinhVuc;
}

export type ISearchNhomHanhViViPham = Pick<IPhuongTienViViPham, 'linhVuc' | 'ma' | 'ten'>;
