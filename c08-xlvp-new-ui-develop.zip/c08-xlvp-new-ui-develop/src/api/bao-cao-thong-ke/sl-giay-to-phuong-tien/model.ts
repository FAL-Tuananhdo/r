import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { ITrangThaiTangVat } from '/@/const';

export interface IBcSlGiayToPhuongTien
  extends Pick<
    IBaoCaoThongKe,
    'reportCode' | 'fileType' | 'donVi' | 'tuNgay' | 'denNgay' | 'username'
  > {
  linhVuc: string;
  tangVat: string;
  trangThai?: ITrangThaiTangVat;
  loaiBaoCao?: string;
}
