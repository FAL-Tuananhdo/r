import { baoCaoThongKeHttp } from '/@/utils/http/axios';

import { BaoCaoThongKeEndPoint } from '../../apiConst';
import { IBcSlGiayToPhuongTien } from './model';

export class BcSlGiayToPhuongTien {
  async exportExcel(params: IBcSlGiayToPhuongTien): Promise<void> {
    return baoCaoThongKeHttp.downloadFile({
      url: `${BaoCaoThongKeEndPoint.ExportExcel}`,
      params: params,
    });
  }
}
