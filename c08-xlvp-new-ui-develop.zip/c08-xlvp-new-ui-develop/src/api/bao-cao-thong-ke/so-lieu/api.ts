import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '../../apiConst';
import { IBctkSoLieu, ISearchParamBctkSoLieu } from './model';
import { BaseApi } from '../../baseApi';

export class BctkSoLieu extends BaseApi<IBctkSoLieu> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.Reporting);
  }

  async search(params: ISearchParamBctkSoLieu): Promise<IBctkSoLieu[]> {
    return baoCaoThongKeHttp.get<IBctkSoLieu[]>({
      url: `${this.url}/search`,
      params: params,
    });
  }
}
