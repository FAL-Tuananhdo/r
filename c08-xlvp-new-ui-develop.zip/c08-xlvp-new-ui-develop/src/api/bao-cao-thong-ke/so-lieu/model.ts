import { BaseInfo } from '/@/api';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { IHanhViViPham } from '/@/api/bao-cao-thong-ke/hanh-vi-vi-pham/model';

export interface IBctkSoLieu extends BaseInfo {
  maTongHopBc: string;
  tenTrangThaiTh: string;
  maTrangThaiTh: string;
  ngayBc: string | Date;
  reportFile?: string;
}

export interface ISearchParamBctkSoLieu
  extends Pick<
      IBaoCaoThongKe,
      | 'reportCode'
      | 'fileType'
      | 'tuNgay'
      | 'denNgay'
      | 'linhVuc'
      | 'nhomHanhVi'
      | 'username'
      | 'donVi'
    >,
    Omit<IBaoCaoThongKe, 'donViTraGiayTo' | 'phuongTien' | 'hanhVi' | 'tangVat'> {
  hanhVi?: Array<IHanhViViPham>;
  phuongTien?: Array<string>;
  tangVat?: Array<string>;
}
