import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';

export interface IViPhamQuaHinhAnh
  extends Pick<IBaoCaoThongKe, 'fileType' | 'donVi' | 'tuNgay' | 'denNgay' | 'username'> {
  loaiBaoCao?: string;
  reportFile?: string;
}
