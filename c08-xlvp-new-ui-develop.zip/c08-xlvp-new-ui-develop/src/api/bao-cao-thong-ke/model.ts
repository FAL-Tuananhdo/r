import { RangeValue } from '/@/views/bao-cao-thong-ke/use/UseDisableRangeExport';

export interface IBaoCaoThongKe {
  reportCode: string;
  code?: string;
  name?: string;
  type?: number;
  dateFrom?: Date;
  dateTo?: Date;
  fileType?: string;
  strParam?: string;
  donVi?: string | undefined;
  donViTraGiayTo?: string;
  phuongTien?: string;
  bienSo?: string;
  soThongTu?: string;
  nhomHanhVi?: string;
  hanhVi?: string;
  nguoiViPham?: string;
  diaDiem?: string;
  loai?: string;
  tuyenDuong?: string;
  diaBan?: string;
  username?: string;
  tangVat?: string;
  ngayTamGiuTu?: string;
  ngayTamGiuDen?: string;
  ngayTuocGiayToTu?: Date;
  ngayTuocGiayToDen?: Date;
  ngheNghiep?: string;
  ngayViPhamTu?: Date;
  ngayViPhamDen?: Date;
  quocTich?: string;
  doTuoiDen?: number;
  doTuoiTu?: number;
  maDonViTraGiayTo?: number;
  tuNgay?: Date;
  denNgay?: Date;
  trangThai?: string;
  linhVuc?: string;
  hinhThuc?: string;
  hinhThucXpbs?: string;
  '[tuNgay, denNgay]'?: RangeValue;
  '[ngayTuocGiayToTu, ngayTuocGiayToDen]'?: RangeValue;
  loaiQuyetDinh?: string;
}

export interface BctkBasePagination<T> {
  result: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  page: 0;
  last: boolean;
}
