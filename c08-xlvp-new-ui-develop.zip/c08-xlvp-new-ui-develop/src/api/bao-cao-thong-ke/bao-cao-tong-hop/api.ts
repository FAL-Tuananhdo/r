import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { BaseApi } from '/@/api/baseApi';
import {
  IBctkBaoCaoTongHop,
  IBctkBaoCaoTopHopColumns,
} from '/@/api/bao-cao-thong-ke/bao-cao-tong-hop/model';
import { BasePagination } from '/@/api';

export class BctkBaoCaoTongHopApi extends BaseApi<IBctkBaoCaoTopHopColumns> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.BaoCaoTongHop);
  }
  async search(params: IBctkBaoCaoTongHop): Promise<BasePagination<IBctkBaoCaoTopHopColumns>> {
    return baoCaoThongKeHttp.get<BasePagination<IBctkBaoCaoTopHopColumns>>({
      url: `${this.url}/search`,
      params: params,
    });
  }

  async exportExcel(id: string): Promise<void> {
    baoCaoThongKeHttp.downloadFile({
      url: `${this.url}/report/${id}`,
    });
  }
}
