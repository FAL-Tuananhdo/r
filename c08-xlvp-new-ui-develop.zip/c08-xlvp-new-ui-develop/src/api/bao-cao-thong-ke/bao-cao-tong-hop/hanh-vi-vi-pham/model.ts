import { BaseInfo } from '/@/api';
import { ILinhVuc } from '/@/const';

export interface INhomHanhViViPham extends BaseInfo {
  page?: string;
  size?: string;
  strParam?: string;
  name: string;
  code: string;
  linhVuc?: ILinhVuc;
}
export type ISearchNhomHanhViViPham = Partial<
  Pick<INhomHanhViViPham, 'linhVuc' | 'strParam' | 'name'>
>;
