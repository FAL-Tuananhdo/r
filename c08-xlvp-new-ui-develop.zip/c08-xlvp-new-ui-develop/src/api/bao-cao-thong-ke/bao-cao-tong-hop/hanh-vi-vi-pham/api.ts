import { BaoCaoThongKeEndPoint } from '/@/api/apiConst';
import { baoCaoThongKeHttp } from '/@/utils/http/axios';
import { BaseApi } from '/@/api/baseApi';

import { RequestOptions } from '/#/axios';
import { BctkBasePagination } from '/@/api/bao-cao-thong-ke/model';
import {
  INhomHanhViViPham,
  ISearchNhomHanhViViPham,
} from '/@/api/bao-cao-thong-ke/bao-cao-tong-hop/hanh-vi-vi-pham/model';

export class hanhViViPhamApi extends BaseApi<INhomHanhViViPham> {
  constructor() {
    super(baoCaoThongKeHttp, BaoCaoThongKeEndPoint.HanhViViViPham);
  }
  async getNhomHvvp(
    params: ISearchNhomHanhViViPham,
    options?: RequestOptions,
  ): Promise<BctkBasePagination<INhomHanhViViPham>> {
    return this.http.get<BctkBasePagination<INhomHanhViViPham>>(
      {
        url: this.url,
        params: params,
      },
      options,
    );
  }
}
