import { BaseInfo } from '/@/api';
import { RangeValue } from '/@/views/bao-cao-thong-ke/use/UseDisableRangeExport';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';
import { IDanhMucHanhViViPham } from '/@/api/danh-muc/hanh-vi-vi-pham/model';

export interface IBctkBaoCaoTongHop
  extends Pick<
      IBaoCaoThongKe,
      | 'reportCode'
      | 'donVi'
      | 'tuNgay'
      | 'denNgay'
      | 'fileType'
      | 'username'
      | 'nhomHanhVi'
      | 'linhVuc'
    >,
    Omit<
      IBaoCaoThongKe,
      | 'tuNgay'
      | 'denNgay'
      | 'hanhVi'
      | 'phuongTien'
      | 'ngheNghiep'
      | 'linhVuc'
      | 'ngayViPhamTu'
      | 'ngayViPhamDen'
      | 'tangVat'
      | 'diaDiem'
    > {
  '[tuNgay, denNgay]'?: RangeValue;
  '[ngayTuocGiayToTu, ngayTuocGiayToDen]'?: RangeValue;
  hanhVi?: IDanhMucHanhViViPham[];
  nhomHanhVi?: string;
  phuongTien?: string[];
  ngheNghiep?: string[];
  linhVucArray?: string[];
  tangVat?: string[];
  diaDiem?: string[];
  bienSo?: string;
  loai?: string;
  soThongTu?: string;
  nguoiViPham?: string;
  ngayViPhamTu?: Date;
  ngayViPhamDen?: Date;
}

export interface IBctkBaoCaoTopHopColumns extends BaseInfo {
  maTongHopBc: string;
  tenTrangThaiTh: string;
  maTrangThaiTh: string;
  ngayBc: string | Date;
  reportFile?: string;
}
