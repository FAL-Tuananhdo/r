import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';

export interface ISoThongKeViPham
  extends Pick<IBaoCaoThongKe, 'fileType' | 'donVi' | 'tuNgay' | 'denNgay' | 'username'> {
  linhVuc?: Array<number>;
  loaiQuyetDinh?: string;
  reportFile?: string;
}
