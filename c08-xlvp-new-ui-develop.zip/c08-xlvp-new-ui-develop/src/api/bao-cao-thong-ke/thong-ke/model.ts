import { RangeValue } from '/@/views/bao-cao-thong-ke/use/UseDisableRangeExport';
import { IBaoCaoThongKe } from '/@/api/bao-cao-thong-ke/model';

export interface IBctkThongKe
  extends Pick<
      IBaoCaoThongKe,
      'reportCode' | 'donVi' | 'tuNgay' | 'denNgay' | 'linhVuc' | 'fileType'
    >,
    Omit<IBaoCaoThongKe, 'tuNgay' | 'denNgay'> {
  '[tuNgay, denNgay]': RangeValue;
  linhVucArray?: Array<number>;
}
