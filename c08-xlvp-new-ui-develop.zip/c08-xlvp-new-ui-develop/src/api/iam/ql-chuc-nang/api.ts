import { omit } from 'lodash-es';

import { treeMapEach } from '/@/utils/helper/treeHelper';
import { iamHttp } from '/@/utils/http/axios';
import { isBoolean } from '/@/utils/is';

import { IamEndPoint } from '../../apiConst';
import { BasePagination } from '../../types';
import {
  IAppCodeDto,
  IChucNangChaDto,
  IChucNangDto,
  IPermissionApiDto,
  IRequestBodyChucNangDto,
  ISearchChucNangChaParamsDto,
  ISearchParamsChucNangDto,
} from './dto';
import {
  IAppCode,
  IChucNang,
  IChucNangCha,
  IPermissionApi,
  IRequestBodyChucNang,
  ISearchChucNangByParentCodeParams,
  ISearchParamsChucNang,
} from './model';

export class QuanLyChucNangApi {
  async search(params: ISearchParamsChucNang): Promise<BasePagination<IChucNang>> {
    const searchParamsDto: ISearchParamsChucNangDto = {
      ...omit(params, 'pageSize'),
      menuCode: params.name,
      name: params.title,
      parentCode: params.parentName,
      status: booleanToNumber(params.status),
      size: params.pageSize,
    };
    const res = await iamHttp.get<{ result: IChucNangDto[]; totalElements: number }>({
      url: IamEndPoint.DanhSachPhanQuyen,
      params: searchParamsDto,
    });

    return {
      items: res.result?.map((item) => this.fromDto(item)),
      total: res.totalElements,
    };
  }

  async getAllPermissionApi(params: { appCode: string; name: string }): Promise<IPermissionApi[]> {
    const paramsDto: Pick<IPermissionApiDto, 'appCode' | 'menuCode'> = {
      appCode: params.appCode,
      menuCode: params.name,
    };
    const res = await iamHttp.get<IPermissionApiDto[]>({
      url: IamEndPoint.QuyenTruyCapApi,
      params: paramsDto,
    });
    return res.map((item) => ({
      appCode: item.appCode,
      isUpdateAccessApi: item.isUpdateAccessApi,
      menuCode: item.menuCode,
      name: item.name,
      status: !!item.status,
    }));
  }

  async getAllAppCode(): Promise<IAppCode[]> {
    const res = await iamHttp.get<IAppCodeDto[]>({
      url: IamEndPoint.DanhSachUngDung,
    });
    return res.map((item) => ({
      appCode: item.appCode,
      name: item.name,
      description: item.description,
      status: item.status,
    }));
  }

  async getChucNangByParentCode(
    params: ISearchChucNangByParentCodeParams,
  ): Promise<IChucNangCha[]> {
    const searchParamsDto: ISearchChucNangChaParamsDto = {
      appCode: params.appCode,
      type: params.type?.toString(),
      parentCode: params.parentName,
    };
    const res = await iamHttp.get<IChucNangChaDto>({
      url: IamEndPoint.ChucNangByParentCode,
      params: searchParamsDto,
    });
    if (!res) return [];

    return [
      treeMapEach(res, {
        conversion: (item: IChucNangChaDto): IChucNangCha => ({
          treeLeaf: item.leaf,
          name: item.name,
          menuCode: item.rowKey,
          selected: item.selected,
        }),
      }),
    ];
  }

  async createChucNang(model: IRequestBodyChucNang): Promise<IChucNang> {
    const requestBodyDto = this.toDto(model);
    const res = await iamHttp.post<IChucNangDto>({
      url: IamEndPoint.ChucNang,
      data: requestBodyDto,
    });
    return this.fromDto(res);
  }

  async updateChucNang(model: IRequestBodyChucNang): Promise<IChucNang> {
    const requestBodyDto = this.toDto(model);
    const res = await iamHttp.put<IChucNangDto>({
      url: IamEndPoint.ChucNang,
      data: requestBodyDto,
    });
    return this.fromDto(res);
  }

  async detailChucNang(): Promise<IChucNang> {
    const res = await iamHttp.get<IChucNangDto>({
      url: IamEndPoint.ChucNang,
    });
    return this.fromDto(res);
  }

  async deleteChucNang(appCode: string, name: string) {
    await iamHttp.delete(
      {
        url: IamEndPoint.ChucNang,
        params: { appCode, menuCode: name },
      },
      {
        joinParamsToUrl: true,
      },
    );
  }

  fromDto(chucNang: IChucNangDto): IChucNang {
    return {
      appCode: chucNang.appCode,
      parentName: chucNang.parentCode,
      name: chucNang.menuCode,
      type: chucNang.type,
      path: chucNang.menuPath,
      component: chucNang.url,
      redirect: chucNang.meta?.redirect,
      meta: {
        ...omit(chucNang.meta, 'redirect'),
        title: chucNang.name,
        orderNo: chucNang.orderNo,
        icon: chucNang.menuIcon,
        hideMenu: !!chucNang.hideMenu,
        currentActiveMenu: chucNang.activeMenu,
      },
      listAccessApi: chucNang.lstAccessApi || [],
      status: !!chucNang.status,
    };
  }

  toDto(requestBody: IRequestBodyChucNang): IRequestBodyChucNangDto {
    return {
      activeMenu: requestBody.meta.currentActiveMenu,
      appCode: requestBody.appCode,
      isUpdateAccessApi: true,
      menuCode: requestBody.name,
      name: requestBody.meta.title,
      status: booleanToNumber(requestBody.status)!,
      type: requestBody.type,
      url: requestBody.component,
      hideMenu: booleanToNumber(requestBody.meta?.hideMenu),
      menuIcon: requestBody.meta.icon,
      menuPath: requestBody.path,
      orderNo: requestBody.meta?.orderNo,
      parentCode: requestBody.parentName,
      meta: {
        ...omit(requestBody.meta, ['hideMenu', 'currentActiveMenu', 'icon', 'orderNo', 'title']),
        redirect: requestBody.redirect,
      },
      lstAccessApi: requestBody.listAccessApi,
    };
  }
}

const booleanToNumber = (value?: boolean): number | undefined => {
  if (isBoolean(value)) {
    return value ? 1 : 0;
  }
  return undefined;
};
