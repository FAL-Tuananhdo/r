import type { RouteMeta } from 'vue-router';

export interface IChucNang {
  appCode: string;
  isUpdateAccessApi?: boolean;
  status: boolean;
  type: number;
  name: string;
  redirect?: string;
  component: string;
  listAccessApi?: string[];
  path?: string;
  disabled?: boolean;
  meta: RouteMeta;
  parentName?: string;
  children?: IChucNang[];
}

export interface ISearchParamsChucNang
  extends Partial<Pick<IChucNang, 'appCode' | 'name' | 'parentName' | 'status' | 'type'>> {
  title?: string;
  page: number;
  pageSize: number;
}

export interface IAppCode {
  appCode: string;
  name: string;
  description: string;
  status: number;
}

export interface IChucNangCha {
  treeLeaf: boolean;
  name: string;
  menuCode: string;
  selected: boolean;
  children?: IChucNangCha[];
}

export interface ISearchChucNangByParentCodeParams
  extends Pick<IChucNang, 'appCode' | 'parentName'> {
  type?: number[];
}

export type IRequestBodyChucNang = Omit<IChucNang, 'children'>;

export interface IPermissionApi extends Pick<IChucNang, 'status' | 'appCode' | 'name'> {
  isUpdateAccessApi: boolean;
}
