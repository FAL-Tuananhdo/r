interface IMetaChucNangDto extends Record<string | number | symbol, unknown> {
  redirect?: string;
}

export interface IChucNangDto {
  appCode: string;
  isUpdateAccessApi: boolean;
  menuCode: string;
  name: string;
  status: number;
  type: number;
  url: string;
  lstAccessApi?: string[];
  orderNo?: number;
  parentCode?: string;
  activeMenu?: string;
  menuPath?: string;
  menuIcon?: string;
  hideMenu?: number;
  children?: IChucNangDto[];
  meta?: IMetaChucNangDto;
}

export interface ISearchParamsChucNangDto
  extends Partial<
    Pick<IChucNangDto, 'appCode' | 'menuCode' | 'name' | 'parentCode' | 'status' | 'type'>
  > {
  page: number;
  size: number;
}

export interface IAppCodeDto {
  appCode: string;
  name: string;
  description: string;
  status: number;
}

export interface IChucNangChaDto {
  leaf: boolean;
  name: string;
  rowKey: string;
  selected: boolean;
  children?: IChucNangChaDto[];
}

export interface ISearchChucNangChaParamsDto extends Pick<IChucNangDto, 'appCode' | 'parentCode'> {
  type?: string;
}

export type IRequestBodyChucNangDto = Omit<IChucNangDto, 'children'>;

export interface IPermissionApiDto
  extends Pick<IChucNangDto, 'status' | 'appCode' | 'menuCode' | 'name'> {
  isUpdateAccessApi: boolean;
}
