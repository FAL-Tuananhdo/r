import componentSetting from '/@/settings/componentSetting';

const { description } = componentSetting;

const { defaultSize } = description;

export const DEFAULT_SIZE = defaultSize;
