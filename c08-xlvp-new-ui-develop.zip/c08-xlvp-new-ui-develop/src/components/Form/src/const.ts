import componentSetting from '/@/settings/componentSetting';

const { basicForm } = componentSetting;

const {
  defaultActionColOptions,
  defaultLabelCol,
  defaultWrapperCol,
  defaultColProps,
  defaultRowProps,
  defaultLabelWidth,
  labelAlign,
  defaultTransformDateFunc,
} = basicForm;

export const DEFAULT_ACTION_COL_OPTIONS = defaultActionColOptions;

export const DEFAULT_LABEL_COL = defaultLabelCol;

export const DEFAULT_WRAPPER_COL = defaultWrapperCol;

export const DEFAULT_BASE_COL_PROP = defaultColProps;

export const DEFAULT_ROW_PROP = defaultRowProps;

export const DEFAULT_LABEL_WIDTH = defaultLabelWidth;

export const DEFAULT_LABEL_ALIGN = labelAlign;

export const DEFAULT_TRANSFORM_DATE_FUNC = defaultTransformDateFunc;
