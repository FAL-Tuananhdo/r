<template>
  <Input
    v-bind="attrs"
    type="tel"
    :value="formattedValue"
    v-money="config"
    :disabled="disabled"
    @change="change"
  />
</template>

<script lang="ts" setup inheritAttrs="false">
  import { computed, ref, toRefs, watch } from 'vue';
  import { Input } from 'ant-design-vue';

  import {
    vMoney,
    defaultConfig,
    format,
    unFormat,
    filterOptRestrictions,
    fixed,
    validateRestrictedInput,
    VMoneyOptions,
  } from '/@/directives/money';
  import { useAttrs } from '/@/hooks/core/useAttrs';

  const props = defineProps({
    value: {
      type: [Number, String],
      default: '',
    },
    modelModifiers: {
      required: false,
      type: Object as PropType<VMoneyOptions['modelModifiers']>,
      default: () => defaultConfig.modelModifiers,
    },
    masked: {
      type: Boolean,
      default: false,
    },
    precision: {
      type: Number,
      default: () => defaultConfig.precision,
    },
    decimal: {
      type: String,
      default: () => defaultConfig.decimal,
      validator(value: string) {
        return validateRestrictedInput(value, 'decimal');
      },
    },
    thousands: {
      type: String,
      default: () => defaultConfig.thousands,
      validator(value: string) {
        return validateRestrictedInput(value, 'thousands');
      },
    },
    prefix: {
      type: String,
      default: () => defaultConfig.prefix,
      validator(value: string) {
        return validateRestrictedInput(value, 'prefix');
      },
    },
    suffix: {
      type: String,
      default: () => defaultConfig.suffix,
      validator(value: string) {
        return validateRestrictedInput(value, 'suffix');
      },
    },
    disableNegative: {
      type: Boolean,
      default: () => defaultConfig.disableNegative,
    },
    disabled: {
      type: Boolean,
      default: false,
    },
    max: {
      type: [Number, String],
      default: () => defaultConfig.max,
    },
    min: {
      type: [Number, String],
      default: () => defaultConfig.min,
    },
    allowBlank: {
      type: Boolean,
      default: () => defaultConfig.allowBlank,
    },
    minimumNumberOfCharacters: {
      type: Number,
      default: () => defaultConfig.minimumNumberOfCharacters,
    },
    shouldRound: {
      type: Boolean,
      default: () => defaultConfig.shouldRound,
    },
  });

  const emit = defineEmits<{
    (e: 'update:value', value: string | number): void;
    (e: 'change', value: string | number): void;
  }>();

  const attrs = useAttrs({
    excludeKeys: ['onUpdate:value'],
  });

  const { value: valueRef, modelModifiers, masked, precision, shouldRound } = toRefs(props);

  const config = computed<Partial<VMoneyOptions>>(() => ({
    precision: props.precision,
    decimal: props.decimal,
    thousands: props.thousands,
    prefix: props.prefix,
    suffix: props.suffix,
    disableNegative: props.disableNegative,
    min: props.min,
    max: props.max,
    allowBlank: props.allowBlank,
    minimumNumberOfCharacters: props.minimumNumberOfCharacters,
    modelModifiers: props.modelModifiers,
    shouldRound: props.shouldRound,
  }));

  let modelValue: string | number = valueRef.value;
  if (props.disableNegative || modelValue !== '-') {
    if (modelModifiers.value && modelModifiers.value.number) {
      if (shouldRound.value) {
        modelValue = Number(valueRef.value).toFixed(fixed(precision.value));
      } else {
        modelValue = Number(valueRef.value)
          .toFixed(fixed(precision.value) + 1)
          .slice(0, -1);
      }
    }
  }
  const formattedValue = ref(format(modelValue, props));

  watch(valueRef, (value: string | number | null | undefined) => {
    const formatted = format(value, filterOptRestrictions({ ...props }));
    if (formatted !== formattedValue.value) {
      formattedValue.value = formatted;
    }
  });

  let lastValue: string | number | null = null;
  function change(evt: ChangeEvent) {
    let value: string | number = evt.target.value;

    if (!(masked.value && !modelModifiers.value.number)) {
      value = unFormat(value, filterOptRestrictions({ ...props }));
    }
    if (value !== lastValue) {
      lastValue = value;
      emit('update:value', value);
      emit('change', value);
    }
  }
</script>
