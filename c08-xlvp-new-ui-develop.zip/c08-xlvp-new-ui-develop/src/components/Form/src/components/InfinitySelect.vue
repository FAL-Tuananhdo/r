<template>
  <Select
    v-bind="$attrs"
    v-model:value="state"
    allowClear
    showSearch
    :loading="loading"
    :filterOption="false"
    :options="getOptions"
    :disabled="disabled"
    @popupScroll="handleLoadMore"
    @search="handleSearchDebounce"
    @change="handleChange"
    @dropdown-visible-change="handleDropdownVisibleChange"
    :placeholder="t('common.choose_text')"
  >
    <template #[item]="data" v-for="item in Object.keys($slots)">
      <slot :name="item" v-bind="data || {}"></slot>
    </template>
    <template #dropdownRender="{ menuNode }">
      <Component v-if="!loading || getOptions.length" :is="menuNode" />
      <div v-if="loading" class="py-1 px-3">
        <Spin />
        {{ t('common.loading_text') }}
      </div>
    </template>
  </Select>
</template>

<script lang="ts" setup name="InfinitySelect" inheritAttrs="false">
  import { computed, onMounted, ref, unref, watch } from 'vue';
  import { Select, Spin } from 'ant-design-vue';
  import { get, isEqual, uniqBy } from 'lodash-es';
  import { useDebounceFn } from '@vueuse/core';

  import { propTypes } from '/@/utils/propTypes';
  import { useState } from '/@/hooks/core/useState';
  import { useI18n } from '/@/hooks/web/useI18n';
  import { useRuleFormItem } from '/@/hooks/component/useFormItem';
  import { isFunction } from '/@/utils/is';
  import componentSetting from '/@/settings/componentSetting';

  type IOption = { label: string; value: string; disabled?: boolean; hidden?: boolean };
  type IOptionItem = IOption | Recordable;
  const DISTANCE = 10;
  const emit = defineEmits(['change', 'update:value', 'selected']);

  const props = defineProps({
    displayRender: { type: String },
    value: { type: String },
    api: {
      type: Function as PropType<(arg?: Recordable) => Promise<Recordable>>,
      default: null,
    },
    params: {
      type: Object as PropType<Recordable>,
      default: () => ({}),
    },
    disabled: propTypes.bool.def(false),
    immediate: propTypes.bool.def(true),
    pageSize: propTypes.number.def(10),
    fetchSetting: {
      type: Object as PropType<{
        pageField: string;
        sizeField: string;
        listField: string;
        totalField: string;
      }>,
      default: () => componentSetting.infinitySelect.fetchSetting,
    },
    searchSetting: {
      type: Object as PropType<{
        searchField: string;
        searchValueField: string;
      }>,
      default: () => componentSetting.infinitySelect.searchParamsSetting,
    },

    fieldNames: {
      type: Object as PropType<{
        label: string;
        value: string;
      }>,
      default: () => componentSetting.infinitySelect.fieldNames,
    },

    disableOption: {
      type: Function as PropType<(option: Recordable) => boolean>,
    },
  });

  const { t } = useI18n();
  const [options, setOptions] = useState<IOptionItem[]>([]);
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [keyword, setKeyword] = useState('');

  const emitData = ref<unknown[]>([]);
  const [state] = useRuleFormItem(props, 'value', 'change', emitData);

  const hasMore = computed(() => {
    return unref(options).length < total.value;
  });

  let isFirstLoaded = false;

  const getOptions = computed(() => {
    const { disableOption } = props;
    const _options: IOptionItem[] = unref(options).map((item) => {
      const isDisabled = disableOption && isFunction(disableOption) && disableOption(item);
      return {
        ...item,
        disabled: isDisabled,
      };
    });
    if (
      props.value &&
      props.displayRender &&
      !_options.some((item) => item.value === props.value)
    ) {
      _options.push({
        label: props.displayRender,
        hidden: true,
        value: props.value,
      });
    }
    return _options;
  });

  const handleSearch = async (text: string): Promise<IOptionItem[]> => {
    setKeyword(text);
    const opt = await fetch({
      page: 0,
    });
    setOptions(opt);
    return opt;
  };
  const handleSearchDebounce = useDebounceFn(handleSearch, 300);

  const handleChange = (value: string, selectObject: IOptionItem) => {
    emitData.value = [selectObject];
    emit('update:value', value);
  };

  const handleLoadMore = async (event: Event) => {
    const target = event.target as HTMLElement;
    if (Math.ceil(target.scrollTop + target.offsetHeight) + DISTANCE >= target.scrollHeight) {
      if (!unref(loading) && hasMore.value) {
        try {
          setLoading(true);
          const page = unref(currentPage);
          const opt = await fetch({
            page: page + 1,
          });
          setOptions(uniqBy(unref(options).concat(opt), 'value'));
        } finally {
          setLoading(false);
        }
      }
    }
  };

  const handleDropdownVisibleChange = (isVisible: boolean) => {
    if (isVisible && (!isFirstLoaded || unref(keyword))) {
      handleSearch('');
    }
  };

  watch(
    [() => props.params, state],
    async (currentValue, oldValue) => {
      const [oldParams, oldState] = oldValue;
      const [newParams, newState] = currentValue;

      const isStateChange = oldState !== newState;
      const isParamsChange = !isEqual(oldParams, newParams);

      if (isParamsChange) {
        const options = await fetch({ page: 0 });
        setOptions(options);
      }

      if (isStateChange) {
        let cache = unref(options).find((item) => item.value === newState);
        let isAppendOption = false;
        if (newState && !cache) {
          const option = await fetch({ searchValue: newState });
          cache = option.find((item) => item.value === newState);
          isAppendOption = true;
        }
        if (cache && isAppendOption) {
          setOptions(uniqBy(unref(options).concat(cache), 'value'));
        }
        emitData.value = cache ? [cache] : [];
        emit('selected', cache);
      }
    },
    {
      deep: true,
      flush: 'post',
    },
  );

  const fetch = async (opt?: { page?: number; searchValue?: string }) => {
    const api = props.api;
    if (!api || !isFunction(api)) return [];
    const { fieldNames } = props;
    const { listField, totalField, pageField, sizeField } = props.fetchSetting;
    const { searchField, searchValueField } = props.searchSetting;

    try {
      setLoading(true);
      let params: Recordable = {
        [searchField]: unref(keyword),
        [pageField]: (opt && opt.page) ?? unref(currentPage),
        [sizeField]: props.pageSize,
        ...props.params,
      };
      const isFetchDetail = opt && opt.searchValue;
      if (isFetchDetail) {
        params = {
          [searchValueField]: opt.searchValue,
          ...props.params,
        };
      }

      const res = await api(params);
      const rawOption = (get(res, listField) as IOptionItem[]) || [];

      const option = rawOption.reduce<IOptionItem[]>((opt, item) => {
        if (item) {
          opt.push({
            ...item,
            value: item[fieldNames.value],
            label: item[fieldNames.label] || '',
          });
        }
        return opt;
      }, []);

      if (!isFetchDetail) {
        isFirstLoaded = true;
        setTotal(res[totalField]);
        setCurrentPage(params[pageField]);
      }
      return option;
    } catch (error) {
      return [];
    } finally {
      setLoading(false);
    }
  };

  onMounted(() => {
    props.immediate && handleSearch(unref(state) || '');
  });
</script>
