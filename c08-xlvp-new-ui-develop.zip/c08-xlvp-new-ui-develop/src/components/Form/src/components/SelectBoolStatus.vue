<template>
  <Select v-bind="attrs" v-model:value="bindVal" :options="getOptions" />
</template>

<script setup lang="ts" name="SelectBoolStatus">
  import { computed } from 'vue';
  import { Select } from 'ant-design-vue';

  import { useAttrs } from '/@/hooks/core/useAttrs';
  import { propTypes } from '/@/utils/propTypes';
  import { isBoolean, isNumber } from '/@/utils/is';
  import { useI18n } from '/@/hooks/web/useI18n';

  const attrs = useAttrs();

  const emit = defineEmits(['change', 'update:value']);

  type ILabelConfig = {
    active?: string;
    inactive?: string;
  };

  const props = defineProps({
    value: propTypes.bool,
    labelSettings: {
      type: Object as PropType<ILabelConfig>,
    },
  });

  const { t } = useI18n();

  const bindVal = computed<number | undefined>({
    get() {
      return isBoolean(props.value) ? Number(props.value) : undefined;
    },
    set(val) {
      const emitValue = isNumber(val) ? Boolean(val) : undefined;
      emit('change', emitValue);
      emit('update:value', emitValue);
    },
  });

  const getOptions = computed(() => {
    return [
      { label: props.labelSettings?.active || t('common.is_activated'), value: 1 },
      { label: props.labelSettings?.inactive || t('common.is_deactivated'), value: 0 },
    ];
  });
</script>
