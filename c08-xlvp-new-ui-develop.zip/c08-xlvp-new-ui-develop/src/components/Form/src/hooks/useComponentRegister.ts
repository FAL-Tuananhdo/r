import type { ComponentType } from '../types/index';
import { tryOnUnmounted } from '@vueuse/core';
import { add, del, has } from '../componentMap';
import { Component } from 'vue';
import { tryOnActivated } from '/@/hooks/component/tryOnActivated';

export function useComponentRegister(
  compName: ComponentType,
  comp: Component,
  deleteOnUnmounted = true,
) {
  add(compName, comp);
  tryOnUnmounted(() => {
    deleteOnUnmounted && del(compName);
  });
  tryOnActivated(() => {
    if (!has(compName)) {
      add(compName, comp);
    }
  });
}
