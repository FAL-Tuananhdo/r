export { default as ImagePreview } from './src/Preview.vue';
export { createImgPreview } from './src/functional';
export { default as ImageSlider } from './src/ImageSlider.vue';
