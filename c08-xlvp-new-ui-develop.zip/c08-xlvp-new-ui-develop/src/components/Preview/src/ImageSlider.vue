<template>
  <Carousel :class="getClass" arrows dots-class="slick-dots slick-thumb">
    <template #prevArrow>
      <div class="custom-slick-arrow" style="left: 10px; z-index: 1">
        <left-circle-outlined />
      </div>
    </template>
    <template #nextArrow>
      <div class="custom-slick-arrow" style="right: 10px">
        <right-circle-outlined />
      </div>
    </template>
    <template #customPaging="{ i: index }: { i: number }">
      <a>
        <img :src="getImgUrlThumbs(index)" />
      </a>
    </template>

    <template v-if="isExistedImages">
      <div v-for="(item, index) in imgs" :key="item">
        <Image
          width="100%"
          height="100%"
          :src="item"
          :preview="false"
          @click="handleOpenImg(index)"
        />
      </div>
    </template>
    <template v-else>
      <div class="text-center text-2xl overflow-clip">{{ t('common.khong_co_du_lieu') }}</div>
    </template>
  </Carousel>
</template>

<script lang="ts" setup>
  import { computed } from 'vue';
  import { Carousel, Image } from 'ant-design-vue';

  import { LeftCircleOutlined, RightCircleOutlined } from '@ant-design/icons-vue';
  import { useDesign } from '/@/hooks/web/useDesign';
  import { useI18n } from '/@/hooks/web/useI18n';

  import { createImgPreview } from './functional';

  const props = defineProps({
    imgs: {
      type: Array as PropType<string[]>,
      required: true,
      default: () => [],
    },
    fileName: String as PropType<string>,
  });

  const getImgUrlThumbs = (index: number) => {
    return `${props.imgs[index]}`;
  };

  const handleOpenImg = (index: number) => {
    createImgPreview({
      imageList: props.imgs,
      rememberState: true,
      index: index,
      fileName: props.fileName,
    });
  };

  const { prefixCls } = useDesign('custom-carousel');
  const { t } = useI18n();

  const getClass = computed(() => [prefixCls]);

  const isExistedImages = computed(() => props.imgs && props.imgs.length);
</script>

<style lang="less">
  @prefix-cls: ~'@{namespace}-custom-carousel';

  .@{prefix-cls} {
    .slick-dots {
      position: relative;
      min-height: 45px;

      li.slick-active {
        width: 60px;
      }
    }

    .slick-slide img {
      border: 5px solid #fff;
      display: block;
      margin: auto;
      max-width: 80%;
    }

    .slick-thumb {
      bottom: 0px;

      li {
        width: 60px;
        height: 45px;

        img {
          width: 100%;
          height: 100%;
          filter: grayscale(100%);
        }
      }

      li.slick-active img {
        filter: grayscale(0%);
      }
    }

    .slick-arrow.custom-slick-arrow {
      width: 25px;
      height: 25px;
      font-size: 25px;
      color: #000;
      background-color: rgba(31, 45, 61, 0.11);
      opacity: 0.3;
      z-index: 1;
    }

    .slick-prev::before {
      content: '';
    }

    .slick-next::before {
      content: '';
    }
  }
</style>
