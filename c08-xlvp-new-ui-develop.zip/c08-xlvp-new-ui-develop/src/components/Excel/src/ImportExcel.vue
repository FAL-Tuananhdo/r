<template>
  <div>
    <input
      ref="inputRef"
      type="file"
      v-show="false"
      accept=".xlsx, .xls"
      @change="handleInputClick"
    />
    <div @click="handleUpload">
      <slot></slot>
    </div>
  </div>
</template>
<script lang="ts">
  import { defineComponent, ref, unref } from 'vue';
  import * as XLSX from 'xlsx';
  import { dateUtil } from '/@/utils/dateUtil';

  import type { ExcelData } from './typing';
  export default defineComponent({
    name: 'ImportExcel',
    props: {
      // Datetime format. If not provided or a null value is provided, the original Date object will be returned
      dateFormat: {
        type: String,
      },
      // Time zone adjustment. Experimental feature, only to solve the problem of reading datetime values ​​skewed. Currently only offset corrections for the +08:00 time zone are available
      // https://github.com/SheetJS/sheetjs/issues/1470#issuecomment-501108554
      timeZone: {
        type: Number,
        default: 8,
      },
      // Whether to return the selected file directly
      isReturnFile: {
        type: Boolean,
        default: false,
      },
    },
    emits: ['success', 'error', 'cancel'],
    setup(props, { emit }) {
      const inputRef = ref<HTMLInputElement | null>(null);
      const loadingRef = ref<Boolean>(false);
      const cancelRef = ref<Boolean>(true);

      function shapeWorkSheel(sheet: XLSX.WorkSheet, range: XLSX.Range) {
        let str = ' ',
          char = 65,
          customWorkSheet = {
            t: 's',
            v: str,
            r: '<t> </t><phoneticPr fontId="1" type="noConversion"/>',
            h: str,
            w: str,
          };
        if (!sheet || !sheet['!ref']) return [];
        let c = 0,
          r = 1;
        while (c < range.e.c + 1) {
          while (r < range.e.r + 1) {
            if (!sheet[String.fromCharCode(char) + r]) {
              sheet[String.fromCharCode(char) + r] = customWorkSheet;
            }
            r++;
          }
          r = 1;
          str += ' ';
          customWorkSheet = {
            t: 's',
            v: str,
            r: '<t> </t><phoneticPr fontId="1" type="noConversion"/>',
            h: str,
            w: str,
          };
          c++;
          char++;
        }
      }

      /**
       * @description: first line as header
       */
      function getHeaderRow(sheet: XLSX.WorkSheet) {
        if (!sheet || !sheet['!ref']) return [];
        const headers: string[] = [];
        // A3:B7=>{s:{c:0, r:2}, e:{c:1, r:6}}
        const range: XLSX.Range = XLSX.utils.decode_range(sheet['!ref']);
        shapeWorkSheel(sheet, range);
        const R = range.s.r;
        /* start in the first row */
        for (let C = range.s.c; C <= range.e.c; ++C) {
          /* walk every column in the range */
          const cell = sheet[XLSX.utils.encode_cell({ c: C, r: R })];
          /* find the cell in the first row */
          let hdr = 'UNKNOWN ' + C; // <-- replace with your desired default
          if (cell && cell.t) hdr = XLSX.utils.format_cell(cell);
          headers.push(hdr);
        }
        return headers;
      }

      /**
       * @description: get excel data
       */
      function getExcelData(workbook: XLSX.WorkBook) {
        const excelData: ExcelData[] = [];
        const { dateFormat, timeZone } = props;
        for (const sheetName of workbook.SheetNames) {
          const worksheet = workbook.Sheets[sheetName];
          const header: string[] = getHeaderRow(worksheet);
          let results = XLSX.utils.sheet_to_json(worksheet, {
            raw: true,
            dateNF: dateFormat, //Not worked
          }) as object[];
          results = results.map((row: object) => {
            for (let field in row) {
              if (row[field] instanceof Date) {
                if (timeZone === 8) {
                  row[field].setSeconds(row[field].getSeconds() + 43);
                }
                if (dateFormat) {
                  row[field] = dateUtil(row[field]).format(dateFormat);
                }
              }
            }
            return row;
          });

          excelData.push({
            header,
            results,
            meta: {
              sheetName,
            },
          });
        }
        return excelData;
      }

      /**
       * @description: read excel data
       */
      function readerData(rawFile: File) {
        loadingRef.value = true;
        return new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = async (e) => {
            try {
              const data = e.target && e.target.result;
              const workbook = XLSX.read(data, { type: 'array', cellDates: true });
              // console.log(workbook);
              /* DO SOMETHING WITH workbook HERE */
              const excelData = getExcelData(workbook);
              emit('success', excelData);
              resolve('');
            } catch (error) {
              reject(error);
              emit('error');
            } finally {
              loadingRef.value = false;
            }
          };
          reader.readAsArrayBuffer(rawFile);
        });
      }

      async function upload(rawFile: File) {
        const inputRefDom = unref(inputRef);
        if (inputRefDom) {
          // fix can't select the same excel
          inputRefDom.value = '';
        }
        await readerData(rawFile);
      }

      /**
       * @description: Trigger select file manager
       */
      function handleInputClick(e: Event) {
        const target = e && (e.target as HTMLInputElement);
        const files = target?.files;
        const rawFile = files && files[0]; // only setting files[0]
        target.value = '';
        if (!rawFile) return;
        cancelRef.value = false;
        if (props.isReturnFile) {
          emit('success', rawFile);
          return;
        }
        upload(rawFile);
      }

      /**
       * @description After the file selector is closed, judge the cancellation status
       */
      function handleFocusChange() {
        const timeId = setInterval(() => {
          if (cancelRef.value === true) {
            emit('cancel');
          }
          clearInterval(timeId);
          window.removeEventListener('focus', handleFocusChange);
        }, 1000);
      }

      /**
       * @description: Click the upload button
       */
      function handleUpload() {
        const inputRefDom = unref(inputRef);
        if (inputRefDom) {
          cancelRef.value = true;
          inputRefDom.click();
          window.addEventListener('focus', handleFocusChange);
        }
      }

      return { handleUpload, handleInputClick, inputRef };
    },
  });
</script>
