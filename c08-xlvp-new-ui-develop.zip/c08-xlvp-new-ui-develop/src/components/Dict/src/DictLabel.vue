<template>
  <span class="vdict-label" :title="label">{{ label }}</span>
</template>

<script setup lang="ts" inheritAttrs="false">
  import { useEffect } from '/@/hooks/core/useEffect';
  import { useState } from '/@/hooks/core/useState';
  import { useDonViCsgtStore } from '/@/store/modules/danh-muc/donViCsgt';
  import { propTypes } from '/@/utils/propTypes';
  import { DictType } from '/@/const/type';

  import { useDict } from './useDict';

  const props = defineProps({
    dictType: { type: String as PropType<DictType>, required: true },
    dictValue: propTypes.any,
  });

  const donViCsgtStore = useDonViCsgtStore();
  const [label, setLabel] = useState('');
  const { getDictLabel } = useDict();

  useEffect(() => {
    const text = getDictLabel(props.dictType, props.dictValue);
    setLabel(text);
  }, [() => props.dictValue, () => donViCsgtStore.loading]);
</script>
<style lang="less" scoped>
  .vdict-label {
    padding: 0 2px;
  }
</style>
