import { DictType } from '/@/const/type';
import { useI18n } from '/@/hooks/web/useI18n';
import { formatToDate, formatToDateTime } from '/@/utils/dateUtil';
import { useMauBbQdStoreWithOut } from '/@/store/modules/danh-muc/mauBbQd';
import { useDonViCsgtStoreWithOut } from '/@/store/modules/danh-muc/donViCsgt';

const { t } = useI18n();
const mauBbqdStore = useMauBbQdStoreWithOut();
const donViCsgtStore = useDonViCsgtStoreWithOut();

export function useDict() {
  function getDictLabel(dictType: DictType, value?: any, defaultValue = ''): string {
    if (!value) return defaultValue;
    switch (dictType) {
      case 'MAU_BBQD':
        const bbqd = mauBbqdStore.getByKey(value);
        return `${bbqd?.maBBQD} - ${bbqd?.ten}` || defaultValue;
      case 'DON_VI_CSGT':
        return donViCsgtStore.getByKey(value)?.tenVietTat || defaultValue;
      case 'TRANG_THAI':
        return t(`domain.trang_thai.${value.toLowerCase()}`);
      case 'DATE':
        return formatToDate(value);
      case 'DATE_TIME':
        return formatToDateTime(value);
      default:
        return defaultValue;
    }
  }
  return { getDictLabel };
}
