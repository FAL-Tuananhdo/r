import { withInstall } from '/@/utils';

import dictLabel from './src/DictLabel.vue';

export const DictLabel = withInstall(dictLabel);
