import { ActionItem } from '/@/components/Table';
import { useI18n } from '/@/hooks/web/useI18n';
import { deepMerge } from '/@/utils';
const { t } = useI18n();

class TableActionsBuilder {
  private actions: ActionItem[] = [];

  constructor() {}

  addView(action?: ActionItem) {
    this.actions.push(
      deepMerge(
        {
          icon: 'ant-design:eye-outlined',
          tooltip: t('common.detail_text'),
          color: 'success',
        },
        action,
      ),
    );

    return this;
  }

  addEdit(action?: ActionItem) {
    this.actions.push(
      deepMerge(
        {
          icon: 'clarity:note-edit-line',
          tooltip: t('common.edit_text'),
        },
        action,
      ),
    );
    return this;
  }

  addRemove(onConfirm?: Function, action?: ActionItem) {
    this.actions.push(
      deepMerge(
        {
          icon: 'ant-design:delete-outlined',
          color: 'error',
          tooltip: t('common.del_text'),
          popConfirm: {
            title: t('common.confirm_delete'),
            placement: 'left',
            confirm: onConfirm,
          },
        },
        action,
      ),
    );
    return this;
  }

  addDownload(action?: ActionItem) {
    this.actions.push(
      deepMerge(
        {
          icon: 'ant-design:download-outlined',
          tooltip: t('common.download_text'),
        },
        action,
      ),
    );
    return this;
  }

  addPrint(action?: ActionItem) {
    this.actions.push(
      deepMerge(
        {
          icon: 'ant-design:printer-outlined',
          tooltip: t('common.print_text'),
        },
        action,
      ),
    );
    return this;
  }

  addAction(action: ActionItem) {
    this.actions.push(action);
    return this;
  }

  build(): ActionItem[] {
    return this.actions;
  }
}

export function useTableActionsBuilder() {
  const builder = new TableActionsBuilder();

  return [builder];
}
