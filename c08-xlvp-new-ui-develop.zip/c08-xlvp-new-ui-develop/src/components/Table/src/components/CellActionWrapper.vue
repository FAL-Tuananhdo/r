<template>
  <TableAction v-bind="getComponentsProps" />
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { ActionItem } from '../types/tableAction';
  import TableAction from './TableAction.vue';

  const props = defineProps({
    record: {
      type: Object as PropType<Recordable>,
      default: () => ({}),
    },
    actions: {
      type: Function as PropType<(record: Recordable) => ActionItem[]>,
      default: () => {},
    },
    dropDownActions: {
      type: Function as PropType<(record: Recordable) => ActionItem[]>,
      default: () => {},
    },
  });

  const getComponentsProps = computed(() => {
    const { record, actions, dropDownActions } = props;
    return {
      actions: actions(record),
      dropDownActions: dropDownActions(record),
    };
  });
</script>
