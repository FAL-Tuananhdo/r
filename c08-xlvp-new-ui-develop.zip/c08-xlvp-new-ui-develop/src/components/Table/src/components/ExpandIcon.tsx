import { BasicArrow } from '/@/components/Basic';
import { isEmpty } from '/@/utils/is';

export default (
  expandCollapse: Fn,
  handleTableExpand: Fn,
  childrenColumnName = 'children',
  expandedRowRender = false,
) => {
  return (props: Recordable) => {
    const { treeLeaf, isLoading, children } = props.record;
    const childList = props.record[childrenColumnName];
    const leaf = !isEmpty(treeLeaf) ? treeLeaf : isEmpty(children || childList);
    return (
      <BasicArrow
        style={
          expandedRowRender
            ? ''
            : leaf
            ? 'margin-left: 1px; margin-right: 7px; opacity: 0.7;'
            : 'margin-right: 8px;'
        }
        iconStyle="vertical-align: middle; margin-top: -5px;"
        onClick={async (_e: Event) => {
          if (leaf) return;
          if (expandedRowRender) {
            props.onExpand(props.record, _e);
          } else {
            const expanded = await expandCollapse(props.record);
            handleTableExpand(expanded, props.record);
          }
        }}
        onDblclick={async (_e: Event) => {
          if (leaf) return;
          if (expandedRowRender) return;
          if (children || childList) return;
          const expanded = await expandCollapse(props.record, false, true);
          handleTableExpand(expanded, props.record);
        }}
        expand={props.expanded}
        leaf={leaf}
        loading={isLoading}
      />
    );
  };
};
