import { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';

export const pdfPageProps = {
  canvasId: {
    type: String,
    default: '',
  },
  page: {
    type: Number,
    required: true,
    default: 1,
  },
  pdfDoc: {
    type: Object as PropType<PDFDocumentProxy>,
    required: true,
    default: () => ({}),
  },
  scale: {
    type: Number,
    default: 1,
  },
  defaultCursor: {
    type: String,
  },
};
