export const useSignatureCavas = () => {};
