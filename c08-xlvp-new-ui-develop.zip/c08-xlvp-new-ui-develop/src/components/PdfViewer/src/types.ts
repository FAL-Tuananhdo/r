import { PageViewport } from 'pdfjs-dist/types/web/pdf_page_view';

import { PDFDocumentProxy, TypedArray } from 'pdfjs-dist/types/src/display/api';

export type PdfBinaryData = TypedArray | ArrayBuffer | Array<number> | string;

export interface IPdfInfo {
  loaded: boolean;
  pdfDoc: PDFDocumentProxy;
  total: number;
  viewport: PageViewport;
}

export interface IPdfPage {
  pdfDoc: PDFDocumentProxy;
  page: number;
  scale: number;
}

export interface ICoord {
  left: number;
  top: number;
  width: number;
  height: number;
}
