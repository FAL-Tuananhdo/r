import * as PDFJSlib from 'pdfjs-dist/build/pdf';
import PDFJSWorker from 'pdfjs-dist/build/pdf.worker?url';
import { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';

import { arrayBufferToBase64 } from '/@/utils/file/base64Conver';

import { PdfBinaryData } from '../types';

PDFJSlib.GlobalWorkerOptions.workerSrc = PDFJSWorker;

export async function getPDFDocument(data: PdfBinaryData): Promise<PDFDocumentProxy> {
  return PDFJSlib.getDocument({ data }).promise;
}

export function arrayBufferToBase64Pdf(data: ArrayBuffer) {
  return window.atob(arrayBufferToBase64(data));
}
