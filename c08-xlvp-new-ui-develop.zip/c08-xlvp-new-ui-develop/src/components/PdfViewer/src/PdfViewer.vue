<template>
  <Layout>
    <template #toolbar v-if="$slots['toolbar'] || enableSignature">
      <SignatureToolbar
        v-if="enableSignature"
        @add-signature="activateDrawingMode"
        @remove-signature="cancelDrawedSignature"
        @e-sign="submitSignature"
        :isDrew="!!signatureCanvas"
        :loadingSignature="loadingSignature"
      />
      <slot v-else name="toolbar" />
    </template>

    <template #left-sidebar v-if="isShowLeftSideBar">
      <PagesPreview
        :total="pdfInfo.total"
        :currentPage="currentPage"
        :pdfDoc="(pdfInfo.pdfDoc as PDFDocumentProxy)"
        :viewport="pdfInfo.viewport"
        @page="selectPage"
      />
    </template>

    <template v-show="pdfInfo.loaded" #main>
      <SinglePageViewer
        ref="pdfViewerCanvas"
        v-if="isSinglePage"
        v-bind="getHandlerOptions"
        :page="currentPage"
        :pdfDoc="(pdfInfo.pdfDoc as PDFDocumentProxy)"
        :scale="zoomLevel"
        :width="594"
        :height="840"
      />

      <MultiPagesViewer
        v-else
        :total="pdfInfo.total"
        :pdfDoc="(pdfInfo.pdfDoc as PDFDocumentProxy)"
        :viewport="pdfInfo.viewport"
        :zoomLevel="zoomLevel"
      />
    </template>

    <template #right-sidebar>
      <Space direction="vertical">
        <RightToolbar :zoomLevel="zoomLevel" :onZoom="useDebounceFn(handleZoom, 100)" />
        <slot name="right-sidebar" />
      </Space>
    </template>
  </Layout>
</template>

<script name="PdfSignaturePreview" setup lang="ts">
  import { Space } from 'ant-design-vue';
  import { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';
  import { PageViewport } from 'pdfjs-dist/types/src/display/display_utils';
  import { computed, onMounted, reactive, readonly, ref, toRaw, unref, watch } from 'vue';
  import { useDebounceFn } from '@vueuse/core';

  import { useState } from '/@/hooks/core/useState';
  import Handler, { HandlerOptions } from '/@/components/VCanvas/src/handlers/Handler';
  import { isFunction } from '/@/utils/is';

  import Layout from './components/Layout.vue';
  import MultiPagesViewer from './components/MultiPagesViewer.vue';
  import PagesPreview from './components/PagesPreview.vue';
  import RightToolbar from './components/RightToolbar.vue';
  import SinglePageViewer from './components/SinglePageViewer.vue';
  import SignatureToolbar from './components/SignatureToolbar.vue';
  import { ICoord, PdfBinaryData } from './types';
  import { getPDFDocument } from './utils/pdfjs';
  import DrawingSignatureHandler from './handler/DrawingSignatureHandler';

  const props = withDefaults(
    defineProps<{
      pdf: PdfBinaryData;
      defaultZoomLevel?: number;
      isSinglePage?: boolean;
      isShowLeftSideBar?: boolean;
      enableSignature?: boolean;
      handlerOptions?: HandlerOptions;
      onSign?: (page: number, coord: ICoord) => Promise<void>;
    }>(),
    {
      defaultZoomLevel: 1,
      isShowLeftSideBar: true,
    },
  );

  const pdfViewerCanvas = ref<null | InstanceType<typeof SinglePageViewer>>();

  const [currentPage, setCurrentPage] = useState<number>(1);
  const [zoomLevel, setZoomLevel] = useState<number>(props.defaultZoomLevel);
  const [signatureCanvas, setSignatureCanvas] = useState<any | undefined>();
  const [loadingSignature, setLoadingSignature] = useState<boolean>(false);

  const pdfInfo = reactive({
    total: 0,
    loaded: false,
    pdfDoc: {} as PDFDocumentProxy,
    viewport: {} as PageViewport,
  });

  const drawingSignatureContext = {
    activateDrawingMode: () => {
      const handler = unref(currentCanvas)?.handler;
      if (handler) {
        handler.interactionHandler.drawing();
        const signatureHandler = handler.handlers['signature'] as Nullable<DrawingSignatureHandler>;
        if (signatureHandler) {
          signatureHandler.drawInit();
        }
      }
    },
    onAdd: (target) => {
      setSignatureCanvas(target);
    },
    onLoad: (handler: Handler) => {
      handler.registerHandler('signature', DrawingSignatureHandler);
    },
  };

  const { onLoad, onAdd } = drawingSignatureContext;

  const getHandlerOptions = computed(() => ({ onLoad, onAdd, ...props.handlerOptions }));

  const currentCanvas = computed(() => unref(pdfViewerCanvas)?.vCanvas);

  function activateDrawingMode() {
    drawingSignatureContext.activateDrawingMode();
  }

  function cancelDrawedSignature() {
    if (!unref(currentCanvas)?.handler || !unref(signatureCanvas)) return;

    unref(currentCanvas)?.handler?.remove(toRaw(unref(signatureCanvas)));
    setSignatureCanvas(undefined);
  }

  async function submitSignature() {
    if (!unref(currentCanvas)?.handler || !unref(signatureCanvas)) return;

    const currentZoomLevel = unref(zoomLevel);

    const pageHeight = unref(pdfViewerCanvas)?.vCanvas?.canvas.height!;
    const signatureHeight = unref(signatureCanvas)?.height!;

    const coord: ICoord = {
      height: signatureHeight / currentZoomLevel,
      width: unref(signatureCanvas)?.width! / currentZoomLevel,
      top: (pageHeight - unref(signatureCanvas)?.top! - signatureHeight) / currentZoomLevel,
      left: unref(signatureCanvas)?.left! / currentZoomLevel,
    };

    try {
      setLoadingSignature(true);
      isFunction(props.onSign) && (await props.onSign(unref(currentPage) - 1, coord));
    } catch {
    } finally {
      unref(currentCanvas)?.handler?.remove(toRaw(unref(signatureCanvas)));
      setSignatureCanvas(undefined);
      setLoadingSignature(false);
    }
  }

  function selectPage(page: number) {
    setCurrentPage(page);
  }

  function handleZoom(value: number) {
    setZoomLevel(value);
  }

  async function getPdfDoc(source: PdfBinaryData) {
    const pdfDoc = await getPDFDocument(source);
    const pdfPage = await toRaw(pdfDoc).getPage(1);
    const viewport = pdfPage.getViewport({ scale: 1 });
    pdfInfo.pdfDoc = pdfDoc;
    pdfInfo.total = pdfDoc.numPages;
    pdfInfo.viewport = viewport;
    pdfInfo.loaded = true;
  }

  watch(
    () => props.pdf,
    async (source) => {
      if (!props.pdf) return;
      await getPdfDoc(source);
    },
  );

  onMounted(async () => {
    await getPdfDoc(props.pdf);
  });

  defineExpose({ pdfViewerCanvas: readonly(pdfViewerCanvas) });
</script>
