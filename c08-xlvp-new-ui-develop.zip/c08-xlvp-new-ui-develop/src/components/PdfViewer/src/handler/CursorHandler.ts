import { Handler, CustomHandler } from '/@/components/VCanvas';

class CursorHandler extends CustomHandler {
  constructor(handler: Handler) {
    super(handler);
  }

  public setDefaultCursor = (cursor?: string) => {
    this.handler.canvas.defaultCursor = cursor || 'default';
  };
}

export default CursorHandler;
