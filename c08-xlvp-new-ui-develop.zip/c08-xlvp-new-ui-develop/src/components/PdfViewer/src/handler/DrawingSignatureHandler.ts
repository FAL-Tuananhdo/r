import { FabricEvent, FabricObject, Handler, CustomHandler } from '/@/components/VCanvas';

class DrawingSignatureHandler extends CustomHandler {
  private isDrawing = false;
  private originPoint = {
    left: 0,
    top: 0,
  };
  private rect: Nullable<FabricObject> = null;

  constructor(handler: Handler) {
    super(handler);
    this.initialize();
  }

  private initialize() {
    // @ts-ignore
    this.handler.canvas.on({
      'mouse:down': this.mousedown,
      'mouse:move': this.mousemove,
      'mouse:up': this.mouseup,
      'object:modified': this.modified,
    });
  }

  public drawInit = () => {
    if (this.handler.editable && this.isDrawingMode()) {
      this.handler.canvas.defaultCursor = 'crosshair';
    }
  };

  private modified = (opt: FabricEvent) => {
    const { target } = opt;
    if (!target) {
      return;
    }
    const currentCanvas = this.handler.canvas;

    if (currentCanvas) {
      const boudingBox = target.getBoundingRect();
      const isOutSide = this.isOutSideTheBoundary(boudingBox, {
        height: currentCanvas.getHeight(),
        width: currentCanvas.getWidth(),
      });

      if (isOutSide) {
        const center = currentCanvas.getCenter();
        target.top = center.top / 2;
        target.left = center.left - boudingBox.width / 2;
        target.setCoords();
      }
    }
  };

  private mousedown = (opt: fabric.IEvent) => {
    const event = opt as FabricEvent<MouseEvent>;
    const { editable } = this.handler;
    if (!editable || !this.isDrawingMode()) return;

    if (!this.isDrawing) this.isDrawing = true;
    const { x, y } = this.handler.canvas.getPointer(event.e);
    this.originPoint = {
      left: x,
      top: y,
    };

    this.rect = this.handler.add({
      type: 'rect',
      left: x,
      top: y,
      fill: 'rgba(255,0,0,0.5)',
      originX: 'left',
      originY: 'top',
      lockRotation: true,
      hasRotatingPoint: false,
      cornerStyle: 'circle',
      transparentCorners: false,
    });

    if (!this.rect) return;
    this.rect.setControlsVisibility({ mtr: false });
  };

  private mousemove = (opt: FabricEvent) => {
    const event = opt as FabricEvent<MouseEvent>;
    const { editable } = this.handler;
    if (!editable || !this.rect || !this.isDrawing || !this.rect || !this.isDrawingMode()) return;
    const { x, y } = this.handler.canvas.getPointer(event.e);
    let bounds = {
      height: 0,
      left: 0,
      top: 0,
      width: 0,
    };
    if (this.originPoint.left > x) {
      bounds.left = Math.max(0, x);
      bounds.width = this.originPoint.left - bounds.left;
    } else {
      bounds.left = this.originPoint.left;
      bounds.width = Math.min(
        x - this.originPoint.left,
        this.handler.canvas.getWidth() - this.originPoint.left,
      );
    }
    if (this.originPoint.top > y) {
      bounds.top = Math.max(0, y);
      bounds.height = this.originPoint.top - bounds.top;
    } else {
      bounds.height = Math.min(
        y - this.originPoint.top,
        this.handler.canvas.getHeight() - this.originPoint.top,
      );
      bounds.top = this.originPoint.top;
    }
    this.rect.set({
      left: bounds.left,
      top: bounds.top,
      width: bounds.width,
      height: bounds.height,
      dirty: true,
    });
    this.handler.canvas.renderAll();
  };

  private mouseup = (_: FabricEvent) => {
    if (this.isDrawingMode()) {
      this.isDrawing = false;
      this.drawSuccess();
    }
  };

  private drawSuccess() {
    if (this.handler.editable && this.isDrawingMode()) {
      this.handler.canvas.defaultCursor = 'default';
      this.handler.interactionHandler.selection();

      this.originPoint = {
        left: 0,
        top: 0,
      };
      this.rect = null;
    }
  }

  private isDrawingMode = () => {
    return this.handler.interactionMode === 'drawing';
  };

  private isOutSideTheBoundary(position, limit: { width: number; height: number }) {
    return (
      position.left < 0 ||
      position.top < 0 ||
      position.left + position.width > limit.width ||
      position.top + position.height > limit.height
    );
  }
}

export default DrawingSignatureHandler;
