<template>
  <Popover :title="t('component.cropper.btn_zoom_in_out')" trigger="click" placement="left">
    <template #content>
      <Slider v-model:value.lazy="scale" :min="0.5" :max="2" :step="0.01" />
    </template>
    <Button>
      <template #icon><CompressOutlined /> </template>
    </Button>
  </Popover>
</template>

<script setup lang="ts">
  import { CompressOutlined } from '@ant-design/icons-vue';
  import { Button, Popover, Slider } from 'ant-design-vue';
  import { ref, watch } from 'vue';
  import { useI18n } from '/@/hooks/web/useI18n';

  const props = defineProps<{ zoomLevel: number; onZoom: (value: number) => void }>();

  const scale = ref<number>(props.zoomLevel);

  const { t } = useI18n();

  watch(scale, (current) => {
    props.onZoom(current);
  });
</script>
