<template>
  <ul ref="el" class="pages flex flex-col h-full w-full px-5">
    <li
      v-for="page in total"
      :key="page"
      @click="selectPage(page)"
      :class="[
        'pages__item relative w-full flex justify-center py-3',
        { active: page === currentPage },
      ]"
    >
      <SinglePageViewer
        :canvasId="`canvas-page-${page}`"
        class="pages__item-pdf"
        :page="page"
        :pdf-doc="pdfDoc"
        :scale="scale"
        :width="191"
        :height="270"
        defaultCursor="pointer"
      />
    </li>
  </ul>
</template>

<script setup lang="ts">
  import { computed, ref, unref } from 'vue';
  import { useElementSize } from '@vueuse/core';
  import { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';
  import { PageViewport } from 'pdfjs-dist/types/src/display/display_utils';

  import SinglePageViewer from './SinglePageViewer.vue';

  interface Props {
    total: number;
    currentPage: number;
    pdfDoc: PDFDocumentProxy;
    viewport: PageViewport;
  }

  const props = defineProps<Props>();

  const emit = defineEmits<{
    (e: 'page', page: number): void;
  }>();

  const el = ref(null);
  const { width } = useElementSize(el);

  const scale = computed(() => {
    return unref(width) / props.viewport.width;
  });

  function selectPage(page: number) {
    emit('page', page);
  }
</script>

<style lang="less" scoped>
  .pages {
    &__item {
      &:hover {
        .pages__item-pdf {
          box-shadow: 0 0 0 1px rgb(0 0 0 / 50%), 0 0px 16px rgb(0 0 0 / 40%);
        }
      }

      &.active {
        .pages__item-pdf {
          box-shadow: 0 0 0 1px rgb(0 0 0 / 50%), 0 0px 16px rgb(0 0 0 / 40%);
        }
      }

      &-pdf {
        cursor: pointer;
      }
    }
  }
</style>
