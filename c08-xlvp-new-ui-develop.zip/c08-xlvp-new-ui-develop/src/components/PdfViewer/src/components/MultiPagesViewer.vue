<template>
  <ul ref="el" class="pages flex flex-col h-full w-full px-5">
    <li
      v-for="page in total"
      :key="page"
      class="pages__item relative w-full flex justify-center py-3"
    >
      <SinglePageViewer
        :canvasId="`canvas-multi-pages-${page}`"
        class="pages__item-pdf"
        :page="page"
        :pdfDoc="pdfDoc"
        :scale="scale"
        :width="594"
        :height="840"
      />
    </li>
  </ul>
</template>

<script setup lang="ts">
  import { computed, ref, unref } from 'vue';
  import { useElementSize } from '@vueuse/core';
  import { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';
  import { PageViewport } from 'pdfjs-dist/types/src/display/display_utils';

  import SinglePageViewer from './SinglePageViewer.vue';

  interface Props {
    total: number;
    pdfDoc: PDFDocumentProxy;
    viewport: PageViewport;
    zoomLevel: number;
  }

  const props = defineProps<Props>();

  // const emit = defineEmits<{
  //   (e: 'page', page: number): void;
  // }>();

  const el = ref(null);
  const { height } = useElementSize(el);

  const scale = computed(() => {
    return (unref(height) / props.viewport.height) * props.zoomLevel;
  });

  // function getCurrentPage() {
  //   console.log('scroll');
  // }
</script>
