<template>
  <div class="flex justify-end" ref="el">
    <Space>
      <Button
        v-if="!isDrawing"
        :disabled="loadingSignature"
        size="middle"
        type="primary"
        @click="addSign"
      >
        <template #icon>
          <PlusOutlined />
        </template>
        {{ t('domain.quyet_dinh.tao_ky_so') }}
      </Button>

      <Button v-if="isDrawing" size="middle" type="primary" danger @click="removeSign">
        <template #icon>
          <MinusOutlined />
        </template>
        {{ t('domain.quyet_dinh.huy_tao_ky_so') }}
      </Button>

      <Button
        size="middle"
        :loading="loadingSignature"
        type="primary"
        @click="kySo"
        :disabled="!isDrew"
      >
        <template #icon>
          <EditOutlined />
        </template>
        {{ t('domain.quyet_dinh.ky_so') }}
      </Button>
    </Space>
  </div>
</template>

<script setup lang="ts">
  import { PlusOutlined, MinusOutlined, EditOutlined } from '@ant-design/icons-vue';
  import { Button, Space } from 'ant-design-vue';

  import { useI18n } from '/@/hooks/web/useI18n';
  import { useState } from '/@/hooks/core/useState';

  const emits = defineEmits(['e-sign', 'add-signature', 'remove-signature']);
  defineProps<{
    isDrew: boolean;
    loadingSignature: boolean;
  }>();

  const { t } = useI18n();
  const [isDrawing, setIsDrawing] = useState<boolean>(false);

  const addSign = () => {
    setIsDrawing(true);
    emits('add-signature');
  };

  const removeSign = () => {
    setIsDrawing(false);
    emits('remove-signature');
  };

  const kySo = () => {
    setIsDrawing(false);
    emits('e-sign');
  };
</script>
