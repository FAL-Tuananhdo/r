<template>
  <VCanvas
    v-bind="getAttrs"
    class="border border-gray-500 border-opacity-100"
    :id="canvasId"
    ref="vCanvas"
  />
</template>

<script setup lang="ts">
  import { fabric } from 'fabric';
  import { PDFDocumentProxy } from 'pdfjs-dist/types/src/display/api';
  import { computed, readonly, ref, toRaw, unref, watchEffect } from 'vue';

  import { Handler, VCanvas } from '/@/components/VCanvas';
  import { isEmpty } from '/@/utils/is';
  import { useAttrs } from '/@/hooks/core/useAttrs';

  import { pdfPageProps } from '../props';
  import CursorHandler from '../handler/CursorHandler';

  interface SpecifyPageArgs {
    page: number;
    pdfDoc: PDFDocumentProxy;
    scale?: number;
  }

  const props = defineProps(pdfPageProps);

  const vCanvas = ref<Nullable<InstanceType<typeof VCanvas>>>(null);

  const attrs = useAttrs();

  const controlCursorContext = {
    setDefaultCursor: (cursor?: string) => {
      const handler = unref(vCanvas)?.handler;
      if (handler) {
        const myHandler = handler.handlers['mycursor'] as Nullable<CursorHandler>;
        if (myHandler) {
          myHandler.setDefaultCursor(cursor);
        }
      }
    },
    onLoad: (handler: Handler) => {
      handler.registerHandler('mycursor', CursorHandler);
    },
  };

  const getAttrs = computed(() => {
    if (props.defaultCursor) return { ...unref(attrs), onLoad: controlCursorContext.onLoad };
    return unref(attrs);
  });

  async function specifyPage({ page, pdfDoc, scale = 1 }: SpecifyPageArgs) {
    if (isEmpty(toRaw(pdfDoc))) return;

    const pdfPage = await toRaw(pdfDoc).getPage(page);
    const viewport = pdfPage.getViewport({ scale });
    const pdfCanvas = document.createElement('canvas');
    const context = pdfCanvas.getContext('2d');
    const renderContext = {
      canvasContext: context!,
      viewport,
    };

    const renderTask = pdfPage.render(renderContext);

    pdfCanvas.height = viewport.height;
    pdfCanvas.width = viewport.width;
    return renderTask.promise.then(() => {
      if (!vCanvas.value) {
        return;
      }
      const { canvas: currentCanvas } = vCanvas.value!;

      if (currentCanvas) {
        const image = new fabric.Image(pdfCanvas);
        currentCanvas.setWidth(image.width!);
        currentCanvas.setHeight(image.height!);
        currentCanvas.setBackgroundImage(image, currentCanvas.renderAll.bind(currentCanvas));
      }
    });
  }

  watchEffect(() => {
    if (props.defaultCursor) controlCursorContext.setDefaultCursor(props.defaultCursor);
    specifyPage(props);
  });

  defineExpose({
    vCanvas: readonly(vCanvas),
  });
</script>
