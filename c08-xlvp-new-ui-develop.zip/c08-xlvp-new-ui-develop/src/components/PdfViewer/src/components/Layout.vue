<template>
  <div class="pdf-layout flex flex-col h-full w-full">
    <div v-if="$slots['toolbar']" class="pdf-layout-toolbar flex justify-end">
      <slot name="toolbar" />
    </div>

    <div class="pdf-layout-content flex flex-row w-full">
      <div v-if="$slots['left-sidebar']" class="w-1/5 overflow-y-auto relative">
        <slot name="left-sidebar" />
      </div>
      <div class="flex w-full relative justify-center overflow-auto border">
        <slot name="main" />
      </div>
      <div
        v-if="$slots['right-sidebar']"
        class="min-w-36px pt-2 ml-3 overflow-y-auto relative text-center"
      >
        <slot name="right-sidebar" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts"></script>

<style lang="less" scoped>
  .pdf-layout {
    @toolbarHeight: 40px;

    &-toolbar {
      height: @toolbarHeight;
    }

    &-content {
      height: 100%;
    }

    .pdf-layout-toolbar + .pdf-layout-content {
      height: calc(100% - @toolbarHeight);
    }
  }
</style>
