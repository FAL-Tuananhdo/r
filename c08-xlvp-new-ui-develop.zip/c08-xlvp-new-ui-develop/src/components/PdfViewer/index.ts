export { default as PdfViewer } from './src/PdfViewer.vue';

export type { PdfBinaryData, ICoord } from './src/types';
