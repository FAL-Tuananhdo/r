// Refer to qr-code-with-logo for ts version modification
import { toCanvas } from './toCanvas';
export * from './typing';
export { toCanvas };
