<template>
  <ApiSelectHSmall
    v-bind="$attrs"
    :api="handleApi"
    showSearch
    :filterOption="false"
    :labelField="labelFieldDefault"
    :valueField="valueFieldDefault"
    :params="searchParams"
    @search="onSearch"
    @change="handleChange"
    :listHeight="100"
  />
</template>

<script lang="ts">
  import { computed, defineComponent, ref, unref } from 'vue';

  import { useDebounceFn } from '@vueuse/core';
  // import { useXlvpApi } from '/@/api';
  import { getListQuanLySeriChuForSelect } from '/@/api/quan-ly-bien-so/quan-ly-seri-chu';
  import {
    ISearchParamQuanLySeriChu,
    IQuanLySeriChu,
  } from '/@/api/quan-ly-bien-so/quan-ly-seri-chu/model';
  import ApiSelectHSmall from '/@/components/Form/src/components/ApiSelectHeightSmall.vue';
  // import { IChucVu, ISearchChucVu } from '/@/api/danh-muc-dung-chung/chuc-vu/model';

  const labelFieldDefault: keyof IQuanLySeriChu = 'seriChu';
  const valueFieldDefault: keyof IQuanLySeriChu = 'id';

  export default defineComponent({
    name: 'SelectCanBo',
    components: { ApiSelectHSmall },
    inheritAttrs: false,
    props: {
      isObjectValue: { type: Boolean, default: false },
    },
    emits: ['change'],
    setup(props, { emit }) {
      // const { chucVuApi } = useXlvpApi();
      const keyword = ref<string>('');

      // const searchParams = computed<ISearchChucVu>(() => ({ tenChucVu: unref(keyword) }));
      const searchParams = computed<ISearchParamQuanLySeriChu>(() => ({ seriChu: unref(keyword) }));

      const handleApi = async (params: ISearchParamQuanLySeriChu) => {
        // const res = await chucVuApi.getAll(params);
        const res = await getListQuanLySeriChuForSelect(params);
        return res;
      };

      function handleChange(
        value?: string,
        selectObject?: ISearchParamQuanLySeriChu & { label: string; value: string },
      ) {
        const itemSelected =
          !!value && props.isObjectValue
            ? {
                ...selectObject,
                [labelFieldDefault]: selectObject?.label,
                [valueFieldDefault]: selectObject?.value,
              }
            : value;
        emit('change', itemSelected);
      }

      function onSearch(value: string) {
        keyword.value = value;
      }

      return {
        searchParams,
        handleApi,
        handleChange,
        onSearch: useDebounceFn(onSearch, 300),
        labelFieldDefault,
        valueFieldDefault,
      };
    },
  });
</script>
