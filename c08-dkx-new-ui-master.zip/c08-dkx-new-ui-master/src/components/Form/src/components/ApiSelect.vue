<template>
  <Select
    @dropdownVisibleChange="handleFetch"
    v-bind="$attrs"
    @change="handleChange"
    :options="getOptions"
    v-model:value="state"
    :listHeight="height"
    :dropdownMatchSelectWidth="false"
    dropdownClassName="drop"
    placeholder=""
    style="font-weight: 500; color: #1327DC"
    optionLabelProp="label"
    optionFilterProp="label"
    :allow-clear="clearOptions"
  >
    <template #[item]="data" v-for="item in Object.keys($slots)">
      <slot :name="item" v-bind="data || {}"></slot>
    </template>
    <template #suffixIcon v-if="loading">
      <LoadingOutlined spin />
    </template>
    <template #notFoundContent v-if="loading">
      <span>
        <LoadingOutlined spin class="mr-1" />
        {{ t('component.form.apiSelectNotFound') }}
      </span>
    </template>
  </Select>
</template>
<script lang="ts">
  import { defineComponent, PropType, ref, watchEffect, computed, unref, watch } from 'vue';
  import { Select } from 'ant-design-vue';
  import { isFunction } from '/@/utils/is';
  import { useRuleFormItem } from '/@/hooks/component/useFormItem';
  import { useAttrs } from '/@/hooks/core/useAttrs';
  import { get, omit } from 'lodash-es';
  import { LoadingOutlined } from '@ant-design/icons-vue';
  import { useI18n } from '/@/hooks/web/useI18n';
  import { propTypes } from '/@/utils/propTypes';

  type OptionsItem = { label: string; value: string; disabled?: boolean };
  export default defineComponent({
    name: 'ApiSelect',
    components: {
      Select,
      LoadingOutlined,
    },
    inheritAttrs: false,
    props: {
      value: [Array, Object, String, Number],
      numberToString: propTypes.bool,
      api: {
        type: Function as PropType<(arg?: Recordable) => Promise<OptionsItem[]>>,
        default: null,
      },
      // api params
      params: {
        type: Object as PropType<Recordable>,
        default: () => ({}),
      },
      // support xxx.xxx.xx
      listHeight: propTypes.number.def(150),
      resultField: propTypes.string.def(''),
      labelField: propTypes.string.def('label'),
      valueField: propTypes.string.def('value'),
      disabledField: propTypes.string.def(''),
      immediate: propTypes.bool.def(true),
      clearOptions: propTypes.bool.def(true),
      defaultValue: propTypes.string.def(''),
      autoSetValue: propTypes.bool.def(false),
    },
    emits: ['options-change', 'change'],
    setup(props, { emit }) {
      const options = ref<OptionsItem[]>([]);
      const loading = ref(false);
      const isFirstLoad = ref(true);
      const emitData = ref<any[]>([]);
      const attrs = useAttrs();
      const { t } = useI18n();
      const height = ref();
      const styleVal = ref();
      // Embedded in the form, just use the hook binding to perform form verification
      const [state] = useRuleFormItem(props, 'value', 'change', emitData);
      const getOptions = computed(() => {
        const { labelField, valueField, disabledField } = props;

        return unref(options).reduce((prev, next: Recordable) => {
          if (next) {
            const disabled = next[disabledField] === 'true';
            const value = next[valueField];
            prev.push({
              ...omit(next, [labelField, valueField]),
              label: next[labelField],
              // value: numberToString ? `${value}` : value,
              value: `${value}`,
              disabled: disabled,
            });
          }
          return prev;
        }, [] as OptionsItem[]);
      });

      watchEffect(() => {
        props.immediate && fetch();
      });

      watch(
        () => props.params,
        () => {
          !unref(isFirstLoad) && fetch();
        },
        { deep: true },
      );

      async function fetch() {
       const api = props.api;
        if (!api || !isFunction(api)) return;
        options.value = [];
        try {
          loading.value = true;
          const res = await api(props.params);
          if (Array.isArray(res)) {
            options.value = res;
            const arrLength = res.length;
            const crrValue = state.value;
            const defaultValue = props.defaultValue;
            if (crrValue) {
              var defVal = crrValue;
              for (let i = 0; i < arrLength; i++) {
                if (res[i][props.valueField] == crrValue) {
                  defVal = crrValue;
                  state.value = `${defVal}`;
                  break;
                } else {
                  if (props.autoSetValue == true) {
                    defVal = res[0][props.valueField];
                    state.value = `${defVal}`;
                  }
                }
              }
            } else {
              if (defaultValue) {
                defVal = defaultValue;
                for (let i = 0; i < arrLength; i++) {
                  if (res[i][props.valueField] == defaultValue) {
                    defVal = defaultValue;
                    state.value = `${defVal}`;
                    break;
                  } else {
                    if (props.autoSetValue == true) {
                      defVal = res[0][props.valueField];
                      state.value = `${defVal}`;
                    }
                  }
                }
              } else {
                if (props.autoSetValue == true) {
                  defVal = res[0][props.valueField];
                  state.value = `${defVal}`;
                }
              }
            }

            if (props.listHeight != 150) {
              height.value = props.listHeight;
            } else {
              height.value = 150;
            }
            emitChange();
            return;
          }

          if (props.resultField) {
            options.value = get(res, props.resultField) || [];
          }
          emitChange();
        } catch (error) {
          // console.warn(error);
        } finally {
          loading.value = false;
        }
      }

      async function handleFetch() {
        if (!props.immediate && unref(isFirstLoad)) {
          await fetch();
          isFirstLoad.value = false;
        }
      }

      function emitChange() {
        emit('options-change', unref(getOptions));
      }

      function handleChange(_, ...args) {
        emitData.value = args;
      }
      const filterOption = (input: string, option: any) => {
        return option.labelField.toLowerCase().indexOf(input.toLowerCase()) == 0;
      };

      return {
        state,
        attrs,
        getOptions,
        loading,
        t,
        handleFetch,
        handleChange,
        filterOption,
        height,
      };
    },
  });
</script>
