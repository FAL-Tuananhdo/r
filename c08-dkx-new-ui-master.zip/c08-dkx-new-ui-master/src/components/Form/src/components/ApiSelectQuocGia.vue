<template>
  <ApiSelect
    v-bind="$attrs"
    :api="handleApi"
    showSearch
    :filterOption="false"
    :labelField="labelFieldDefault"
    :valueField="valueFieldDefault"
    :params="searchParams"
    @search="onSearch"
    @change="handleChange"
  />
</template>
<script lang="ts">
  import { defineComponent, ref } from 'vue';
  import { useDebounceFn } from '@vueuse/core';
  import { getListQuocGiaSelect } from '/@/api/danh-muc/quoc-gia';
  import { IQuocGiaDto } from '/@/api/danh-muc/quoc-gia/dto';
  import { ApiSelect } from '/@/components/Form';

  const labelFieldDefault: keyof IQuocGiaDto = 'tenQuocGia';
  const valueFieldDefault: keyof IQuocGiaDto = 'id';

  export default defineComponent({
    name: 'ApiSelectQuocGia',
    components: { ApiSelect },
    inheritAttrs: false,
    props: {
      isObjectValue: { type: Boolean, default: false },
      type: {
        type: [String] as PropType<IQuocGiaDto | undefined>,
        default: null,
      },
    },
    emits: ['change'],
    setup(props, { emit }) {
      const keyword = ref<string>('');
      const handleApi = async () => {
        const res = await getListQuocGiaSelect();
        //console.log(res, 'res trong apiselectquocgia');//.items.map

        //const options: LabelValueOptions = ((res) => {
        //  labelFieldDefault: res.tenQuocGia,
        //    valueFieldDefault: res.id,
        //});
        //console.log(options, 'option áhbdkas');
        //for (int i; i<= )
        return res[0].item;
      };

      function handleChange(
        value?: string,
        selectObject?: IQuocGiaDto & { label: string; value: string },
      ) {
        const itemSelected =
          !!value && props.isObjectValue
            ? {
                ...selectObject,
                [labelFieldDefault]: selectObject?.label,
                [valueFieldDefault]: selectObject?.value,
              }
            : value;
        emit('change', itemSelected);
      }

      function onSearch(value: string) {
        keyword.value = value;
      }
      return {
        //searchParams,
        handleApi,
        handleChange,
        onSearch: useDebounceFn(onSearch, 300),
        labelFieldDefault,
        valueFieldDefault,
      };
    },
  });
</script>
