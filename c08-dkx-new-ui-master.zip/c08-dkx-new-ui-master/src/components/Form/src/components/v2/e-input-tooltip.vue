<template>
     <div >
         <a-tooltip v-if="!disabled" :placement="tooltipPoint">
          <template v-if="tooltipContent !== null" #title>
            <span v-html="tooltipContent"/>
          </template>
          <a-input :autofocus="autofocus" :size="size" v-model:value="valueInput" :placeholder="placeholder" 
                            @change="onLoadChange" 
                            @blur="onLoadBlur" :style="style" :class="getClassInput()" allow-clear>
                <template #suffix>
                  <LoadingOutlined v-if="isLoadingInput"/>
                </template>
          </a-input>
        </a-tooltip>

         <span v-if="disabled" style="font-weight: 500; color: #1327DC" :style="style">
             {{ valueText }}
         </span>
    </div>
 </template>
 
 <script >
   import { LoadingOutlined, EditOutlined    } from '@ant-design/icons-vue';
   import appUtils from '/@/utils/v2/app-utils'
   import { noAccentLower } from '/@/utils/v2/no-accent';
   export default {
     name:'EInputTooltip',
     components:{
      EditOutlined,
      LoadingOutlined  
     },
     props:{
         value:  [Array, Object, String, Number],
         size: {
           type: String,
           default: 'small'
         },
         style:{
           type: String,
           default: ''
         },
         disabled: {
           type: Boolean,
           default: false
         },
         
         autofocus: {
           type: Boolean,
           default: false
         },
         
         placeholder: {
          type: String,
          default: ''
         },

         tooltipPoint:{
          type: String,
          default: 'topRight'
         },

         tooltipContent:{
          type: String,
          default: null
         },
         
         class:{
          type: String,
          default: null
         },

         style:{
          type: String,
          default: ''
         },

         onChange:{
           type: Function,
           default: null
         },
         onBlur:{
           type: Function,
           default: null
         }
     },
     data() {
       return {
        isLoadingInput: false
       }
     },
     computed:{
       valueInput:appUtils.mapComputed('value'),
     },
 
     created(){
     },
     watch:{
     },
     methods:{
        async onLoadChange(event){
          this.isLoadingInput = true
          try{
            if(typeof this.onChange !== 'function'){
              return
            }
            await this.onChange(event)
          }catch(e){
            console.log(e);
          }finally{
            this.isLoadingInput = false
          }
        },

        async onLoadBlur(event){
          this.isLoadingInput = true
          try{
            if(typeof this.onBlur !== 'function'){
              return
            }
            await this.onBlur(event)
          }catch(e){
            console.log(e);
          }finally{
            this.isLoadingInput = false
          }
        },

        getClassInput(){
          if(typeof this.class === 'string' ){
            return [this.class]
          }
          return (!this.class ? []: this.class)
        }


     }
   }
 </script>
 
 