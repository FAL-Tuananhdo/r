import { withInstall } from '/@/utils';
import flowChart from './src/FlowChart.vue';

export const FlowChart = withInstall(flowChart);
