import { authHttp, mockHttp, iamHttp } from '/@/utils/http/axios';
import {
  GroupRoleIam,
  LoginParams,
  LoginResultModel,
  UserAccountResultModel,
  RoleIam,
} from './model/userModel';

import { ErrorMessageMode } from '/#/axios';

enum Api {
  Login = '/signin',
  Logout = '/logout',
  GetUserAccountInfo = '/validate-jose',
  GetPermCode = '/getPermCode',
  GetGroupRoleList = '/cate/v1/group/get-by-permission',
  GetRoleList = '/cate/api/auth/cas/get-menu-group-by-parent-code', //'/cate/v1/menu/get-all-permission-by-parentcode',
  GetRoleUserDKX = '/v1/role',
}

/**
 * @description: user login api
 */
export function loginApi(params: LoginParams, mode: ErrorMessageMode = 'modal') {
  return authHttp.post<LoginResultModel>(
    {
      url: Api.Login,
      params,
    },
    {
      errorMessageMode: mode,
    },
  );
}

export function getUserAccountInfo() {
  return authHttp.get<UserAccountResultModel>(
    { url: Api.GetUserAccountInfo },
    { errorMessageMode: 'none' },
  );
}
// get role và role group từ IAM
export function getGroupRoleListUser(appCode: string, username: string) {
  return iamHttp.get<GroupRoleIam[]>(
    {
      url: Api.GetGroupRoleList,
      params: {
        username: username,
        appCode: appCode,
      },
    },
    { errorMessageMode: 'message' },
  );
}

export function getRoleListUser(appCode: string) {
  return iamHttp.get<RoleIam[]>(
    {
      url: Api.GetRoleList,
      params: {
        type: 5,
        appCode: appCode,
      },
    },
    { errorMessageMode: 'message' },
  );
}

export function getRoleListMenuUser(appCode: string) {
  return iamHttp.get<RoleIam[]>(
    {
      url: Api.GetRoleList,
      params: {
        type: 1,
        appCode: appCode,
      },
    },
    { errorMessageMode: 'message' },
  );
}

export function getPermCode() {
  return mockHttp.get<string[]>({ url: Api.GetPermCode });
}

export function doLogout() {
  return mockHttp.get({ url: Api.Logout });
}
