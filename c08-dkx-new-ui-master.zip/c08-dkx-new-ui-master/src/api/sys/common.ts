import { CaptchaResultModel } from './model/captchaModel';
import { ErrorMessageMode } from '/#/axios';
import { authHttp } from '/@/utils/http/axios';

enum Api {
  Captcha = '/get-captcha',
}

export function getCaptcha(mode: ErrorMessageMode = 'message') {
  return authHttp.get<CaptchaResultModel>(
    {
      url: Api.Captcha,
    },
    {
      errorMessageMode: mode,
    },
  );
}
