export interface CaptchaResultModel {
  captchaImage: string;
  captchaSecret: string;
  expirationTime: Number;
}
