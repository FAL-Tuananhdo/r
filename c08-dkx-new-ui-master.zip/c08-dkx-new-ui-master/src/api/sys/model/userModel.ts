/**
 * @description: Login interface parameters
 */
export interface LoginParams {
  username: string;
  password: string;
  captchaKey?: string;
  captchaSecret?: string;
}

// type quyền
export interface GroupRoleIam {
  name: string;
  description: string;
  groupCode: string;
  appCode: string;
  status: string;
}
export interface RoleIam {
  parentCode: string;
  lstMenu: lstMenu[];
}
export interface GroupRole {
  tenNhomQuyen: string;
  maNhomQuyen: string;
  appCode: string;
  userName: string;
}
export interface Roles {
  tenQuyen: string;
  maQuyen: string;
  appCode: string;
  userName: string;
}
export interface lstMenu {
  appCode: string;
  menuCode: string;
  name: string;
  url: string;
  parentCode: string;
  status: string;
  levelUsed: string;
}

/**
 * @description: Login interface return value
 */
export interface LoginResultModel {
  accessToken: string;
  tokenType: string;
  qrTotp?: string;
}

export interface UserAccountResultModel {
  ufn: string;
  uid: string;
  orgName: string;
  posName: string;
  depName: string;
  org: string;
  ema: string;
}

/**
 * @description: Get user information return value
 */
export interface GetUserInfoModel {
  roles: GroupRole[];
  // 用户id
  userId: string | number;
  // 用户名
  username: string;
  // 真实名字
  realName: string;
  // 头像
  avatar: string;
  // 介绍
  desc?: string;

  qrCode?: string;
}
