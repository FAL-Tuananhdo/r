import { useUserStore } from '/@/store/modules/user';
import { reportHttpExport } from '/@/utils/http/axios';

import { IExportReport } from '../model';

enum Api {
  view_report = '/v1/reporting/view-bc-tong-hop',
}

const userStore = useUserStore();
const { username } = userStore.getUserInfo;

export const exportReportBaoCaoTongHop = async (params: IExportReport) => {
  const res = await reportHttpExport.downloadFileExcel({
    url: Api.view_report,
    params: { ...params, username: username },
  });
  return res;
};
