import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IListBienCapVuotDto } from './dto';
import { ISearchBienCapVuot, IListBienCapVuot } from './model';
import { transformSearchParamsToDto, transformListBienCapVuotDtoToModel } from './helper';

enum Api {
  main = '/v1/o-bao-cao/bien-vuot',
  excel = '/v1/o-bao-cao/xe-cu/excel',
}

export const getListBienCapVuot = async (params: ISearchBienCapVuot): Promise<IListBienCapVuot> => {
  const res = await localHttp.get<IListBienCapVuotDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListBienCapVuotDtoToModel(res);
};

export const dowloadExcel = async (params: IListBienCapVuot): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: params,
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', 'baocaobiencapvuot.xlsx');
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};
