import { IBienCapVuotDto, ISearchBienCapVuotDto, IListBienCapVuotDto } from './dto';
import { IBienCapVuot, ISearchBienCapVuot, IListBienCapVuot } from './model';

export const transformBienCapVuotDtoToModel = (dto: IBienCapVuotDto): IBienCapVuot => {
  return {
    donVi: dto.donVi,
    quocGia: dto.quocGia,
    dauBienTheoTinh: dto.dauBienTheoTinh,
    dauBienQuocGia: dto.dauBienQuocGia,
    mauBien: dto.mauBien,
    seriChu: dto.seriChu,
    tuSo: dto.tuSo,
    denSo: dto.denSo,
    biensoDaydu: dto.biensoDaydu,
    soMay: dto.soMay,
    soKhung: dto.soKhung,
    chuSoHuu: dto.chuSoHuu,
    ngayDangky: dto.ngayDangky,
    loaiXe: dto.loaiXe,
    nhanHieu: dto.nhanHieu,
  };
};

export const transformListBienCapVuotDtoToModel = (list: IListBienCapVuotDto): IListBienCapVuot => {
  return {
    ...list,
    items: list.items.map<IBienCapVuot>((item) => transformBienCapVuotDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchBienCapVuot) => {
  const paramSearch: ISearchBienCapVuotDto = {
    donVi: dto.donVi,
    quocGia: dto.quocGia,
    dauBienTheoTinh: dto.dauBienTheoTinh,
    dauBienQuocGia: dto.dauBienQuocGia,
    mauBien: dto.mauBien,
    seriChu: dto.seriChu,
    tuSo: dto.tuSo,
    denSo: dto.denSo,
  };
  return paramSearch;
};
