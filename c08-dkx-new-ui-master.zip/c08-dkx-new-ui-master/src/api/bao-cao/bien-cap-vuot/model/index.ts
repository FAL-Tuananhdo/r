import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IBienCapVuot extends BaseModel {
  donVi?: String;
  dauBienTheoTinh?: String;
  mauBien?: String;
  quocGia?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  tuSo?: String;
  denSo?: String;
  biensoDaydu?: String;
  soMay?: String;
  soKhung?: String;
  chuSoHuu?: String;
  ngayDangky?: String;
  loaiXe?: String;
  nhanHieu?: String;
}

export type ISearchBienCapVuot = Pick<
  IBienCapVuot,
  | 'dauBienTheoTinh'
  | 'dauBienQuocGia'
  | 'mauBien'
  | 'tuSo'
  | 'denSo'
  | 'seriChu'
  | 'quocGia'
  | 'donVi'
>;

export type IListBienCapVuot = BasicFetchResult<IBienCapVuot>;
