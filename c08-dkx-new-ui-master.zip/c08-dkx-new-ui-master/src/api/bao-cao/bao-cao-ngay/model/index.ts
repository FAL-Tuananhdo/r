import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoNgay extends BaseModel {
  donViCsgt?: String;
  tuNgay?: String;
  denNgay?: String;
}
