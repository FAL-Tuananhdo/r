import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IBaoCaoNgayDto } from './dto';
import { IBaoCaoNgay } from './model';

enum Api {
  main = '/v1/o-bao-cao/sl-ngay',
  excel = '/v1/o-bao-cao/xe-cu/excel',
}

export const baoCaoNgay = async (params: IBaoCaoNgay) => {
  const res = await localHttp.get<IBaoCaoNgayDto>({ url: Api.main, params: params });
  return res;
};

export const dowloadExcel = async (params: IBaoCaoNgay): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: params,
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', 'baocaongay.xlsx');
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};
