import { localHttpDownload } from '/@/utils/http/axios';
import { IBaoCaoBS } from './model';

enum Api {
  excel = '/v1/o-bao-cao/xe-cu/excel',
}

export const dowloadExcel = async (params: IBaoCaoBS): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: params,
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', 'bao_cao_bien_so.xlsx');
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};
