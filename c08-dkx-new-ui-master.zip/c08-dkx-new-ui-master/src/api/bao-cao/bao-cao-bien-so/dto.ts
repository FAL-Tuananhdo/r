import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoBSDto extends BaseModel {
  donViCsgt?: String;
  quocGia?: String;
  dbTheoTinh?: String;
  dbQuocGia?: String;
  mauBien?: String;
  seriChu?: String;
}
