import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcTheoHienTrang {
  page?: string;
  pageSize?: string;
  donVi?: string;
  diemDangKy?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBcTheoHienTrang extends BaseModel {
  chuyenDi?: number;
  daXuLyBm?: number;
  daXuLyNk?: number;
  maDiemDkText?: string;
  maDonViText?: string;
  tichThuXungQuy?: number;
  trangThaiKhac?: number;
  xeBaoMat?: number;
  xeBiCamCo?: number;
  xeBiDieuTra?: number;
  xeDangLuuHanh: 3;
  xeHetHanLuuHanh?: number;
  xeHetNienHan?: number;
  xeHetThoiHan?: number;
  xeKhongLuuHanh?: number;
  xeNhapKhauTp?: number;
  xeThuHoi?: number;
  xeViPham?: number;
}
