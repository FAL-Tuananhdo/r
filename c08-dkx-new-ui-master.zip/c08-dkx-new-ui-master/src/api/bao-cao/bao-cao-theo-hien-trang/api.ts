import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

import { IBcTheoHienTrang, ISearchBcTheoHienTrang } from './model';

enum Api {
  main = '/v1/o-bao-cao/search-bc-theo-hien-trang',
  excel = '/v1/o-bao-cao/export-excel-bc-theo-hien-trang',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcTheoHienTrang = async (params: ISearchBcTheoHienTrang) => {
  return await localHttp.get<IBcTheoHienTrang>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcTheoHienTrang = async (
  params: ISearchBcTheoHienTrang,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaotheohientrang_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: ISearchBcTheoHienTrang) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, realName, tenDonVi } = userStore.userInfo || {};
  const fetchParam = {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    userName: realName,
    tenDonViUser: tenDonVi,
    tuNgay: useConvertDayjsToString(params['tuNgay']),
    denNgay: useConvertDayjsToString(params['denNgay']),
  };
  if (fetchParam.donVi === SELECT_ALL) delete fetchParam.donVi;
  return fetchParam;
}
