import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcSuDungDlOnline {
  page?: string;
  pageSize?: string;
  donVi?: string;
  diemDangKy?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBcSuDungDlOnline extends BaseModel {
  stt?: number;
  donViCsgt?: string;
  diemDangKy?: string;
  tongCucThue?: number;
  haiQuan?: number;
  dangKiem?: number;
}
