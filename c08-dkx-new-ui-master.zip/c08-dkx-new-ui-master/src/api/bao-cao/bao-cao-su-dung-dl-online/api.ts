import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

import { IBcSuDungDlOnline, ISearchBcSuDungDlOnline } from './model';

enum Api {
  main = '/v1/o-bao-cao/search-bc-su-dung-du-lieu-online',
  excel = '/v1/o-bao-cao/export-excel-bc-su-dung-du-lieu-online',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcSuDungDlOnline = async (params: ISearchBcSuDungDlOnline) => {
  return await localHttp.get<IBcSuDungDlOnline>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcSuDungDlOnline = async (
  params: ISearchBcSuDungDlOnline,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaosudungdulieuonline_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: ISearchBcSuDungDlOnline) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy } = userStore.userInfo || {};
  const fetchParam = {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    tuNgay: useConvertDayjsToString(params.tuNgay),
    denNgay: useConvertDayjsToString(params.denNgay),
  };
  if (fetchParam.donVi === SELECT_ALL) delete fetchParam.donVi;
  return fetchParam;
}
