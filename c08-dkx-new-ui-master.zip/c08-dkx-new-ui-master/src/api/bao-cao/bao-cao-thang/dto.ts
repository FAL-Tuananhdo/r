import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoThangDto {
  page?: string;
  pageSize?: string;
  tuNgay?: String;
  denNgay?: String;
  donVi?: String;
  diemDangKy?: String;
}
export interface IBaoCaoThangRes extends BaseModel {
  thang?: string;

  dangKyMoi?: number;
  dangKyTam?: number;
  dangKyNv?: number;
  sangTen?: number;
  chuyenDi?: number;
  chuyenDen?: number;
  thuHoi?: number;
  caiTao?: number;
  dangKyTraBien?: number;
  traBien?: number;

  tongSoDk?: number;
  tongSoQl?: number;
}
