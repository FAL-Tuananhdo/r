import dayjs from 'dayjs';

import {
  localHttp,
  localHttpDownload,
  reportHttpExport,
  reportHttpSearch,
} from '/@/utils/http/axios';
import { useUserStore, useUserStoreWithOut } from '/@/store/modules/user';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

import { IBaoCaoThangDto, IBaoCaoThangRes } from './dto';
import { IExportReport, ISearchReport } from '../model';

enum Api {
  main = '/v1/o-bao-cao/search-bc-thang',
  excel = '/v1/o-bao-cao/export-excel-bc-thang',
  //new-url/api
  view_report = '/v1/reporting/view-report',
  search = '/v1/reporting/search',
}

const userStore = useUserStore();
const { username } = userStore.getUserInfo;

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcThang = async (params: IBaoCaoThangDto) => {
  return await localHttp.get<IBaoCaoThangRes>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcThang = async (params: IBaoCaoThangDto): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `BcThang_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoThangDto) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, realName, tenDonVi } = userStore.userInfo || {};
  const fetchParam = {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    userName: realName,
    tenDonViUser: tenDonVi,
  };
  if (!params.tuNgay) {
    fetchParam.tuNgay = useConvertDayjsToString(new Date(), 'MM/YYYY');
  }
  if (!params.denNgay) {
    fetchParam.denNgay = useConvertDayjsToString(new Date(), 'MM/YYYY');
  }
  if (fetchParam.donVi === SELECT_ALL) delete fetchParam.donVi;
  return fetchParam;
}

// New Api

export const exportReportBaoCaoThang = async (params: IExportReport) => {
  const res = await reportHttpExport.downloadFileExcel({
    url: Api.view_report,
    params: {
      ...params,
      tuNgay: dayjs(`${params.tuNgay}`).format('M/YYYY'),
      denNgay: dayjs(`${params.denNgay}`).format('M/YYYY'),
      username: username,
    },
  });
  return res;
};

export const searchReportBaoCaoThang = async (params: ISearchReport) => {
  const res = await reportHttpSearch.get({
    url: Api.search,
    params: {
      ...params,
      page: params.page! - 1, // Do page default truyền là 1 còn BE nhận 0 nên config lại
      tuNgay: dayjs(`${params.tuNgay}`).format('M/YYYY'),
      denNgay: dayjs(`${params.denNgay}`).format('M/YYYY'),
      username: username,
    },
  });

  return {
    items: res.result,
    total: res.totalElements,
  };
};
