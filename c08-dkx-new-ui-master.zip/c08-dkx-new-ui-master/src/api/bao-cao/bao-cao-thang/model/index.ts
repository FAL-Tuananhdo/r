import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoThang extends BaseModel {
  tuNgay?: String;
  denNgay?: String;
  donViCsgt?: String;
}
