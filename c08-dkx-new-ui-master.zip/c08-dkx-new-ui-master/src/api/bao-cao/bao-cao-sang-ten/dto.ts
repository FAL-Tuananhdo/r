import { Dayjs } from 'dayjs';

import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoSTDto {
  page?: string;
  pageSize?: string;
  donViCsgt?: string;
  donViChuyenDen?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBaoCaoSTRes extends BaseModel {
  tenDayDu?: string;
  ngayDangKy?: Date;
  chuCu?: string;
  bienSo?: string;
  mauBien?: string;
  donViChuyenDen?: string;
  ngayChuyenDen?: Date;
  chuMoi?: string;
  soMay?: string;
  soKhung?: string;
}
