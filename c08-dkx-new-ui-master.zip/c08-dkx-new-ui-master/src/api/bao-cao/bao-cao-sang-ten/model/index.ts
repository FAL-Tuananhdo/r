import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoST extends BaseModel {
  tuNgay?: String;
  denNgay?: String;
}
