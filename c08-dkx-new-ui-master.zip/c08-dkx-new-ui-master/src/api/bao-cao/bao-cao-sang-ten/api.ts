import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

import { IBaoCaoSTRes, IBaoCaoSTDto } from './dto';

enum Api {
  main = '/v1/o-bao-cao/search-bc-sang-ten-di-chuyen',
  excel = '/v1/o-bao-cao/export-excel-bc-sang-ten-di-chuyen',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcSangTen = async (params: IBaoCaoSTDto) => {
  return await localHttp.get<IBaoCaoSTRes>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcSangTen = async (params: IBaoCaoSTDto): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaosangtendichuyen_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoSTDto) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy } = userStore.userInfo || {};
  const fetchParam = {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    tuNgay: useConvertDayjsToString(params.tuNgay),
    denNgay: useConvertDayjsToString(params.denNgay),
  };
  if (fetchParam.donViCsgt === SELECT_ALL) delete fetchParam.donViCsgt;
  if (fetchParam.donViChuyenDen === SELECT_ALL) delete fetchParam.donViChuyenDen;
  return fetchParam;
}
