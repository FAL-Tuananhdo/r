import { localHttp, reportHttpSearch } from '/@/utils/http/axios';
import {
  IBaoCaoSoSanhBieuDoSearch,
  ILoaiDangKy,
} from '/@/api/bao-cao/bao-cao-theo-bieu-do-hinh-khoi-so-sanh-tuan-thang-quy-cac-tinh/model';
import { useUserStore } from '/@/store/modules/user';

enum Api {
  main = '/v1/o-bao-cao/bc-bieu-do-so-sanh',
  LoaiDangKy = '/v1/bang-tham-so/get',
  //new-url/api
  search = '/v1/reporting/search',
  view_bieu_do = '/v1/reporting/view-bc-bieu-do',
}

const userStore = useUserStore();
const { username } = userStore.getUserInfo;

export const getListLoaiDangKy = async (params: ILoaiDangKy): Promise<ILoaiDangKy> => {
  console.log(params);
  const res = await localHttp.get<ILoaiDangKy>({
    url: Api.LoaiDangKy,
    params: { vungDuLieu: 'TRANG_THAI_DANG_KY' },
  });
  return res;
};

export const getBieuDo = async (params: IBaoCaoSoSanhBieuDoSearch): Promise<any> => {
  const res = await localHttp.get({
    url: Api.main,
    params: params,
  });
  return res;
};

// New Api

export const searchReportBaoCaoBieuDo = async (params: IBaoCaoSoSanhBieuDoSearch) => {
  const res = await reportHttpSearch.get({
    url:
      params.loaiBaoCao === 'Q' && params.tinhThanh === 'ALL' && params.tuNgay !== params.denNgay
        ? Api.view_bieu_do
        : Api.search,
    params: { ...params, username: username },
  });

  return params.loaiBaoCao === 'Q' && params.tinhThanh === 'ALL' && params.tuNgay !== params.denNgay
    ? res
    : res.result;
};
