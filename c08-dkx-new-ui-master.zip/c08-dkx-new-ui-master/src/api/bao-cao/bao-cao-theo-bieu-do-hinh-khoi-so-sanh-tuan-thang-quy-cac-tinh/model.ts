import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoSoSanhBieuDoSearch extends BaseModel {
  loaiBaoCao?: string;
  namBaoCao?: string;
  tinhThanh?: string;
  tuNgay?: string;
  denNgay?: string;
  loaiDangKy?: string;
  diemDangKy?: string;
  reportCode?: string;
}

export interface ILoaiDangKy extends BaseModel {
  vungDuLieu?: string;
}

export interface IRequestSearchDk extends BaseModel {
  id?: number;
  maThamSo?: string;
  dienGiai?: string;
  vungDuLieu?: string;
}
