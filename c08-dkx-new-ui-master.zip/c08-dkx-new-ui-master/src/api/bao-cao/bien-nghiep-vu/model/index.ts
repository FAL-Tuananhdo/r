import { BaseModel } from '/@/api/model/baseModel';

export interface IBienNghiepVu extends BaseModel {
  tuNgay?: String;
  denNgay?: String;
  bienSo?: String;
}
