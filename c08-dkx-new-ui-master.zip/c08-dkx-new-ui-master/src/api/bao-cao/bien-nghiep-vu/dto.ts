import { BaseModel } from '/@/api/model/baseModel';

export interface IBienNghiepVuDto extends BaseModel {
  tuNgay?: String;
  denNgay?: String;
  bienSoTrunc?: String;
}
