import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';

import { IBcSlPhuongTienHetNienHan, ISearchBcSlPhuongTienHetNienHan } from './model';

enum Api {
  main = '/v1/o-bao-cao/search-bc-xe-het-nien-han',
  excel = '/v1/o-bao-cao/export-excel-bc-xe-het-nien-han',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcSlPhuongTienHetNienHan = async (params: ISearchBcSlPhuongTienHetNienHan) => {
  return await localHttp.get<IBcSlPhuongTienHetNienHan>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcSlPhuongTienHetNienHan = async (
  params: ISearchBcSlPhuongTienHetNienHan,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaosoluongphuongtienthongbaobiensoxehetnienhan_${useConvertDayjsToString(
      new Date(),
      'DDMMYYYY',
    )}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: ISearchBcSlPhuongTienHetNienHan) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, realName, tenDonVi } = userStore.userInfo || {};
  return {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    userName: realName,
    tenDonViUser: tenDonVi,
    tuNgay: useConvertDayjsToString(params.tuNgay),
    denNgay: useConvertDayjsToString(params.denNgay),
  };
}
