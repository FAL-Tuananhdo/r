import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcSlPhuongTienHetNienHan {
  page?: string;
  pageSize?: string;
  diemDk?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBcSlPhuongTienHetNienHan extends BaseModel {
  stt?: number;
  donViCsgt?: string;
  diemDangKy?: string;
  tongSoXe?: number;
}
