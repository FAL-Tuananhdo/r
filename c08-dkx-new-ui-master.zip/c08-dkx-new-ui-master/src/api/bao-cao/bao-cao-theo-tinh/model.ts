import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoTheoTinhSearch extends BaseModel {
  page?: string;
  pageSize?: string;
  donVi?: string;
  tuNgay?: Date;
  denNgay?: Date;
}
