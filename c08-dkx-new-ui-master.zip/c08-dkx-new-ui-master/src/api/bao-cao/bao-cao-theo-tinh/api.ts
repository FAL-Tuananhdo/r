import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IBaoCaoTinh } from './dto';
import { IBaoCaoTheoTinhSearch } from './model';
import dayjs from 'dayjs';

enum Api {
  main = '/v1/o-bao-cao/search-bc-theo-tinh',
  excel = '/v1/o-bao-cao/export-excel-bc-theo-tinh',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBaoCaoTheoTinh = async (params: IBaoCaoTheoTinhSearch) => {
  return await localHttp.get<IBaoCaoTinh>({ url: Api.main, params: executeParams(params) });
};

export const dowloadExcel = async (params: IBaoCaoTheoTinhSearch): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', `Baocaotheotinh_${dayjs(new Date()).format('DDMMYYYY')}.xlsx`);
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params) {
  return {
    ...params,
    tuNgay: useConvertDayjsToString(params['tuNgay']),
    denNgay: useConvertDayjsToString(params['denNgay']),
  };
}
