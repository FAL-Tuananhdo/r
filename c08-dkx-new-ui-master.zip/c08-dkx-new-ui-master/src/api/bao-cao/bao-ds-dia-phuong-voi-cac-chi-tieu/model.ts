import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcDsDiaPhuong {
  page?: string;
  pageSize?: string;
  donVi?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
  diemDangKy?: string;
}

export interface IBcDsDiaPhuong extends BaseModel {
  diaDanh?: string;
  dangKyMoiTrucTuyen?: number;
  dangKyNvTrucTuyen?: number;
  dangKyTamTrucTuyen?: number;
  sangTenTrucTuyen?: number;
  chuyenDiTrucTuyen?: number;
  chuyenDenTrucTuyen?: number;
  thuHoiTrucTuyen?: number;
  doiCapTrucTuyen?: number;
  xeTraBienTrucTuyen?: number;
  dkTraBienTrucTuyen?: number;
  dangKyMoiTrucTiep?: number;
  dangKyNvTrucTiep?: number;
  dangKyTamTrucTiep?: number;
  sangTenTrucTiep?: number;
  chuyenDiTrucTiep?: number;
  chuyenDenTrucTiep?: number;
  thuHoiTrucTiep?: number;
  doiCapTrucTiep?: number;
  xeTraBienTrucTiep?: number;
  dkTraBienTrucTiep?: number;
}
