import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';
import { IDiaDiemDk } from '/@/api/quan-ly-he-thong/don-vi-csgt';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

import { IBcDsDiaPhuong, ISearchBcDsDiaPhuong } from './model';

enum Api {
  main = '/v1/o-bao-cao/search-bc-ds-cac-dia-phuong-voi-cac-chi-tieu',
  excel = '/v1/o-bao-cao/export-excel-bc-ds-cac-dia-phuong-voi-cac-chi-tieu',
  getListDiaDiemDk = '/v1/o-bao-cao/get-dia-diem-dk-by-don-vi',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcDsDiaPhuongVoiCacChiTieu = async (params: ISearchBcDsDiaPhuong) => {
  return await localHttp.get<IBcDsDiaPhuong>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcDsDiaPhuongVoiCacChiTieu = async (
  params: ISearchBcDsDiaPhuong,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaodanhsachcacdiaphuongvoicacchitieu_${useConvertDayjsToString(
      new Date(),
      'DDMMYYYY',
    )}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: ISearchBcDsDiaPhuong) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, realName, tenDonVi } = userStore.userInfo || {};
  const fetchParams = {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    userName: realName,
    tenDonViUser: tenDonVi,
    tuNgay: useConvertDayjsToString(params['tuNgay']),
    denNgay: useConvertDayjsToString(params['denNgay']),
  };
  if (fetchParams.donVi === SELECT_ALL) delete fetchParams.donVi;
  return fetchParams;
}

export const getListDiemDangKy = async (params: any): Promise<IDiaDiemDk[]> => {
  return (await localHttp.get<IDiaDiemDk>({ url: Api.getListDiaDiemDk, params: params })) as [];
};
