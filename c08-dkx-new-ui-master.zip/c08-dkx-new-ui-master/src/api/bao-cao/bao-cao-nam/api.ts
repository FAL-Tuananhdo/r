import dayjs from 'dayjs';

import {
  localHttp,
  localHttpDownload,
  reportHttpExport,
  reportHttpSearch,
} from '/@/utils/http/axios';
import { useUserStore, useUserStoreWithOut } from '/@/store/modules/user';

import { IBaoCaoNamDto, IBaoCaoNamRes } from './dto';
import { IExportReport, ISearchReport } from '../model';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

enum Api {
  main = '/v1/o-bao-cao/search-bc-nam',
  excel = '/v1/o-bao-cao/export-excel-bc-nam',
  //new-url/api
  view_report = '/v1/reporting/view-report',
  search = '/v1/reporting/search',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

const userStore = useUserStore();
const { username } = userStore.getUserInfo;

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcNam = async (params: IBaoCaoNamDto) => {
  return await localHttp.get<IBaoCaoNamRes>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcNam = async (params: IBaoCaoNamDto): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `BcNam_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoNamDto) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, tenDonVi, realName } = userStore.userInfo || {};
  const fetchParam = {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    userName: realName,
    tenDonViUser: tenDonVi,
  };
  if (!params.tuNgay) {
    fetchParam.tuNgay = useConvertDayjsToString(new Date(), 'YYYY');
  }
  if (!params.denNgay) {
    fetchParam.denNgay = useConvertDayjsToString(new Date(), 'YYYY');
  }
  if (fetchParam.donVi === SELECT_ALL) delete fetchParam.donVi;
  return fetchParam;
}

// New Api

export const exportReportBaoCaoNam = async (params: IExportReport) => {
  const res = await reportHttpExport.downloadFileExcel({
    url: Api.view_report,
    params: { ...params, username: username },
  });
  return res;
};

export const searchReportBaoCaoNam = async (params: ISearchReport) => {
  const res = await reportHttpSearch.get({
    url: Api.search,
    params: {
      ...params,
      username: username,
      page: params.page! - 1, // Do page default truyền là 1 còn BE nhận 0 nên config lại
    },
  });

  return {
    items: res.result,
    total: res.totalElements,
  };
};
