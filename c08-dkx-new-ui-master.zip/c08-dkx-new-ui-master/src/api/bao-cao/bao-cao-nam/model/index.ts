import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoNam extends BaseModel {
  tuNam?: String;
  denNam?: String;
  donViCsgt?: String;
}
