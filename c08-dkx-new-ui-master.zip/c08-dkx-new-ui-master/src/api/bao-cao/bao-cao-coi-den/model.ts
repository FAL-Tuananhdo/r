import { Dayjs } from 'dayjs';

import { BaseModel } from '/@/api/model/baseModel';

export interface ISearchBcCoiDen {
  page?: string;
  pageSize?: string;
  donVi?: string;
  diemDangKy?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
  mauBien?: string;
  bienSo?: string;
  soKhung?: string;
  soMay?: string;
  capLai?: number;
}

export interface IBcCoiDenRes extends BaseModel {
  maDonVi?: string;
  tenDonVi?: string;
  ngayDangKy?: Date;
  bienSo?: string;
  mauBien?: string;
  mauBienText?: string;
  capLai?: number;
  capLaiText?: string;
  loaiXeUuTien?: string;
  soMay?: string;
  soKhung?: string;
  soSeri?: string;
  giaTriDen?: string;
}
