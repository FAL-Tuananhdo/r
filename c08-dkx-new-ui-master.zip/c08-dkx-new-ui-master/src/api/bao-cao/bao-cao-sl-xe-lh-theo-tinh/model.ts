import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBaoCaoSlXeLhTheoTinh {
  page?: string;
  pageSize?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBaoCaoSlXeLhTheoTinh extends BaseModel {
  tenTinh?: string;
  loaiXe?: string;
  nhanHieu?: string;
  tongSo?: string;
}
