import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IXeCuDto } from './dto';
import { IXeCu } from './model';

enum Api {
  main = '/v1/o-bao-cao/xe-cu',
  excel = '/v1/o-bao-cao/xe-cu/excel',
}

export const baoCaoXeCu = async (params: IXeCu) => {
  const res = await localHttp.get<IXeCuDto>({ url: Api.main, params: params });
  return res;
};
export const dowloadExcel = async (params: IXeCu): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: params,
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', 'xe_nhap_du_lieu_cu.xlsx');
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};
