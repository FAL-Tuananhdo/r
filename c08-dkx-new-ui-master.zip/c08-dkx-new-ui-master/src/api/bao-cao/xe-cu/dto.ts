import { BaseModel } from '/@/api/model/baseModel';

export interface IXeCuDto extends BaseModel {
  donViCsgt?: String;
  tuNgay?: String;
  denNgay?: String;
}
