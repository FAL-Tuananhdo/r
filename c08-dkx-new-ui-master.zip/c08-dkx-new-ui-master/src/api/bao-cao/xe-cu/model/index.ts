import { BaseModel } from '/@/api/model/baseModel';

export interface IXeCu extends BaseModel {
  donViCsgt?: String;
  tuNgay?: String;
  denNgay?: String;
}
