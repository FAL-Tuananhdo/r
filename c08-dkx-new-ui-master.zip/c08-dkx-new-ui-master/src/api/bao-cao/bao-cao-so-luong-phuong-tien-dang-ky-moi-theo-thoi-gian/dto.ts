import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoSlPhuongTienDkTheoThoiGian extends BaseModel {
  donViCsgt?: string;
  diemDangKy?: string;
  tongSoDangKyMoi?: string;
}
