import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoSlPhuongTienDkTheoThoiGianSearch extends BaseModel {
  tuNgay?: string;
  denNgay?: string;
  page?: string;
  pageSize?: string;
  '[tuNgay, denNgay]'?: [Date, Date];
}
