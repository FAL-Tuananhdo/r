import dayjs from 'dayjs';
import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { IBaoCaoSlPhuongTienDkTheoThoiGianSearch } from '/@/api/bao-cao/bao-cao-so-luong-phuong-tien-dang-ky-moi-theo-thoi-gian/model';
import { IBaoCaoSlPhuongTienDkTheoThoiGian } from '/@/api/bao-cao/bao-cao-so-luong-phuong-tien-dang-ky-moi-theo-thoi-gian/dto';
import { useUserStoreWithOut } from '/@/store/modules/user';

enum Api {
  main = '/v1/o-bao-cao/bc-sl-pt-dk-new-theo-tg',
  excel = '/v1/o-bao-cao/bc-sl-pt-dk-new-theo-tg/export/excel',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBaoCaoLsPhuongTienDkTheoThoiGian = async (
  params: IBaoCaoSlPhuongTienDkTheoThoiGianSearch,
) => {
  return await localHttp.get<IBaoCaoSlPhuongTienDkTheoThoiGian>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const dowloadExcel = async (
  params: IBaoCaoSlPhuongTienDkTheoThoiGianSearch,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    'excel_bao_cao_so_luong_phuong_tien_dang_ky_moi_theo_thoi_gian.xlsx',
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoSlPhuongTienDkTheoThoiGianSearch) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy } = userStore.userInfo || {};
  return {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    tuNgay: useConvertDayjsToString(params['tuNgay']),
    denNgay: useConvertDayjsToString(params['denNgay']),
  };
}
