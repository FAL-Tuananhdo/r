import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { IBaoCaoLsPhuongTienTheoSoKhungSoMaySearch } from '/@/api/bao-cao/bao-cao-lich-su-phuong-tien-theo-so-khung-so-may/model';
import { IBaoCaoLsPhuongTienTheoSoKhungSoMay } from '/@/api/bao-cao/bao-cao-lich-su-phuong-tien-theo-so-khung-so-may/dto';
import dayjs from 'dayjs';
import { useUserStoreWithOut } from '/@/store/modules/user';

enum Api {
  main = '/v1/o-bao-cao/bc-sl-pt-theo-so-khung-so-may',
  excel = '/v1/o-bao-cao/bc-sl-pt-theo-so-khung-so-may/export/excel',
}
const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBaoCaoLsPhuongTienTheoSoKhungSoMay = async (
  params: IBaoCaoLsPhuongTienTheoSoKhungSoMaySearch,
) => {
  const res = await localHttp.get<IBaoCaoLsPhuongTienTheoSoKhungSoMay>({
    url: Api.main,
    params: executeParams(params),
  });
  return res;
};

export const dowloadExcelBaoCaoLichSuCuaPhuongTienTheoSoKhungSoMay = async (
  params: IBaoCaoLsPhuongTienTheoSoKhungSoMaySearch,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaolichsucuaphuongtientheosokhungsomay_${useConvertDayjsToString(
      new Date(),
      'DDMMYYYY',
    )}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoLsPhuongTienTheoSoKhungSoMaySearch) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy } = userStore.userInfo || {};
  params.tuNgay = params.tuNgay ? useConvertDayjsToString(params['tuNgay']) : undefined;
  params.denNgay = params.denNgay ? useConvertDayjsToString(params['denNgay']) : undefined;
  delete params['tuNgay, denNgay'];
  return {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
  };
}
