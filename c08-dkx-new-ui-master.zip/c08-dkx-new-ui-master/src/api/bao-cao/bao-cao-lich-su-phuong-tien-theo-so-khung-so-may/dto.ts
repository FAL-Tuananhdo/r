import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoLsPhuongTienTheoSoKhungSoMay extends BaseModel {
  soKhung?: string;
  soMay?: string;
  mauSon?: string;
  ngayLamDangKy?: Date;
  bienSo?: string;
  bienSoCu?: string;
  mauBien?: string;
  loaiXe?: string;
  nhanHieu?: string;
  soLoai?: string;
  dungTichXiLanh?: string;
  trongLuongToanBo?: string;
  tuTrong?: string;
  taiTrongHangHoa?: string;
  trongLuongKeoTheo?: string;
  soChoNgoi?: string;
  soChoDung?: string;
  soChoNam?: string;
  nuocSanXuat?: string;
  namSanXuat?: string;
  nienHanSuDung?: string;
  nguonGocXe?: string;
  loaiDangKy?: string;
  trangThaiHoSo?: string;
  trangThaiXe?: string;
}
