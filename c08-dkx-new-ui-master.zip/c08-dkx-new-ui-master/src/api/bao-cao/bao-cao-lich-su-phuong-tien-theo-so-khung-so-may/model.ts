import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoLsPhuongTienTheoSoKhungSoMaySearch extends BaseModel {
  soKhung?: string;
  soMay?: string;
  tuNgay?: string;
  denNgay?: string;
  page?: string;
  pageSize?: string;
  maDonVi?: string;
}
