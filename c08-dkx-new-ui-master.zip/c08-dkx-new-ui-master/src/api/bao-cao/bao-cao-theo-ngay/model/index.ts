import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoNgay extends BaseModel {
  tuNam?: String;
  denNam?: String;
  donViCsgt?: String;
}
