import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';
import { SELECT_ALL } from '/@/views/bao-cao/const/configApi';

import { IBaoCaoNgayDto, IBaoCaoNgayRes } from './dto';

enum Api {
  main = '/v1/o-bao-cao/search-bc-ngay',
  excel = '/v1/o-bao-cao/export-excel-bc-ngay',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcNgay = async (params: IBaoCaoNgayDto) => {
  return await localHttp.get<IBaoCaoNgayRes>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const downloadExcelBcNgay = async (params: IBaoCaoNgayDto): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `BcNgay_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoNgayDto) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, realName, tenDonVi } = userStore.userInfo || {};
  const fetchParam = {
    ...params,
    donViUser: maDonVi,
    userName: realName,
    tenDonViUser: tenDonVi,
    maDiemDangKyUser: maDiemDangKy,
  };
  fetchParam.tuNgay = useConvertDayjsToString(!params.tuNgay ? new Date() : params.tuNgay);
  fetchParam.denNgay = useConvertDayjsToString(!params.denNgay ? new Date() : params.denNgay);
  if (fetchParam.donVi === SELECT_ALL) delete fetchParam.donVi;
  return fetchParam;
}
