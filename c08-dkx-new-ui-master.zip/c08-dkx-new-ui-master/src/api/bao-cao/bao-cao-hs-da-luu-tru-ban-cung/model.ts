import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcHsDaLuuTruBanCung {
  page?: string;
  pageSize?: string;
  donVi?: string;
  diemDangKy?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBcHsDaLuuTruBanCung extends BaseModel {
  stt?: number;
  donViCsgt?: string;
  diemDangKy?: string;
  coDl?: number;
  koCoDl?: number;
}
