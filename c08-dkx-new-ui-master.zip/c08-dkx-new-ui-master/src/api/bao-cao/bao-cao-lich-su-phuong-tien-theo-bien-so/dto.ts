import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoLsPhuongTienTheoBienSoXe extends BaseModel {
  bienSoXe?: string;
  bienSoCu?: string;
  mauBien?: string;
  soKhung?: string;
  soMay?: string;
  mauSon?: string;
  loaiXe?: string;
  nhanHieu?: string;
  ngayLamDangKy?: Date;
  chuSoHuu?: string;
  trangThaiDk?: string;
  trangThaiHoSo?: string;
  trangThaiXe?: string;
  donViCsgt?: string;
  diemDk?: string;
}
