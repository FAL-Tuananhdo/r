import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoLsPhuongTienTheoBienSoXeSearch extends BaseModel {
  bienSo?: string;
  tuNgay?: string;
  denNgay?: string;
  page?: string;
  pageSize?: string;
  maDonVi?: string;
}
