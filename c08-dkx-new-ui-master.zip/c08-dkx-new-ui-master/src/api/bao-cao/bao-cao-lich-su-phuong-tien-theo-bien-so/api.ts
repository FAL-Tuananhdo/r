import dayjs from 'dayjs';
import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { IBaoCaoLsPhuongTienTheoBienSoXeSearch } from '/@/api/bao-cao/bao-cao-lich-su-phuong-tien-theo-bien-so/model';
import { IBaoCaoLsPhuongTienTheoBienSoXe } from '/@/api/bao-cao/bao-cao-lich-su-phuong-tien-theo-bien-so/dto';
import { useUserStoreWithOut } from '/@/store/modules/user';

enum Api {
  main = '/v1/o-bao-cao/bc-ls-pt-theo-bien-so-xe',
  excel = '/v1/o-bao-cao/bc-ls-pt-theo-bien-so-xe/export/excel',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBaoCaoLsPhuongTienTheoBienSoXe = async (
  params: IBaoCaoLsPhuongTienTheoBienSoXeSearch,
) => {
  console.log(params);
  return await localHttp.get<IBaoCaoLsPhuongTienTheoBienSoXe>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const dowloadExcel = async (
  params: IBaoCaoLsPhuongTienTheoBienSoXeSearch,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaolichsuphuongtientheobiensoxe_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: IBaoCaoLsPhuongTienTheoBienSoXeSearch) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy } = userStore.userInfo || {};
  params.tuNgay = params.tuNgay ? useConvertDayjsToString(params['tuNgay']) : undefined;
  params.denNgay = params.denNgay ? useConvertDayjsToString(params['denNgay']) : undefined;
  return {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    // tuNgay: useConvertDayjsToString(fromToDate[0]),
    // denNgay: useConvertDayjsToString(fromToDate[1]),
  };
}
