import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcSlThongTinSaiLech {
  page?: string;
  pageSize?: string;
  donVi?: string;
  diemDangKy?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

//TODO: đợi response BE
export interface IBcSlThongTinSaiLech extends BaseModel {
  stt?: number;
  donViCsgt?: string;
  diemDangKy?: string;
  tongCucThue?: number;
  haiQuan?: number;
  dangKiem?: number;
}
