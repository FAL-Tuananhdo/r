import dayjs from 'dayjs';

import { reportHttpExport, reportHttpSearch } from '/@/utils/http/axios';
import { DATE_FORMAT_DDMMYYYY } from '/@/utils/dateUtil';
import { useUserStore } from '/@/store/modules/user';

import { IExportReport, ISearchReport } from './model';

enum Api {
  view_report = '/v1/reporting/view-report',
  search = '/v1/reporting/search',
}

const userStore = useUserStore();
const { username } = userStore.getUserInfo;

export const exportReport = async (params: IExportReport) => {
  const res = await reportHttpExport.downloadFileExcel({
    url: Api.view_report,
    params: {
      ...params,
      tuNgay:
        typeof params.tuNgay === 'undefined'
          ? ''
          : dayjs(`${params.tuNgay}`).format(DATE_FORMAT_DDMMYYYY),
      denNgay:
        typeof params.denNgay === 'undefined'
          ? ''
          : dayjs(`${params.denNgay}`).format(DATE_FORMAT_DDMMYYYY),
    },
  });
  return res;
};

export const searchtReport = async (params: ISearchReport) => {
  const res = await reportHttpSearch.get({
    url: Api.search,
    params: {
      ...params,
      username: username,
      page: params.page! - 1, // Do page default truyền là 1 còn BE nhận 0 nên config lại
      tuNgay:
        typeof params.tuNgay === 'undefined'
          ? ''
          : dayjs(`${params.tuNgay}`).format(DATE_FORMAT_DDMMYYYY),
      denNgay:
        typeof params.denNgay === 'undefined'
          ? ''
          : dayjs(`${params.denNgay}`).format(DATE_FORMAT_DDMMYYYY),
    },
  });

  return {
    items: res.result,
    total: res.totalElements,
  };
};
