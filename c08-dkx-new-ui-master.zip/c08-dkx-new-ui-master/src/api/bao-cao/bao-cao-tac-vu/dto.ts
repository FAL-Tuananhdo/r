import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoTacVu extends BaseModel {
  maDonVi?: string;
  tenDayDu?: string;
  dkMoi?: string;
  dkTam?: string;
  dkNghiepVu?: string;
  sangTenTrongTinh?: string;
  sangTenNgoaiTinh?: string;
  chuyenDen?: string;
  thuHoi?: string;
  doiCap?: string;
  dkTraBien?: string;
  xeTraBien?: string;
  xeKoLuuHanhViLyDoKhac?: string;
  xeHetHanLuuHanh?: string;
  xeDangCamCoTheChap?: string;
  xeHetThoiHanDk?: string;
  xeHetNienHanSd?: string;
  xeDangBiDieuTra?: string;
  xeThuHoi?: string;
  xeViPham?: string;
  xeBaoMat?: string;
  xeDangLuuHanh?: string;
  trangThaiKhac?: string;
  xeNhapKhauTraiPhep?: string;
  tichThuXungQuyNn?: string;
  chuyenDi?: string;
  daXlXeNkTraiPhep?: string;
  daXlXeBaoMat?: string;
}
