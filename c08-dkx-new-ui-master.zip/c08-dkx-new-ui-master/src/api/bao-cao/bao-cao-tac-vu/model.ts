import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoTacVuSearch extends BaseModel {
  donViCsgt?: string;
  tuNgay?: Date;
  denNgay?: Date;
  diemDangKy?: string;
  trangThai?: string;
  trangThaiHoSo?: string;
}
