import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IBaoCaoTacVu } from './dto';
import { IBaoCaoTacVuSearch } from './model';
import dayjs from 'dayjs';

enum Api {
  main = '/v1/o-bao-cao/search-bc-theo-tinh',
  excel = '/v1/o-bao-cao/export-excel-bc-theo-tinh',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBaoCaoTacVu = async (params: IBaoCaoTacVuSearch) => {
  return await localHttp.get<IBaoCaoTacVu>({ url: Api.main, params: executeParams(params) });
};

export const dowloadExcel = async (params: IBaoCaoTacVuSearch): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', `Baocaotacvu_${dayjs(new Date()).format('DDMMYYYY')}.xlsx`);
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params) {
  return {
    ...params,
    tuNgay: useConvertDayjsToString(params['tuNgay']),
    denNgay: useConvertDayjsToString(params['denNgay']),
  };
}
