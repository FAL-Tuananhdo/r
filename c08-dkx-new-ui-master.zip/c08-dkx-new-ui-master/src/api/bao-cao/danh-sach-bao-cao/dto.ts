import { BaseModel } from '/@/api/model/baseModel';

export interface IDanhSachBaoCaoDto extends BaseModel {
  donViCsgt?: String;
  tuNgay?: String;
  denNgay?: String;
  diemDangKy?: String;
  noi_dung: String;
  ten_file: string;
}
