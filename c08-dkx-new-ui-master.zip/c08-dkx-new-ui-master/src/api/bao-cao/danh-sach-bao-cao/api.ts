import { localHttp } from '/@/utils/http/axios';

import { IDanhSachBaoCaoDto } from './dto';
import { IDanhSachBaoCao } from './model';

enum Api {
  mau05tt37 = '/v1/o-bao-cao/mau-05-tt-37',
  tKeNguonGoc = '/v1/o-bao-cao/Tke-nguon-goc-oto-theo-loai-dky',
  mau08tt15 = '/v1/o-bao-cao/mau-08-tt-15',
  xeHetNienHan = '/v1/o-bao-cao/xe-het-nien-han',
  capPhuHieu = '/v1/o-bao-cao/cap-phu-hieu-ks',
  tamNhapTaiXuatdlh = '/v1/o-bao-cao/tam-nhap-tai-xuat-dlh',
  tamNhapTaiXuathhlh = '/v1/o-bao-cao/tam-nhap-tai-xuat-hh-lh',

  mau12tt10 = '/v1/o-bao-cao/mau-12-tt-10',
  tkSoLuongDk = '/v1/o-bao-cao/tk-sl-dangky',
  soDkXe = '/v1/o-bao-cao/so-dk-xe',
}

export const mau05TT37 = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.mau05tt37, params: params });
  return res;
};
export const tKeNguonGoc = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.tKeNguonGoc, params: params });
  return res;
};
export const mau08TT15 = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.mau08tt15, params: params });
  return res;
};
export const xeHetNienHan = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.xeHetNienHan, params: params });
  return res;
};
export const capPhuHieu = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.capPhuHieu, params: params });
  return res;
};
export const tamNhapTaiXuatdlh = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({
    url: Api.tamNhapTaiXuatdlh,
    params: params,
  });
  return res;
};
export const tamNhapTaiXuathhlh = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({
    url: Api.tamNhapTaiXuathhlh,
    params: params,
  });
  return res;
};
export const mau12tt10 = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.mau12tt10, params: params });
  return res;
};
export const tkSoLuongDk = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.tkSoLuongDk, params: params });
  return res;
};
export const soDkXe = async (params: IDanhSachBaoCao) => {
  const res = await localHttp.get<IDanhSachBaoCaoDto>({ url: Api.soDkXe, params: params });
  return res;
};
