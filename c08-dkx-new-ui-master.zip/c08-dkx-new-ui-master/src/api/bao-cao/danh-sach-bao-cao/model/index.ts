import { BaseModel } from '/@/api/model/baseModel';

export interface IDanhSachBaoCao extends BaseModel {
  donViCsgt?: String;
  tuNgay?: String;
  denNgay?: String;
  diemDangKy?: String;
  noi_dung: String;
  ten_file: string;
}
