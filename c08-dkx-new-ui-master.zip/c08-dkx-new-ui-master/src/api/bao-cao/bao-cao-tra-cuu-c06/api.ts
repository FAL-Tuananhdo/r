import dayjs from 'dayjs';

import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { useUserStoreWithOut } from '/@/store/modules/user';

import { IBc06Res, ISearchBcC06 } from './model';

enum Api {
  tracuu_main = '/v1/o-bao-cao/bc-c06-search-tra-cuu',
  tracuu_excel = '/v1/o-bao-cao/bc-c06-export-tra-cuu',
  thongke_main = '/v1/o-bao-cao/bc-c06-search-thong-ke',
  thongke_excel = '/v1/o-bao-cao/bc-c06-export-thong-ke',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBcC06 = async (params: ISearchBcC06, isTraCuu = true) => {
  return await localHttp.get<IBc06Res>({
    url: isTraCuu ? Api.tracuu_main : Api.thongke_main,
    params: executeParams(params),
  });
};

export const downloadExcelBcC06 = async (
  params: ISearchBcC06,
  isTraCuu = true,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: isTraCuu ? Api.tracuu_excel : Api.thongke_excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute(
    'download',
    `Baocaotracuuc06_${useConvertDayjsToString(new Date(), 'DDMMYYYY')}.xlsx`,
  );
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params: ISearchBcC06) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy, realName, tenDonVi } = userStore.userInfo || {};
  return {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    userName: realName,
    tenDonViUser: tenDonVi,
    tuNgay: useConvertDayjsToString(params.tuNgay),
    denNgay: useConvertDayjsToString(params.denNgay),
  };
}
