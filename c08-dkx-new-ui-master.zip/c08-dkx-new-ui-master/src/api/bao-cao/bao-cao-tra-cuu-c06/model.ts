import { BaseModel } from '/@/api/model/baseModel';
import { Dayjs } from 'dayjs';

export interface ISearchBcC06 {
  page?: string;
  pageSize?: string;
  hanhDong?: string;
  chucNang?: string;
  soDinhDanh?: string;
  donVi?: string;
  tuNgay?: Dayjs;
  denNgay?: Dayjs;
}

export interface IBc06Res extends BaseModel {
  // tra cuu
  thoiGianTraCuu?: string;
  canBoTraCuu?: string;
  cmnd?: string;
  soDinhDanh?: string;
  chucNang?: string;
  hanhDong?: string;

  // thong ke
  tenChiTieu?: string;
  dangKyMoi?: number;
  dangKyNghiepVu?: number;
  dangKyTam?: number;
  sangTenTrongTinh?: number;
  dkXeChuyenDen?: number;
  sangTenNgoaiTinh?: number;
}
