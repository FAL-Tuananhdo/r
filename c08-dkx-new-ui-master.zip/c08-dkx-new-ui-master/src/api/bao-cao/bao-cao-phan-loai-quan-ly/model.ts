import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoPhanLoaiQuanLySearch extends BaseModel {
  page?: string;
  pageSize?: string;
  donVi?: string;
  tuNgay?: Date;
  denNgay?: Date;
  diemDk?: string;
  '[tuNgay, denNgay]'?: [Date, Date];
}
