import { BaseModel } from '/@/api/model/baseModel';

export interface IBaoCaoPhanLoaiQuanLy extends BaseModel {
  tenPhanLoai?: string;
  xeKoLuuHanhViLyDoKhac?: string;
  xeHetHanLuuHanh?: string;
  xeDangCamCoTheChap?: string;
  xeHetThoiHanDk?: string;
  xeHetNienHanSd?: string;
  xeDangBiDieuTra?: string;
  xeViPham?: string;
  xeBaoMat?: string;
  xeDangLuuHanh?: string;
  trangThaiKhac?: string;
  xeNhapKhauTraiPhep?: string;
  tichThuXungQuyNn?: string;
  chuyenDi?: string;
  daXlXeBaoMat?: string;
}
