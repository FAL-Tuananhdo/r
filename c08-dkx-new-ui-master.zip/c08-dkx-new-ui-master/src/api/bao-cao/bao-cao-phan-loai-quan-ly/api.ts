import dayjs from 'dayjs';
import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { IBaoCaoPhanLoaiQuanLySearch } from '/@/api/bao-cao/bao-cao-phan-loai-quan-ly/model';
import { IBaoCaoPhanLoaiQuanLy } from '/@/api/bao-cao/bao-cao-phan-loai-quan-ly/dto';
import { useUserStoreWithOut } from '/@/store/modules/user';

enum Api {
  main = '/v1/o-bao-cao/search-bc-pl-quan-ly',
  excel = '/v1/o-bao-cao/export-excel-bc-pl-quan-ly',
}

const DATE_FORMAT = {
  DDMMYYYY: 'DD/MM/YYYY',
};

const DATE_EXCEL = {
  DDMMYYYY: 'DDMMYYYY',
};

function useConvertDayjsToString(date, format = DATE_FORMAT.DDMMYYYY) {
  return dayjs(date).format(format);
}
function useConverDateExcel(date, format = DATE_EXCEL.DDMMYYYY) {
  return dayjs(date).format(format);
}

export const getBaoCaoPhanLoaiQuanLy = async (params: IBaoCaoPhanLoaiQuanLySearch) => {
  return await localHttp.get<IBaoCaoPhanLoaiQuanLy>({
    url: Api.main,
    params: executeParams(params),
  });
};

export const dowloadExcel = async (params: IBaoCaoPhanLoaiQuanLySearch): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.excel,
    params: executeParams(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', `Baocaophanloaiquanly_${useConverDateExcel(Date())}.xlsx`);
  document.body.appendChild(fileLink);
  fileLink.click();
  return res;
};

function executeParams(params) {
  const userStore = useUserStoreWithOut();
  const { maDonVi, maDiemDangKy } = userStore.userInfo || {};
  return {
    ...params,
    donViUser: maDonVi,
    maDiemDangKyUser: maDiemDangKy,
    tuNgay: useConvertDayjsToString(params['tuNgay']),
    denNgay: useConvertDayjsToString(params['denNgay']),
  };
}
