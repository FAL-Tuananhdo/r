import { localHttp } from '/@/utils/http/axios';

import { ICheckCbDto, IDangKyOtoDto } from './dto';
import { IDangKyOto, IKtCapbienDK } from './model';
import { IInDangKyDto } from '../in-giay-hen/dto';
import { IInDangKy } from '../in-giay-hen';

enum Api {
  maMauBien = '/v1/bang-tham-so/get?vungDuLieu=MA_MAU_BIEN',
  getList = '/v1/dau-bien-theo-tinh/getList',
  ktCapBien = '/v1/o-dang-ky/dang-ky-moi/kt-cap-bien',
  bienDinhDanh = '/v1/o-dang-ky/chung/bien-dinh-danh',
  ktCapBienDauGia = '/v1/o-dang-ky/dang-ky-moi/kt-cap-bien-dau-gia',
  ktCapBienOld = '/v1/o-dang-ky/chung/kt-cap-bien',
  capBien = '/v1/o-dang-ky/dang-ky-moi/cap-bien',
  capBienDknvm = '/v1/o-dang-ky/dang-ky-moi/cap-bien-dknv-moi',
  capBienDauGia = '/v1/o-dang-ky/dang-ky-moi/cap-bien-dau-gia',
  capBienDauGiaDDK = '/v1/o-dang-ky/ho-so/doi-cap-cap-bien-dg',
  capBienDinhDanh = '/v1/o-dang-ky/dang-ky-moi/cap-bien-dinh-danh',
  capBienDinhDanhNv = '/v1/o-dang-ky/dang-ky-moi/cap-bien-dinh-danh-nv',
  macDinh = '/v1/o-dang-ky/chung/mac-dinh',
  diaChi = '/v1/o-dang-ky/chung/dia-chi',
  doicapLayLaiBien = '/v1/o-dang-ky/ho-so/doi-cap-lay-lai-bien',
  doicapCapBien = '/v1/o-dang-ky/ho-so/doi-cap-cap-bien',
  traBien = '/v1/o-dang-ky/ho-so/tra-bien',
  chuyenDonVi = '/v1/o-dang-ky/ho-so/chuyen-don-vi',
  stttLayLaiBien = '/v1/o-dang-ky/ho-so/sttt-lay-lai-bien',
  rutSTNT = '/v1/o-dang-ky/ho-so/rut-stnt',
  rutDCNT = '/v1/o-dang-ky/ho-so/rut-dcnt',
  stttCapBien = '/v1/o-dang-ky/ho-so/sttt-cap-bien',
  stttCapBienDd = '/v1/o-dang-ky/ho-so/sttt-cap-bien-dinh-danh',
  dktttthCapBien = '/v1/o-dang-ky/ho-so/dkt-tt-th-cap-bien',
  chuyenDenCapBien = '/v1/o-dang-ky/ho-so/chuyen-den-cap-bien',
  saiHeBienCapBien = '/v1/o-dang-ky/ho-so/sai-he-bien-cap-bien',
  thuHoiDangKy = '/v1/o-dang-ky/ho-so/thu-hoi',
  inCnThuHoi = '/v1/o-dang-ky/ho-so/in-cn-thu-hoi',
  inCnThuHoiNt = '/v1/o-dang-ky/ho-so/in-cn-thu-hoi-nt',
  inPhieuTcxm = '/v1/o-dang-ky/ho-so/in-phieu-tcxm',
  ktCapBienTamTH = '/v1/o-dang-ky/dang-ky-tam/kt-cap-bien-thu-hoi',
  capBienTamTH = '/v1/o-dang-ky/dang-ky-tam/cap-bien-tam-thu-hoi',
  luuInDkTamXTH = '/v1/o-dang-ky/ho-so/luu-tt-dktam-xth',
  ktCapBienTam = '/v1/o-dang-ky/dang-ky-tam/kt-cap-bien',
  capBienTam = '/v1/o-dang-ky/dang-ky-tam/cap-bien',
  capBienTamLai = '/v1/o-dang-ky/dang-ky-tam/cap-bien-lai',
  ktNhapBienTam = '/v1/o-dang-ky/dang-ky-tam/kt-nhap-bien',
  nhapBienTam = '/v1/o-dang-ky/dang-ky-tam/nhap-bien',
}

export const capBienDkOto = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBien, params: params });
  return res;
};

export const capBienDkNVMOto = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBienDknvm, params: params });
  return res;
};

export const capBienDauGia = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBienDauGia, params: params });
  return res;
};

export const capBienDauGiaDDK = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.capBienDauGiaDDK, params: params });
  return res;
};

export const capBienDinhDanh = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBienDinhDanh, params: params });
  return res;
};

export const capBienDinhDanhNv = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBienDinhDanhNv, params: params });
  return res;
};

export const capBienDkTam = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBienTam, params: params });
  return res;
};

export const capBienDkTamLai = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.capBienTamLai, params: params });
  return res;
};

export const nhapBienDkTam = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.post<IDangKyOtoDto>({ url: Api.nhapBienTam, params: params });
  return res;
};

export const stttLayLaiBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.stttLayLaiBien, params: params });
  return res;
};

export const rutSTNT = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.rutSTNT, params: params });
  return res;
};

export const rutDCNT = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.rutDCNT, params: params });
  return res;
};

export const doicapLayLaiBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.doicapLayLaiBien, params: params });
  return res;
};

export const thuHoiDangKy = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.thuHoiDangKy, params: params });
  return res;
};

export const stttCapBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.stttCapBien, params: params });
  return res;
};

export const stttCapBienDD = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.stttCapBienDd, params: params });
  return res;
};

export const dktttthCapBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.dktttthCapBien, params: params });
  return res;
};

export const chuyenDenCapBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.chuyenDenCapBien, params: params });
  return res;
};

export const saiHeBienCapBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.saiHeBienCapBien, params: params });
  return res;
};

export const doicapCapBien = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.doicapCapBien, params: params });
  return res;
};

export const traBienLD = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.traBien, params: params });
  console.log('res', res);
  return res;
};

export const chuyenDonViQl = async (params: IDangKyOto) => {
  console.log(params);
  const res = await localHttp.put<IDangKyOtoDto>({ url: Api.chuyenDonVi, params: params });
  console.log('res', res);
  return res;
};

export const inCnThuHoi = async (id: String): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({ url: `${Api.inCnThuHoi}/${id}` });
  return res;
};

export const inCnThuHoiNt = async (id: String): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({ url: `${Api.inCnThuHoiNt}/${id}` });
  return res;
};
export const inPhieuTcxm = async (maGiaoDich: String, canBo: String): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({
    url: `${Api.inPhieuTcxm}/${maGiaoDich}/${canBo}`,
  });
  return res;
};

export const ktCapBien = async (params: IKtCapbienDK) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<ICheckCbDto>({ url: Api.ktCapBien, params: params });
  return res;
};

export const bienDinhDanh = async (soDinhDanh: string) => {
  console.log('bienDinhDanh: ', soDinhDanh);
  const res = await localHttp.get<ICheckCbDto>({ url: `${Api.bienDinhDanh}/${soDinhDanh}` });
  return res;
};
export const ktCapBienDauGia = async (params: IKtCapbienDK) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<ICheckCbDto>({ url: Api.ktCapBienDauGia, params: params });
  return res;
};

export const ktNhapBienTam = async (params: IKtCapbienDK) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<ICheckCbDto>({ url: Api.ktNhapBienTam, params: params });
  return res;
};

export const ktCapBienTam = async (params: IKtCapbienDK) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<ICheckCbDto>({ url: Api.ktCapBienTam, params: params });
  return res;
};

export const capBienTamTH = async (params: any) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<any>({ url: Api.capBienTamTH, params: params });
  return res;
};

export const luuInDkTamXTH = async (params: any) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.put<any>({ url: Api.luuInDkTamXTH, params: params });
  return res;
};

export const ktCapBienTamTH = async (params: any) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<ICheckCbDto>({ url: Api.ktCapBienTamTH, params: params });
  return res;
};

export const ktCapBienOld = async (params: IKtCapbienDK) => {
  const res = await localHttp.post<ICheckCbDto>({ url: Api.ktCapBienOld, params: params });
  return res;
};

export const getMacDinh = async (params: String) => {
  const res = await localHttp.get<ICheckCbDto>({ url: `${Api.macDinh}/${params}` });
  return res;
};

export const getDiaChi = async (params: String) => {
  const res = await localHttp.get<ICheckCbDto>({ url: `${Api.diaChi}/${params}` });
  return res;
};
