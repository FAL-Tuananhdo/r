import { BaseDto } from '../../dto/baseDto';

export interface IDangKyOtoDto extends BaseDto {
  bienSo?: String;
  message?: String;
  diemdkId?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  mauBien?: String;
  canboDangKyID?: String;
  bienSoNuocNgoai?: String;
  laKhuKtdb?: String;
  donViCsgtId?: String;
  maNopThueTruocBa?: String;
  maHsDvc?: String;
  traCuuC06?: String;
  ten?: String;
  soCmnd?: String;
  diadanhHanhchinhId?: String;
  diaChi?: String;
  soDienThoai?: String;
  hkDayDu?: String;
  diaChiHienTai?: String;
  soMay?: String;
  soKhung?: String;
  nhanhieuLoaixeId?: String;
  soLoai?: String;
  maLoaiXeId?: String;
  id?: String;
  status?: String;
}

export interface ICheckCbDto extends BaseDto {
  status?: String;
  message?: String[];
  tinh: string;
  quan: string;
  xa: string;
  diaChi: string;
  diemdkId: String;
  maDonVi: String;
  phanloaiQuanly: String;
  loaiGiayTo: String;
  soKhuKtdb: String;
}
