import { BaseModel } from '/@/api/model/baseModel';

export interface IDangKyOto extends BaseModel {
  id?: String;
  oId?: String;
  duLieuCu?: String;
  diemdkId?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  mauBien?: String;
  canboDangKyID?: String;
  bienSoNuocNgoai?: String;
  laKhuKtdb?: String;
  donViCsgtId?: String;
  maNopThueTruocBa?: String;
  maHsDvc?: String;
  traCuuC06?: String;
  ten?: String;
  soCmnd?: String;
  diadanhHanhchinhId?: String;
  bienSoTrunc?: String;

  diaChi?: String;
  soDienThoai?: String;
  hkDayDu?: String;
  diaChiHienTai?: String;
  soMay?: String;
  soKhung?: String;
  nhanhieuLoaixeId?: String;
  soLoai?: String;
  maLoaiXeId?: String;

  ///
  cshMaQuocGia?: String;
  tinhThanhPho?: String;
  quanHuyen?: String;
  phuongXa?: String;
  loaiXe?: String;
  bienSoQuocGiaId?: String;
  maQuocGia?: String;
}

export interface IKtCapbienDK extends BaseModel {
  soMay?: String;
  soKhung?: String;
  diemdkId?: String;
  maDiemDk?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  mauBien?: String;
  maLoaiXe?: String;
  maQuocGia?: String;
  oId?: String;
  bienSoId?: String;
}
