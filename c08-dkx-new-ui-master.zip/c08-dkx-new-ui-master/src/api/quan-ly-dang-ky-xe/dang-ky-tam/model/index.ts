import { BaseModel } from '/@/api/model/baseModel';

export interface IDangKyTam extends BaseModel {
  loaiDangKy?: String;
  chuSoHuu?: String;
  quocGiaId?: String;
  tinhThanhPho?: String;
  quanHuyen?: String;
  phuongXa?: String;
  diaChi?: String;
  soDienThoai?: number;

  loaiXe?: String;
  nhanHieu?: String;
  soLoai?: String;
  soMay?: String;
  soKhung?: String;

  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChuId?: String;
  seriChu?: String;
  mauBien?: String;
  bienSoQuocGiaId?: String;
  diemdkId?: String;
  donViCsgtId?: String;
  maLoaiXeId?: String;
}
