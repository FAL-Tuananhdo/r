import { BaseDto } from '../../dto/baseDto';

export interface IDangKyTamDto extends BaseDto {
  bienSo?: String;
  loaiDangKy?: String;
  chuSoHuu?: String;
  quocGiaId?: String;
  tinhThanhPho?: String;
  quanHuyen?: String;
  phuongXa?: String;
  diaChi?: String;
  soDienThoai?: number;

  loaiXe?: String;
  nhanHieu?: String;
  soLoai?: String;
  soMay?: String;
  soKhung?: String;

  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChuId?: String;
  seriChu?: String;
  mauBien?: String;
  bienSoQuocGiaId?: String;
  diemdkId?: String;
  donViCsgtId?: String;
  maLoaiXeId?: String;
  status?: String;
}
