import { localHttp } from '/@/utils/http/axios';

import { IDangKyTamDto } from './dto';
import { IDangKyTam } from './model';


enum Api {
  maMauBien = '/v1/bang-tham-so/get?vungDuLieu=MA_MAU_BIEN',
  getList = '/v1/dau-bien-theo-tinh/getList',
  capBienTam = '/v1/o-dang-ky/dang-ky-tam/cap-bien',
}

export const capBienTam = async (params: IDangKyTam) => {
  const res = await localHttp.post<IDangKyTamDto>({ url: Api.capBienTam, params: params });
  return res;
};
