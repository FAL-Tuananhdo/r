import { localHttp } from '/@/utils/http/axios';

import { IInDangKyDto } from './dto';
import { IInDangKy, IInDangKyGcn } from './model';

enum Api {
  inGiayHen = '/v1/o-dang-ky/chung/in-giay-hen',
  inToKhai = '/v1/o-dang-ky/chung/in-to-khai',
  inToKhaiDkt = '/v1/o-dang-ky/chung/in-to-khai-dkt',
  inGiayHenN = '/v1/o-dang-ky/chung/in-giay-hen-n',
  inDkTamXTHTT58 = '/v1/o-dang-ky/chung/in-dkt-xth-tt58',
  inDangKy = '/v1/o-dang-ky/ho-so/in-dang-ky',
  inDanhSach = '/v1/o-dang-ky/ho-so/in-ds',
  inPHieuStdc = '/v1/o-dang-ky/ho-so/in-phieu-stdc',
}

export const inGiayHen = async (params: IInDangKy) => {
  const res = await localHttp.get<IInDangKyDto>({ url: Api.inGiayHen, params: params });
  return res;
};

export const inDkTamXTHTT58 = async (id, dcIn) => {
  const res = await localHttp.get<IInDangKyDto>({ url: `${Api.inDkTamXTHTT58}/${id}/${dcIn}` });
  return res;
};

export const getByIdInGiayHen = async (id: String): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({ url: `${Api.inGiayHen}/${id}` });
  return res;
};

export const getInToKhai = async (id: String, cb: String, params: any): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({
    url: `${Api.inToKhai}/${id}/${cb}`,
    params: params,
  });
  return res;
};

export const getInToKhaiDktam = async (id: String, cb: String, params: any): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({
    url: `${Api.inToKhaiDkt}/${id}/${cb}`,
    params: params,
  });
  return res;
};

export const inPHieuStdc = async (id: String, params: IInDangKyGcn): Promise<IInDangKy> => {
  const res = await localHttp.put<IInDangKyDto>({
    url: `${Api.inPHieuStdc}/${id}`,
    params: params,
  });
  return res;
};

export const getInDangKyId = async (id: String, params: IInDangKyGcn): Promise<IInDangKy> => {
  const res = await localHttp.put<IInDangKyDto>({ url: `${Api.inDangKy}/${id}`, params: params });
  return res;
};

export const getInDanhsach = async (
  inDc: String,
  canBoId: String,
  params: any,
): Promise<IInDangKy> => {
  console.log('in param: ', params);
  const res = await localHttp.put<IInDangKyDto>({
    url: `${Api.inDanhSach}/${inDc}/${canBoId}`,
    params: params,
  });
  return res;
};

export const getByIdInGiayHenN = async (id: String): Promise<IInDangKy> => {
  const res = await localHttp.get<IInDangKyDto>({ url: `${Api.inGiayHenN}/${id}` });
  return res;
};
