import { BaseDto } from '../../dto/baseDto';

export interface IInDangKyDto extends BaseDto {
  id: String;
  noi_dung: String;
  ten_file: String;
}
