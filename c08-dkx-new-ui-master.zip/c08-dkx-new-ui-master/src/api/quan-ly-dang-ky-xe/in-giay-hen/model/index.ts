import { BaseModel } from '/@/api/model/baseModel';

export interface IInDangKy extends BaseModel {
  id: String;
  noi_dung: String;
  ten_file: String;
}

export interface IInDangKyGcn extends BaseModel {
  id: String;
  canBoId: String;
  bienSoTrunc: String;
  soKhung: String;
  soMay: String;
  mauBien: String;
  loaiIn: String;
  dcIn: String;
}
