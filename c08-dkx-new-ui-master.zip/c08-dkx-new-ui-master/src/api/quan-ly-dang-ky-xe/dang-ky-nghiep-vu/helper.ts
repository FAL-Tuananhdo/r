import {
  IDangKyTamDto,
} from './dto';
import { IDangKyTam } from './model';

export const transformDangKyTamDtoToModel = (dto: IDangKyTamDto): IDangKyTam => {
  return {
    loaiDangKy: dto.loaiDangKy,
    chuSoHuu: dto.chuSoHuu,
    quocGiaId: dto.quocGiaId,
    tinhThanhPho: dto.tinhThanhPho,
    quanHuyen: dto.quanHuyen,
    phuongXa: dto.phuongXa,
    diaChi: dto.diaChi,
    soDienThoai: dto.soDienThoai,

    loaiXe: dto.loaiXe,
    nhanHieu: dto.nhanHieu,
    soLoai: dto.soLoai,
    soMay: dto.soMay,
    soKhung: dto.soKhung,

    dauBienTheoTinh: dto.dauBienTheoTinh,
    dauBienQuocGia: dto.dauBienQuocGia,
    seriChuId: dto.seriChuId,
    mauBien: dto.mauBien,
  };
};

export const transformDangKyTamModelToDto = (model: IDangKyTam): IDangKyTamDto => {
  return {
    loaiDangKy: model.loaiDangKy,
    chuSoHuu: model.chuSoHuu,
    quocGiaId: model.quocGiaId,
    tinhThanhPho: model.tinhThanhPho,
    quanHuyen: model.quanHuyen,
    phuongXa: model.phuongXa,
    diaChi: model.diaChi,
    soDienThoai: model.soDienThoai,

    loaiXe: model.loaiXe,
    nhanHieu: model.nhanHieu,
    soLoai: model.soLoai,
    soMay: model.soMay,
    soKhung: model.soKhung,

    dauBienTheoTinh: model.dauBienTheoTinh,
    dauBienQuocGia: model.dauBienQuocGia,
    seriChuId: model.seriChuId,
    mauBien: model.mauBien,
  };
};
