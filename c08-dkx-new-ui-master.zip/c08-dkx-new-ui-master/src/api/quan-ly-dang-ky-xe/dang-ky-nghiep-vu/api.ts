import { localHttp } from '/@/utils/http/axios';

import { IDangKyTamDto } from './dto';
import {
  IDangKyTam,
  IUpdateParamsDongSoHuu,
} from './model';

enum Api {
  maMauBien = '/v1/bang-tham-so/get?vungDuLieu=MA_MAU_BIEN',
  getList = '/v1/dau-bien-theo-tinh/getList',
  main = '/v1/dau-bien-theo-tinh',
}
export const createDKNV = async (params: IDangKyTam) => {
  const res = await localHttp.post<IDangKyTamDto>({ url: Api.main, params: params });
  return res;
};

export const createDongSoHuu = async (params: IDangKyTam) => {
  const res = await localHttp.post<IDangKyTamDto>({ url: Api.main, params: params });
  return res;
};

export const updateDongSoHuu = (params: IUpdateParamsDongSoHuu, id: any) => {
  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};
export const deleteDongSoHuu = (id?: String) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};
