import { BaseDto } from '../../dto/baseDto';

export interface IDangKyTamDto extends BaseDto {
  loaiDangKy?: String;
  chuSoHuu?: String;
  quocGiaId?: String;
  tinhThanhPho?: String;
  quanHuyen?: String;
  phuongXa?: String;
  diaChi?: String;
  soDienThoai?: String;
  message?: String;

  loaiXe?: String;
  nhanHieu?: String;
  soLoai?: String;
  soMay?: String;
  soKhung?: String;

  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChuId?: String;
  mauBien?: String;
}
