import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IDangKyTam extends BaseModel {
  loaiDangKy?: String;
  chuSoHuu?: String;
  dongSoHuu?: String;
  quocGiaId?: String;
  tinhThanhPho?: String;
  quanHuyen?: String;
  phuongXa?: String;
  diaChi?: String;
  soDienThoai?: String;
  message?: String;

  loaiXe?: String;
  nhanHieu?: String;
  soLoai?: String;
  soMay?: String;
  soKhung?: String;

  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChuId?: String;
  mauBien?: String;
}

export interface IUpdateParamsDongSoHuu extends IDangKyTam {
  id: String;
}

export type IListDongSoHuu = BasicFetchResult<IDangKyTam>;
