import { BaseModel } from '/@/api/model/baseModel';

export interface ITimKiemXe extends BaseModel {
  canBoDangKy?: String;
  donViCsgtId?: String;
  mauBien?: String;
  bienSo?: String;
  soMay?: String;
  soKhung?: String;
}
