import { localHttp } from '/@/utils/http/axios';

import { ITimKiemXeDto } from './dto';
import { ITimKiemXe } from './model';

enum Api {
  timKiemXe = '/v1/o-dang-ky/ho-so/ho-so-nghiep-vu',
  tracuuBs = '/v1/o-dang-ky/ho-so/tra-cuu-bien-so',
  timBienDauGia = '/v1/o-dang-ky/ho-so/bien-dau-gia',
  dsLichSu = '/v1/o-dang-ky/ho-so/ds-lich-su',
  traToKhai = '/v1/dich-vu-cong/to-khai',
  lptbTheoTk = '/v1/dich-vu-cong/lptb-theo-tk',
  dkhqTheoTk = '/v1/dich-vu-cong/dkhq-theo-tk',
  lptbTheoDk = '/v1/dich-vu-cong/lptb-theo-dk',
  dkhqTheoDk = '/v1/dich-vu-cong/dkhq-theo-dk',
  capNhatTtToKhai = '/v1/dich-vu-cong/cap-nhat-tt-to-khai',
  tracuuXacminhNhanh = '/v1/o-tien-ich/tra-cuu-xac-minh-nhanh',
}

export const timKiemXe = async (params: ITimKiemXe) => {
  console.log('tkx: ', params);
  const res = await localHttp.get<ITimKiemXeDto>({ url: Api.timKiemXe, params: params });
  return res;
};

export const tracuuBs = async (params: ITimKiemXe) => {
  console.log('tkx: ', params);
  const res = await localHttp.get<ITimKiemXeDto>({ url: Api.tracuuBs, params: params });
  return res;
};

export const tracuuXacminhNhanh = async (params: any) => {
  console.log('tracuuxmnhanh: ', params);
  const res = await localHttp.get<any>({ url: Api.tracuuXacminhNhanh, params: params });
  return res;
};

export const timBienDauGia = async (params: ITimKiemXe) => {
  console.log('tkx: ', params);
  console.log('link: ', Api.timBienDauGia);
  const res = await localHttp.get<ITimKiemXeDto>({ url: Api.timBienDauGia, params: params });
  return res;
};

export const lptbTheoTk = async (id: String) => {
  const res = await localHttp.get<any>({ url: `${Api.lptbTheoTk}/${id}` });
  return res;
};

export const dkhqTheoTk = async (id: String) => {
  const res = await localHttp.get<any>({ url: `${Api.dkhqTheoTk}/${id}` });
  return res;
};

export const lptbTheoDk = async (id: String) => {
  const res = await localHttp.get<any>({ url: `${Api.lptbTheoDk}/${id}` });
  return res;
};

export const dkhqTheoDk = async (id: String) => {
  const res = await localHttp.get<any>({ url: `${Api.dkhqTheoDk}/${id}` });
  return res;
};
export const traToKhai = async (params: any) => {
  const res = await localHttp.get<any>({ url: Api.traToKhai, params: params });
  return res;
};

export const capNhatTtToKhai = async (params: any) => {
  const res = await localHttp.put<any>({ url: `${Api.capNhatTtToKhai}`, params: params });
  return res;
};

export const dsLichSu = async (params: any) => {
  const res = await localHttp.get<ITimKiemXeDto>({ url: Api.dsLichSu, params: params });
  return res;
};
