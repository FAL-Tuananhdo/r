import { localHttp } from '/@/utils/http/axios';

import {
  IDshDto,
  IDshInputDto,
  IHieuChinhDto,
  IHoanChinhHso,
  IKtHoanChinhHso,
  INhapSeriDto,
} from './dto';
import {
  IDshModel,
  IHieuChinh,
  IHoanChinhHsoModel,
  IKtHCHSMessage,
  ILovBangThamso,
  ILovCanBo,
  ILovDauBienQuocGia,
  ILovDauBienTheoTinh,
  ILovDiaDanh,
  ILovDonVi,
  ILovLoaiXe,
  ILovMaMauBien,
  ILovNhanHieu,
  ILovNoiCap,
  ILovPhanloaiQuanly,
  ILovQuocGia,
  ILovSeriChu,
  IMaMauSon,
  INhapSeriModel,
} from './model';
import { IBangThamSo } from '../../quan-ly-he-thong/bang-tham-so';
import { IDangKyOto } from '../dang-ky-oto';

enum Api {
  getHieuChinh = '/v1/o-dang-ky/ho-so',
  traLptb = '/v1/dich-vu-cong/lptb',
  traDangKiem = '/v1/dich-vu-cong/dang-kiem',
  traHaiQuan = '/v1/dich-vu-cong/hai-quan',
  themNguonGoc = '/v1/dich-vu-cong/nguon-goc',
  putHieuChinh = '/v1/o-dang-ky/ho-so',
  dongSoHuu = '/v1/o-dang-ky/chung/dong-so-huu',
  dinhKem = '/v1/o-dang-ky/chung/hoso-dinhkem',
  getDSH = '/v1/o-dang-ky/chung/ds-dong-so-huu',
  getDinhKem = '/v1/o-dang-ky/chung/ds-dinh-kem',
  ktHoanChinhHso = '/v1/o-dang-ky/ho-so/kt-hoan-chinh-hoso',
  hoanChinhHso = '/v1/o-dang-ky/ho-so/hoan-chinh-hoso',
  nhapSeri = '/v1/o-dang-ky/ho-so/nhap-seri',
  ktxe = '/v1/o-dang-ky/chung/kt-xe',
  hieuchinhSkSmLx = '/v1/o-dang-ky/ho-so/hieu-chinh-sk-sm-lx',

  lovPhanloaiQuanly = '/v1/o-dang-ky/chung/phan-loai-quan-ly',
  lovLoaiGiayTo = '/v1/o-dang-ky/chung/loai-giay-to',
  lovInTheoMau = '/v1/o-dang-ky/chung/in-theo-mau',
  lovKhoa = '/v1/o-dang-ky/chung/khoa',
  lovTrangthaiDangky = '/v1/o-dang-ky/chung/trang-thai-dang-ky',
  lovTrangthaiDvc = '/v1/o-dang-ky/chung/trang-thai-dvc',
  lovCapDoDvc = '/v1/o-dang-ky/chung/cap-do-dvc',
  lovLyDoThuHoi = '/v1/o-dang-ky/chung/ly-do-thu-hoi',
  lovLyDoDoiCap = '/v1/o-dang-ky/chung/ly-do-doi-cap',
  lovLyDoTraBien = '/v1/o-dang-ky/chung/ly-do-tra-bien',
  lovLoaiCaiTao = '/v1/o-dang-ky/chung/loai-cai-tao',
  lovLoaiDkt = '/v1/o-dang-ky/chung/loai-dkt',
  lovNoiCap = '/v1/o-dang-ky/chung/noi-cap',
  lovLoaiNhienLieu = '/v1/o-dang-ky/chung/loai-nhien-lieu',
  lovNhanHieu = '/v1/o-dang-ky/chung/nhan-hieu',
  lovLoaiXe = '/v1/o-dang-ky/chung/loai-xe',
  layMaMau = '/v1/o-dang-ky/chung/ma-mau-son',
  maMauSonD = '/v1/o-dang-ky/chung/ma-mau-son-d',
  lovQuocGia = '/v1/o-dang-ky/chung/quoc-gia',
  lovMaMauBien = '/v1/o-dang-ky/chung/ma-mau-bien',
  lovDauBienQuocGia = '/v1/o-dang-ky/chung/dau-bien-quoc-gia',
  lovDauBienTheoTinh = '/v1/o-dang-ky/chung/dau-bien-theo-tinh',
  lovCanBo = '/v1/o-dang-ky/chung/can-bo',
  danhSachTinNhan = '/v1/o-dang-ky/chung/danh-sach-tin-nhan',
  dinhKemTuC08 = '/v1/o-dang-ky/chung/dinh-kem-tu-c08',
  lovDonVi = '/v1/o-dang-ky/chung/don-vi',
  lovKhuKtdb = '/v1/o-dang-ky/chung/khu-ktdb',
  lovSeriChu = '/v1/o-dang-ky/chung/seri-chu',
  lovNuocSx = '/v1/o-dang-ky/chung/nuoc-sx',
  lovNguonGoc = '/v1/o-dang-ky/chung/nguon-goc',
  lovChuyenQuyenSoHuu = '/v1/o-dang-ky/chung/chuyen-quyen-so-huu',
  lovNguonGocTk = '/v1/o-dang-ky/chung/nguon-goc-tk',
  lovTinh = '/v1/o-dang-ky/chung/tinh',
  lovQuan = '/v1/o-dang-ky/chung/quan',
  lovXa = '/v1/o-dang-ky/chung/xa',
  traCsh = '/v1/o-dang-ky/chung/tra-csh',
  traC06 = '/v1/o-dang-ky/chung/tra-c06',
  traBienDauGia = '/v1/o-dang-ky/chung/tra-bien-dau-gia',
}

export const ktXe = async (params: any) => {
  console.log('kt cap bien: ', params);
  const res = await localHttp.post<any>({ url: Api.ktxe, params: params });
  return res;
};

export const getHieuChinhBoSung = async (id: String): Promise<IHieuChinh> => {
  const res = await localHttp.get<IHieuChinhDto>({ url: `${Api.getHieuChinh}/${id}` });
  return res;
};

export const traLptb = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({ url: `${Api.traLptb}`, params: params });
  return res;
};

export const themLptb = async (params: any): Promise<any> => {
  const res = await localHttp.post<any>({ url: `${Api.traLptb}`, params: params });
  return res;
};

export const themNguonGoc = async (params: any): Promise<any> => {
  const res = await localHttp.post<any>({ url: `${Api.themNguonGoc}`, params: params });
  return res;
};

export const traCsh = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({ url: `${Api.traCsh}`, params: params });
  return res;
};

export const traC06 = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({ url: `${Api.traC06}`, params: params });
  return res;
};
export const traBienDauGia = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({ url: `${Api.traBienDauGia}`, params: params });
  return res;
};

export const traDangKiem = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({ url: `${Api.traDangKiem}`, params: params });
  return res;
};

export const traHaiQuan = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({ url: `${Api.traHaiQuan}`, params: params });
  return res;
};

export const ktHoanChinhHso = async (id: String): Promise<IKtHCHSMessage> => {
  const res = await localHttp.get<IKtHoanChinhHso>({ url: `${Api.ktHoanChinhHso}/${id}` });
  return res;
};

export const postThemDongSoHuu = async (params: IDshInputDto): Promise<IDshModel> => {
  const res = await localHttp.post<IDshModel>({ url: `${Api.dongSoHuu}`, params: params });
  return res;
};

export const postHosoDinhkem = async (params: any): Promise<any> => {
  const res = await localHttp.post<any>({ url: `${Api.dinhKem}`, params: params });
  return res;
};

themLptb;

export const putCapnhatDongSoHuu = async (params: IDshInputDto, id: String): Promise<IDshModel> => {
  const res = await localHttp.put<IDshModel>({
    url: `${Api.dongSoHuu}/${id}`,
    params: params,
  });
  return res;
};

export const deleteXoaDongSoHuu = async (id: String): Promise<IDshModel> => {
  const res = await localHttp.delete<IDshModel>({
    url: `${Api.dongSoHuu}/${id}`,
  });
  return res;
};

export const deleteHosoDinhkem = async (id: String): Promise<IDshModel> => {
  const res = await localHttp.delete<any>({
    url: `${Api.dinhKem}/${id}`,
  });
  return res;
};

export const dsDongSoHuu = async (params: IDshDto): Promise<IDshModel> => {
  const res = await localHttp.get<IDshModel>({
    url: `${Api.getDSH}`,
    params: params,
  });
  return res;
};

export const dsDinhKem = async (params: any): Promise<any> => {
  const res = await localHttp.get<any>({
    url: `${Api.getDinhKem}`,
    params: params,
  });
  return res;
};

export const hoanChinhHso = async (
  params: IHoanChinhHso,
  id: String,
): Promise<IHoanChinhHsoModel> => {
  const res = await localHttp.put<IHoanChinhHsoModel>({
    url: `${Api.hoanChinhHso}/${id}`,
    params: params,
  });
  return res;
};

export const nhapSeri = async (params: INhapSeriDto, id: String): Promise<INhapSeriModel> => {
  const res = await localHttp.put<INhapSeriModel>({
    url: `${Api.nhapSeri}/${id}`,
    params: params,
  });
  return res;
};

export const hieuchinhSkSmLx = async (params: any): Promise<any> => {
  const res = await localHttp.put<any>({
    url: `${Api.hieuchinhSkSmLx}`,
    params: params,
  });
  return res;
};

export const putHieuChinhBoSung = (params: IHieuChinhDto, id: String): Promise<IHieuChinhDto> => {
  const res = localHttp.put<IHieuChinhDto>({ url: `${Api.putHieuChinh}/${id}`, params: params });
  return res;
};

export const getLOVTinh = async (): Promise<ILovDiaDanh> => {
  const res = await localHttp.get<ILovDiaDanh>({ url: `${Api.lovTinh}` });
  return res;
};

export const getLOVKhuKtdb = async (maDonVi: any): Promise<any> => {
  const res = await localHttp.get<any>({
    url: `${Api.lovKhuKtdb}/${maDonVi.maDonVi}`,
  });
  return res;
};

export const getLOVQuan = async (maTinh: any): Promise<ILovDiaDanh> => {
  const res = await localHttp.get<ILovDiaDanh>({ url: `${Api.lovQuan}/${maTinh.maTinh}` });
  return res;
};

export const getLOVXa = async (maQuan: any): Promise<ILovDiaDanh> => {
  const res = await localHttp.get<ILovDiaDanh>({ url: `${Api.lovXa}/${maQuan.maQuan}` });
  return res;
};

export const getLOVPhanloaiQuanly = async (): Promise<ILovPhanloaiQuanly> => {
  const res = await localHttp.get<ILovPhanloaiQuanly>({ url: `${Api.lovPhanloaiQuanly}` });
  return res;
};

export const getLOVLoaiGiayTo = async (laToChuc: any): Promise<ILovBangThamso> => {
  console.log('loai giay to', laToChuc);
  const res = await localHttp.get<ILovBangThamso>({
    url: `${Api.lovLoaiGiayTo}/${laToChuc.laToChuc}`,
  });
  return res;
};

export const getLOVKhoa = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovKhoa}` });
  return res;
};

export const getLOVTrangthaiDangky = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovTrangthaiDangky}` });
  return res;
};

export const getLOVTrangthaiDvc = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovTrangthaiDvc}` });
  return res;
};

export const getLOVCapDo = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovCapDoDvc}` });
  return res;
};

export const getLOVLyDoThuHoi = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovLyDoThuHoi}` });
  return res;
};
export const getLOVLyDoTraBien = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovLyDoTraBien}` });
  return res;
};

export const getLOVLyDoDoiCap = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovLyDoDoiCap}` });
  return res;
};

export const getLOVLoaiCaiTao = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovLoaiCaiTao}` });
  return res;
};

export const getLOVLoaiDKT = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovLoaiDkt}` });
  return res;
};

export const getLOVInTheoMau = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovInTheoMau}` });
  return res;
};

export const getLOVLoaiNhienLieu = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovLoaiNhienLieu}` });
  return res;
};

export const getLOVNhanHieu = async (): Promise<ILovNhanHieu> => {
  const res = await localHttp.get<ILovNhanHieu>({ url: `${Api.lovNhanHieu}` });
  return res;
};

export const getLOVLoaiXe = async (): Promise<ILovLoaiXe> => {
  const res = await localHttp.get<ILovLoaiXe>({ url: `${Api.lovLoaiXe}` });
  return res;
};

export const getLOVNoiCap = async (params: any): Promise<ILovNoiCap> => {
  if (params.loai) {
    const res = await localHttp.get<ILovNoiCap>({ url: `${Api.lovNoiCap}/${params.loai}` });
    return res;
  } else {
    const noiCap: ILovNoiCap = {};
    return noiCap;
  }
};

export const getMauSon = async (maMau: String): Promise<IMaMauSon> => {
  try {
    const res = await localHttp.get<IMaMauSon>({ url: `${Api.layMaMau}/${maMau}` });
    return res;
  } catch (exception) {
    return {};
  }
};

export const getLOVMauSonD = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.maMauSonD}` });
  return res;
};

export const getLOVMaMauBien = async (): Promise<ILovMaMauBien> => {
  const res = await localHttp.get<ILovMaMauBien>({ url: `${Api.lovMaMauBien}` });
  return res;
};

export const getLOVQuocGia = async (): Promise<ILovQuocGia> => {
  const res = await localHttp.get<ILovQuocGia>({ url: `${Api.lovQuocGia}` });
  return res;
};

export const getLOVDonVi = async (): Promise<ILovDonVi> => {
  const res = await localHttp.get<ILovDonVi>({ url: `${Api.lovDonVi}` });
  return res;
};

export const getLOVDauBienQuocGia = async (maQuocGia: any): Promise<ILovDauBienQuocGia> => {
  let mqg = 'VN';
  if (maQuocGia.maQuocGia) {
    mqg = maQuocGia.maQuocGia === null ? 'VN' : maQuocGia.maQuocGia;
  }
  const res = await localHttp.get<ILovDauBienQuocGia>({
    url: `${Api.lovDauBienQuocGia}/${mqg}`,
  });
  return res;
};

export const getLOVDauBienTheoTinh = async (maDonVi: any): Promise<ILovDauBienTheoTinh> => {
  const res = await localHttp.get<ILovDauBienTheoTinh>({
    url: `${Api.lovDauBienTheoTinh}/${maDonVi.maDonVi}`,
  });
  return res;
};

export const getLOVCanBo = async (maDonVi: any): Promise<ILovCanBo> => {
  const res = await localHttp.get<ILovCanBo>({
    url: `${Api.lovCanBo}/${maDonVi.maDonVi}`,
  });
  return res;
};

export const getDanhSachTinNhan = async (maDonVi: any): Promise<any> => {
  console.log('danh sahc tin nhan ma dv: ', maDonVi.maDonVi);
  const res = await localHttp.get<any>({
    url: `${Api.danhSachTinNhan}/${maDonVi.maDonVi}`,
  });
  return res;
};

export const getDinhKemTuC08 = async (): Promise<any> => {
  const res = await localHttp.get<any>({
    url: `${Api.dinhKemTuC08}`,
  });
  return res;
};

export const getLOVSeriChu = async (maQuocGia: any): Promise<ILovSeriChu> => {
  const trongNuoc = maQuocGia.maQuocGia === 'VN' ? '1' : '2';
  const res = await localHttp.get<ILovSeriChu>({
    url: `${Api.lovSeriChu}/${trongNuoc}/0`,
  });
  return res;
};

export const getLOVSeriChuT = async (maQuocGia: any): Promise<ILovSeriChu> => {
  const trongNuoc = maQuocGia.maQuocGia === 'VN' ? '1' : '2';
  const res = await localHttp.get<ILovSeriChu>({
    url: `${Api.lovSeriChu}/${trongNuoc}/1`,
  });
  return res;
};

export const getLOVNuocSx = async (): Promise<ILovQuocGia> => {
  const res = await localHttp.get<ILovQuocGia>({ url: `${Api.lovNuocSx}` });
  return res;
};

export const getLOVNguonGoc = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovNguonGoc}` });
  return res;
};

export const getLOVChuyenQuyenSH = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovChuyenQuyenSoHuu}` });
  return res;
};

export const getLOVNguonGocTk = async (): Promise<ILovBangThamso> => {
  const res = await localHttp.get<ILovBangThamso>({ url: `${Api.lovNguonGocTk}` });
  return res;
};
