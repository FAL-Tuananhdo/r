import { BaseModel } from '/@/api/model/baseModel';

export interface IHieuChinh extends BaseModel {
  id?: String;
  otoId?: String;
  chuSoHuuId?: String;
  phanloaiQuanlyId?: String;
  dauBienTheoTinh?: String;
  biensoQuocgiaId?: String;
  biensoDaydu?: String;
  biensoCu?: String;
  canboDangkyId?: String;
  ngayDangky?: String;
  trangthaiDangky?: String;
  hieuLucDk?: String;
  ngayTradangky?: String;
  ngayDkLandau?: String;
  hieulucDenngay?: String;
  soChungnhandk?: String;
  trangthaiHoso?: String;
  lydoThuhoiDoicap?: String;
  hinhthucCaitao?: String;
  ghiChu?: String;
  noiTamnhap?: String;
  ngayTamnhap?: String;
  noiTaiXuat?: String;
  ngayTaiXuat?: String;
  duocphepDitu?: String;
  ngayDi?: String;
  duocphepDiden?: String;
  ngayDen?: String;
  nguoiTao?: String;
  ngayTao?: String;
  nguoiSua?: String;
  ngaySua?: String;
  daTaiXuat?: String;
  capPheDuyet?: String;
  ngayPheDuyet?: String;
  mucDichSuDung?: String;
  noiDungPheDuyet?: String;
  khuktdbId?: String;
  dauBienQuocGia?: String;
  otoBienSoid?: String;
  lanhDaoDuyet?: String;
  doiTruongduyet?: String;
  khoa?: String;
  seriChu?: String;
  mauBien?: String;
  phamViHoatDong?: String;
  bienSoNuocNgoai?: String;
  loaiDangKyTam?: String;
  coQuancapPhep?: String;
  ngayCapPhep?: String;
  lanhDaoId?: String;
  doiTruongId?: String;
  lyDoThuHoi?: String;
  soPhuHieuKs?: String;
  ngayCapPhuHieu?: String;
  phuHieuHlTuNgay?: String;
  phuHieuHlDenNgay?: String;
  donViChuyenden?: String;
  laKhuKtdb?: String;
  soLanDoiCap?: String;
  duLieuCu?: String;
  maGiaoDich?: String;
  matBien?: String;
  matDangKy?: String;
  biensoTam?: String;
  cancu?: String;
  bienHeThongCu?: String;
  ngayCaiTao?: String;
  ngayThuHoi?: String;
  ngayDiChuyen?: String;
  duocphepdiden1?: String;
  lyDoTraBien?: String;
  loaiStnt?: String;
  diemdkId?: String;
  donViCsgtId?: String;
  maDonVi?: String;
  bienSoTrunc?: String;
  ngayTuDongHoanThanh?: String;
  nhapDuLieuCu?: String;
  loiDulieu?: String;
  maNopThueTruocBa?: String;
  soLanTraBien?: String;
  hsoLuuTai?: String;
  qrCode?: String;
  muaBanQuaNhieuNguoi?: String;
  cocoidenUutien?: String;
  lamSach?: String;
  trangthaiLsach?: String;
  maHsDvc?: String;
  traCuuC06?: String;
  soMay?: String;
  soKhung?: String;
  nhanhieuLoaixeId?: String;
  maNhanHieu?: String;
  soLoai?: String;
  namSx?: String;
  nienHanSuDung?: String;
  dungTich?: String;
  nuocSx?: String;
  congSuat?: String;
  chieuDaicoSo?: String;
  trongLuongtoanBo?: String;
  tutrong?: String;
  taitrongHangHoa?: String;
  soChoNgoi?: String;
  soChoDung?: String;
  soChoNam?: String;
  trongLuongKeotheo?: String;
  kichThuocBaoDai?: String;
  kichThuocBaoRong?: String;
  kichThuocBaoCao?: String;
  kichThuocThungDai?: String;
  kichThuocThungRong?: String;
  kichThuocThungCao?: String;
  soTruc?: String;
  ktLopTruocSau?: String;
  vetXeBanhTruoc?: String;
  vetXeBanhSau?: String;
  kieuDongCo?: String;
  congThucBanhXe?: String;
  congsuatLonnhatDongco?: String;
  anhOto?: String;
  trangthai?: String;
  noiBao?: String;
  ngayBao?: String;
  noiDung?: String;
  thoiGianXuLy?: String;
  hinhThucXuLy?: String;
  mauXe?: String;
  nguonGoc?: String;
  soChungTu?: String;
  ngaycapChungtu?: String;
  coquancapchungtu?: String;
  loaiNhienlieu?: String;
  maLoaiXeId?: String;
  maLoaiXe?: String;
  tenChungtu?: String;
  ten?: String;
  diadanhHanhchinhId?: String;
  maDiaDanhHanhChinh?: String;
  diaChi?: String;
  loaiGiayto?: String;
  idSo?: String;
  idNgayCap?: String;
  idNoiCap?: String;
  soDienThoai?: String;
  quocgiaId?: String;
  cshGhiChu?: String;
  maSoThue?: String;
  taiKhoan?: String;
  nganHang?: String;
  chsDuLieuCu?: String;
  cshMaGiaoDich?: String;
  email?: String;
  soCmnd?: String;
  diaChiHienTai?: String;
  hkDayDu?: String;
  oid?: String;
  oghiChu?: String;
  odiaChi?: String;
  oduLieuCu?: String;
  omaGiaoDich?: String;
  odonViCsgtId?: String;
  oMaDonVi?: String;
  otrangthaiDangky?: String;
  status?: String;
}

export interface ILovPhanloaiQuanly extends BaseModel {
  id?: String;
  tenPhanLoai?: String;
  maPhanLoai?: String;
  nhomQlyId?: String;
  loai?: String;
  loaiDoiTuong?: String;
}

export interface ILovBangThamso extends BaseModel {
  id?: String;
  maThamso?: String;
  dienGiai?: String;
}

export interface ILovNhanHieu extends BaseModel {
  maNhanHieu?: String;
  tenNhanHieu?: String;
  kiemSoatSoKhung?: String;
  kiemSoatSoMay?: String;
}

export interface ILovLoaiXe extends BaseModel {
  maLoaiPhuongTien?: String;
  tenLoaiPhuongTien?: String;
  maPhuongTienCapTren?: String;
  loai?: String;
  inTheoMau?: String;
  nhapLieuTheoMau?: String;
}

export interface ILovDiaDanh extends BaseModel {
  ma?: String;
  tenHieu?: String;
}

export interface ILovNoiCap extends BaseModel {
  id?: String;
  ten?: String;
  loai?: String;
}

export interface IMaMauSon extends BaseModel {
  id?: String;
  tenMau?: String;
  maMau?: String;
}

export interface ILovQuocGia extends BaseModel {
  maQuocGia?: String;
  tenQuocGia?: String;
}

export interface ILovMaMauBien extends BaseModel {
  maMau?: String;
  tenMau?: String;
}

export interface ILovDauBienQuocGia extends BaseModel {
  id?: String;
  dauBienQuocGia?: String;
}

export interface ILovDauBienTheoTinh extends BaseModel {
  dauBienTheoTinh?: String;
}

export interface ILovCanBo extends BaseModel {
  username?: String;
  ten?: String;
}
export interface ILovDonVi extends BaseModel {
  ma?: String;
  tenVietTat?: String;
}

export interface ILovSeriChu extends BaseModel {
  id?: String;
  seriChu?: String;
}

export interface IKtHCHSMessage extends BaseModel {
  errMessage?: String;
}

export interface IHoanChinhHsoModel extends BaseModel {
  id?: String;
  isCu?: String;
}

export interface IDshModel extends BaseModel {
  id?: String;
  chuSoHuuId?: String;
  ten?: String;
  tinhThanhPho?: String;
  quanHuyen?: String;
  phuongXa?: String;
  diadanhHanhchinhId?: String;
  maDiaDanhHanhChinh?: String;
  diaChi?: String;
  loaiGiayto?: String;
  idSo?: String;
  idNgayCap?: String;
  idNoiCap?: String;
  soDienThoai?: String;
  quocgiaId?: String;
  cshMaQuocGia?: String;
  cshGhiChu?: String;
  cshNguoiTao?: String;
  cshNgayTao?: String;
  cshNguoiSua?: String;
  cshNgaySua?: String;

  maSoThue?: String;
  taiKhoan?: String;
  nganHang?: String;
  chsDuLieuCu?: String;
  cshMaGiaoDich?: String;
  email?: String;
  soCmnd?: String;
  diaChiHienTai?: String;
  hkDayDu?: String;
}

export interface INhapSeriModel extends BaseModel {
  id?: String;
}
