import { BaseDto } from '../../dto/baseDto';

export interface ITimKiemHoSoDto extends BaseDto {
  ngayDangKy?: String;
  ngayCapNhat?: String;
  chuSoHuu?: String;
  bienSo?: String;
  mauBien?: String;
  soMay?: String;
  soKhung?: String;
  loaiDangKy?: String;
  trangThai?: String;
  duyetTraBien?: String;
  khoa?: String;
  status?: String;
  items?: ITimKiemHoSoDto[];
}

