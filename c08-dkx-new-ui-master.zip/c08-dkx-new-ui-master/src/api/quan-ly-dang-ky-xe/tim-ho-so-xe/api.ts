import { localHttp } from '/@/utils/http/axios';

import { ITimKiemHoSoDto } from './dto';
import { IHoanThanhDsModel, ITimKiemHoSo } from './model';

enum Api {
  timKiemHoSoXe = '/v1/o-dang-ky/ho-so/danh-sach-xe',
  hoanThanhDs = '/v1/o-dang-ky/ho-so/hoan-thanh-ds',
  duyetTraBien = '/v1/o-dang-ky/ho-so/duyet-tra-bien',
  khongduyetTraBien = '/v1/o-dang-ky/ho-so/khong-duyet-tra-bien',
  moKhoa = '/v1/o-dang-ky/ho-so/mo-khoa',
  timKiemInDk = '/v1/o-dang-ky/ho-so/danh-sach-xe-in',
  timKiemToKhai = '/v1/dich-vu-cong/ds-to-khai',
}

export const timKiemHoSoXe = async (params: ITimKiemHoSo) => {
  const res = await localHttp.get<ITimKiemHoSoDto>({ url: Api.timKiemHoSoXe, params: params });
  return res;
};

export const timKiemToKhai = async (params: any) => {
  console.log('PARAM: ', params);
  const res = await localHttp.get<any>({ url: Api.timKiemToKhai, params: params });
  return res;
};

export const timKiemInDk = async (params: ITimKiemHoSo) => {
  const res = await localHttp.get<ITimKiemHoSoDto>({ url: Api.timKiemInDk, params: params });
  return res;
};

export const hoanThanhDs = async (params: any, canBoId: String) => {
  const res = await localHttp.put<IHoanThanhDsModel>({
    url: `${Api.hoanThanhDs}/${canBoId}`,
    params: params,
  });
  return res;
};

export const duyetTraBien = async (params: any, canBoId: String) => {
  const res = await localHttp.put<IHoanThanhDsModel>({
    url: `${Api.duyetTraBien}/${canBoId}`,
    params: params,
  });
  return res;
};

export const khongduyetTraBien = async (params: any, canBoId: String) => {
  const res = await localHttp.put<IHoanThanhDsModel>({
    url: `${Api.khongduyetTraBien}/${canBoId}`,
    params: params,
  });
  return res;
};

export const moKhoa = async (params: any, canBoId: String) => {
  const res = await localHttp.put<IHoanThanhDsModel>({
    url: `${Api.moKhoa}/${canBoId}`,
    params: params,
  });
  return res;
};
