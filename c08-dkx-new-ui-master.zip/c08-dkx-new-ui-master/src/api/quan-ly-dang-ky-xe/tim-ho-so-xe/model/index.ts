import { BaseModel } from '/@/api/model/baseModel';

export interface ITimKiemHoSo extends BaseModel {
  canBoDangKy?: String;
  tuNgay?: String;
  bienSo?: String;
  denNgay?: String;
  dangKyMoi?: String;
  chuaHoanThanhThuTuc?: String;
  mauBien?: String;
  tuNgayDoiCap?: String;
  dangKyNghiepVu?: String;
  daNhapDuThongTin?: String;
  soMay?: String;
  denNgayDoiCap?: String;
  dangKyTam?: String;
  daInDangKy?: String;
  soKhung?: String;
  tuNgayThuHoi?: String;
  stdc?: String;
  daInSeri?: String;
  tenCSH?: String;
  denNgayThuHoi?: String;
  dangKySangTenTrongTinh?: String;
  daHoanThanhThuTuc?: String;
  diaChi?: String;
  tuNgayDiChuyen?: String;
  dangKyXeChuyenDen?: String;
  dangChoDuyetTraBien?: String;
  denNgayDiChuyen?: String;
  thuHoiDangKyBienSo?: String;
  doiCapLaiDangKyBienSo?: String;
  xeTraLaiBienSo?: String;
  dangKyXeTraBien?: String;
}

export interface ITimKiemInDk extends BaseModel {
  loaiXe?: String;
  laKhuKtdb?: String;
  laBienTam?: String;
  canBoId?: String;
  tuNgay?: String;
  bienSo?: String;
  denNgay?: String;
  dangKyMoi?: String;
  mauBien?: String;
  dangKyNghiepVu?: String;
  daydu?: String;
  soMay?: String;
  dangKyTam?: String;
  daIn?: String;
  soKhung?: String;
  nSeri?: String;
  ten?: String;
  sangTenTT?: String;
  diaChi?: String;
  sangTenNT?: String;
  traBien?: String;
}

export interface IHoanThanhDsModel extends BaseModel {
  success?: String;
  fail?: String;
  doNotUpdate?: String;
}
