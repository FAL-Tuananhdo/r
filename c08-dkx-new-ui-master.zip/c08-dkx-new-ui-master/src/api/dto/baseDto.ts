export interface BaseDto {
  updatedDate?: string;
  createdDate?: string;
  updatedBy?: string;
  createdBy?: string;
}
