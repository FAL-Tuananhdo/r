import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IDauBienQuocGia extends BaseModel {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  dauBienQuocGia?: String;
  bienSoQuocGiaId?: String;
  ghiChu?: String;
  tenQuocGia?: String;
  tenCreatedBy?: String;
  tenUpdatedBy?: String;
  maQuocGia?: String;
}

export type ISearchParamDauBienQuocGia = Pick<
  IDauBienQuocGia,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'dauBienQuocGia'
  | 'bienSoQuocGiaId'
  | 'ghiChu'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
  | 'maQuocGia'
>;
export interface IUpdateParamsDauBienQuocGia extends IDauBienQuocGia {
  id: String;
}

export type IListDauBienQuocGia = BasicFetchResult<IDauBienQuocGia>;
