import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IDauBienQuocGiaDto extends BaseDto {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  dauBienQuocGia?: String;
  bienSoQuocGiaId?: String;
  ghiChu?: String;
  tenQuocGia?: String;
  tenCreatedBy?: String;
  tenUpdatedBy?: String;
  maQuocGia?: String;
}

export type IRequestSearchDauBienQuocGiaDto = Pick<
  IDauBienQuocGiaDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'dauBienQuocGia'
  | 'bienSoQuocGiaId'
  | 'ghiChu'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
  | 'maQuocGia'
>;
export interface IRequestUpdateDauBienQuocGiaDto extends IDauBienQuocGiaDto {
  id: String;
}

export type IListDauBienQuocGiaDto = BasicFetchResult<IDauBienQuocGiaDto>;
