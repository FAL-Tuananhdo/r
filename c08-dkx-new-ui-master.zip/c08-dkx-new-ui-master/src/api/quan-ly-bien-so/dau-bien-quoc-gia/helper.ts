import {
  IDauBienQuocGiaDto,
  IListDauBienQuocGiaDto,
  IRequestSearchDauBienQuocGiaDto,
  IRequestUpdateDauBienQuocGiaDto,
} from './dto';
import {
  ISearchParamDauBienQuocGia,
  IListDauBienQuocGia,
  IUpdateParamsDauBienQuocGia,
  IDauBienQuocGia,
} from './model';

export const transformDauBienQuocGiaDtoToModel = (dto: IDauBienQuocGiaDto): IDauBienQuocGia => {
  return {
    id: dto.id,
    ghiChu: dto.ghiChu,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    dauBienQuocGia: dto.dauBienQuocGia,
    bienSoQuocGiaId: dto.bienSoQuocGiaId,
    maQuocGia: dto.maQuocGia,
    tenQuocGia: dto.tenQuocGia,
    tenCreatedBy: dto.tenCreatedBy,
    tenUpdatedBy: dto.tenUpdatedBy,
  };
};
export const transformListDauBienQuocGiaDtoToModel = (
  list: IListDauBienQuocGiaDto,
): IListDauBienQuocGia => {
  return {
    ...list,
    items: list.items.map<IDauBienQuocGia>((item) => transformDauBienQuocGiaDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamDauBienQuocGia) => {
  const paramSearch: IRequestSearchDauBienQuocGiaDto = {
    dauBienQuocGia: dto.dauBienQuocGia,
    bienSoQuocGiaId: dto.bienSoQuocGiaId,
    maQuocGia: dto.maQuocGia,
    ghiChu: dto.ghiChu,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
  };
  return paramSearch;
};

export const transformDauBienQuocGiaModelToDto = (model: IDauBienQuocGia): IDauBienQuocGiaDto => {
  return {
    id: model.id,
    ghiChu: model.ghiChu,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    dauBienQuocGia: model.dauBienQuocGia,
    bienSoQuocGiaId: model.bienSoQuocGiaId,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsDauBienQuocGia,
): IRequestUpdateDauBienQuocGiaDto => {
  const dtoTransform: IRequestUpdateDauBienQuocGiaDto = {
    ...transformDauBienQuocGiaModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
