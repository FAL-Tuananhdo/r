import { localHttp } from '/@/utils/http/axios';

import { IDauBienQuocGiaDto, IListDauBienQuocGiaDto } from './dto';
import {
  ISearchParamDauBienQuocGia,
  IListDauBienQuocGia,
  IUpdateParamsDauBienQuocGia,
  IDauBienQuocGia,
} from './model';
import {
  transformDauBienQuocGiaDtoToModel,
  transformListDauBienQuocGiaDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  main = '/v1/dau-bien-quoc-gia',
  getList = '/v1/dau-bien-quoc-gia/getList',
  checkDauBienQg = '/v1/dau-bien-quoc-gia/check-su-dung-dau-bien',
}

export const getListDauBienQuocGia = async (
  params: ISearchParamDauBienQuocGia,
): Promise<IListDauBienQuocGia> => {
  const res = await localHttp.get<IListDauBienQuocGiaDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListDauBienQuocGiaDtoToModel(res);
};

export const checkSuDungDauBienQg = async (params: ISearchParamDauBienQuocGia) => {
  const res = await localHttp.get<IDauBienQuocGiaDto>({
    url: Api.checkDauBienQg,
    params: transformSearchParamsToDto(params),
  });
  return res;
};

export const getListDauBienQuocGiaSelect = async (params?: any): Promise<IListDauBienQuocGia> => {
  const res = await localHttp.get<IListDauBienQuocGia>({ url: Api.getList, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createDauBienQuocGia = async (params: IDauBienQuocGia) => {
  const res = await localHttp.post<IDauBienQuocGiaDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateDauBienQuocGia = (params: IUpdateParamsDauBienQuocGia, id: any) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdDauBienQuocGia = async (id: String): Promise<IDauBienQuocGia> => {
  const res = await localHttp.get<IDauBienQuocGiaDto>({
    url: `${Api.main}/${id}`,
  });
  return transformDauBienQuocGiaDtoToModel(res);
};

export const deleteDauBienQuocGia = (id?: String) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};

export const getListDauBienQuocGiaSelectPage = async (): Promise<IListDauBienQuocGia> => {
  const res = await localHttp.get<IListDauBienQuocGia>({ url: Api.getList });
  return res;
};
