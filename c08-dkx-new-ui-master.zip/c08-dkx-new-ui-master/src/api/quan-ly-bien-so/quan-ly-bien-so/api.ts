import { localHttp } from '/@/utils/http/axios';

import { IQuanLyBienSoDto, IListQuanLyBienSoDto, IListBienSoDto } from './dto';
import {
  ISearchParamQuanLyBienSo,
  IListQuanLyBienSo,
  IQuanLyBienSo,
  IBienSo,
  IListBienSo,
} from './model';
import {
  transformListQuanLyBienSoDtoToModel,
  transformSearchParamsToDto,
  transformListBienSoDtoToModel,
} from './helper';

enum Api {
  main = '/v1/quan-ly-bien-so',
  createAll = '/v1/quan-ly-bien-so/tao-ca-day-bien',
  deleteDayBien = '/v1/quan-ly-bien-so/xoa-day-bien',
  detailDayBien = '/v1/quan-ly-bien-so/xem-day-bien',
  detaiDayBienDanhDau = '/v1/quan-ly-bien-so/xem-day-bien-danh-dau',
  searchBienSo = '/v1/quan-ly-bien-so/search',
  updateBienDanhDau = '/v1/quan-ly-bien-so/bienDanhDau',
  guiDayBienDauGia = '/v1/quan-ly-bien-so/gui-bien-dau-gia',
}

export const getQuanLyBienSo = async (
  params: ISearchParamQuanLyBienSo,
): Promise<IListQuanLyBienSo> => {
  const res = await localHttp.get<IListQuanLyBienSoDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListQuanLyBienSoDtoToModel(res);
};

export const getListBienSo = async (params: ISearchParamQuanLyBienSo): Promise<IListBienSo> => {
  const res = await localHttp.get<IListBienSoDto>({
    url: Api.detailDayBien,
    params: transformSearchParamsToDto(params),
  });
  return transformListBienSoDtoToModel(res);
};

export const getListBienSoDanhDau = async (
  params: ISearchParamQuanLyBienSo,
): Promise<IListQuanLyBienSo> => {
  const res = await localHttp.get<IListQuanLyBienSoDto>({
    url: Api.detaiDayBienDanhDau,
    params: transformSearchParamsToDto(params),
  });
  return transformListQuanLyBienSoDtoToModel(res);
};

export const createAllDayBien = async (params: IQuanLyBienSo, status: boolean) => {
  const res = await localHttp.post<IQuanLyBienSoDto>({
    url: `${Api.createAll}/?active=${status}`,
    params: params,
  });
  return res;
};

export const createDayBienTiepTheo = (params: IQuanLyBienSo, status: boolean) => {
  const res = localHttp.post({
    url: `${Api.main}/?active=${status}`,
    params: params,
  });
  return res;
};

export const deleteDayBienSo = async (params: IQuanLyBienSo, status: boolean) => {
  const res = await localHttp.delete({
    url: `${Api.deleteDayBien}?active=${status}`,
    params: params,
  });
  return res;
};

export const searchBienSo = (params: any) => {
  const res = localHttp.get({
    url: Api.searchBienSo,
    params: params,
  });
  return res;
};

export const updateBienSoDanhDau = (id: String, params: any) => {
  const res = localHttp.put({
    url: `${Api.updateBienDanhDau}/${id}`,
    params: params,
  });
  return res;
};

export const guiBienDauGia = (params: IBienSo) => {
  const res = localHttp.post({
    url: `${Api.guiDayBienDauGia}`,
    params: params,
  });
  return res;
};
