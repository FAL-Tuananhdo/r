import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IQuanLyBienSo extends BaseModel {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  dayBien?: String;
  soBien?: String;
  daCapDk?: String;
  daCapMin?: String;
  daCapMax?: String;
  daCapDan?: String;
  danhDau?: String;
  nghiepVu?: String;
  guiDauGia?: string;
  khongDauGia?: string;
  dauGiaThatBai?: string;
  dauGiaThanhCong?: string;

  donViCsgtId?: String;
  quocGiaId?: String;
  maQuocGia?: string;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  dauBienQuocGiaId?: String;
  mauBien?: String;
  seriChuId?: String;
  dangKyTam?: String;
  alert?: String;
  congVanId?: String;
  bienDayDu?: String;

  seriSo?: String;
  daCap?: String;
}
export interface IBienSo extends BaseModel {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  seriSo?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  mauBien?: String;
  dangKyTam?: String;
  daCap?: String;
  nghiepVu?: String;
  trangThaiDauGia?: string;
}

export type ISearchParamQuanLyBienSo = Pick<
  IQuanLyBienSo,
  | 'quocGiaId'
  | 'dauBienTheoTinh'
  | 'dauBienQuocGia'
  | 'mauBien'
  | 'seriChuId'
  | 'dangKyTam'
  | 'dayBien'
  | 'page'
  | 'pageSize'
  | 'seriSo'
  | 'dauBienQuocGiaId'
  | 'maQuocGia'
>;
export interface IUpdateParamsQuanLyBienSo extends IQuanLyBienSo {
  id: String;
}

export type IListQuanLyBienSo = BasicFetchResult<IQuanLyBienSo>;

export type IListBienSo = BasicFetchResult<IBienSo>;
