import {
  IQuanLyBienSoDto,
  IListQuanLyBienSoDto,
  IRequestSearchQuanLyBienSoDto,
  IRequestUpdateQuanLyBienSoDto,
  IBienSoDto,
  IListBienSoDto,
} from './dto';
import {
  ISearchParamQuanLyBienSo,
  IListQuanLyBienSo,
  IUpdateParamsQuanLyBienSo,
  IQuanLyBienSo,
  IBienSo,
  IListBienSo,
} from './model';

export const transformBienSoDtoToModel = (dto: IBienSoDto): IBienSo => {
  return {
    id: dto.id,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    nghiepVu: dto.nghiepVu,
    seriSo: dto.seriSo,
    seriChu: dto.seriChu,
    dangKyTam: dto.dangKyTam,
    daCap: dto.daCap,
    trangThaiDauGia: dto.trangThaiDauGia,
  };
};
export const transformQuanLyBienSoDtoToModel = (dto: IQuanLyBienSoDto): IQuanLyBienSo => {
  return {
    id: dto.id,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    dayBien: dto.dayBien,
    soBien: dto.soBien,
    daCapDk: dto.daCapDk,
    daCapMin: dto.daCapMin,
    daCapMax: dto.daCapMax,
    daCapDan: dto.daCapDan,
    danhDau: dto.danhDau,
    guiDauGia: dto.guiDauGia,
    khongDauGia: dto.khongDauGia,
    dauGiaThatBai: dto.dauGiaThatBai,
    dauGiaThanhCong: dto.dauGiaThanhCong,

    message: dto.message,
    alert: dto.alert,
    nghiepVu: dto.nghiepVu,
    seriSo: dto.seriSo,
    daCap: dto.daCap,
  };
};
export const transformListQuanLyBienSoDtoToModel = (
  list: IListQuanLyBienSoDto,
): IListQuanLyBienSo => {
  return {
    ...list,
    items: list.items.map<IQuanLyBienSo>((item) => transformQuanLyBienSoDtoToModel(item)),
  };
};

export const transformListBienSoDtoToModel = (list: IListBienSoDto): IListBienSo => {
  return {
    ...list,
    items: list.items.map<IBienSo>((item) => transformBienSoDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamQuanLyBienSo) => {
  const paramSearch: IRequestSearchQuanLyBienSoDto = {
    quocGiaId: dto.maQuocGia,
    dauBienTheoTinh: dto.dauBienTheoTinh,
    dauBienQuocGia: dto.dauBienQuocGia,
    dauBienQuocGiaId: dto.dauBienQuocGiaId,
    mauBien: dto.mauBien,
    seriChuId: dto.seriChuId,
    dangKyTam: dto.dangKyTam,
    dayBien: dto.dayBien,
    seriSo: dto.seriSo,
    page: dto.page,
    pageSize: dto.pageSize,
  };
  return paramSearch;
};

export const transformQuanLyBienSoModelToDto = (model: IQuanLyBienSo): IQuanLyBienSoDto => {
  return {
    id: model.id,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    dayBien: model.dayBien,
    daCapDk: model.daCapDk,
    daCapMin: model.daCapMin,
    daCapMax: model.daCapMax,
    daCapDan: model.daCapDan,
    danhDau: model.danhDau,
    message: model.message,
    alert: model.alert,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsQuanLyBienSo,
): IRequestUpdateQuanLyBienSoDto => {
  const dtoTransform: IRequestUpdateQuanLyBienSoDto = {
    ...transformQuanLyBienSoModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
