import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IQuanLyBienSoDto extends BaseDto {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  dayBien?: String;
  soBien?: String;
  daCapDk?: String;
  daCapMin?: String;
  daCapMax?: String;
  daCapDan?: String;
  danhDau?: String;
  nghiepVu?: String;
  guiDauGia?: string;
  khongDauGia?: string;
  dauGiaThatBai?: string;
  dauGiaThanhCong?: string;

  donViCsgtId?: String;
  quocGiaId?: String;
  maQuocGia?: string;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  dauBienQuocGiaId?: String;
  mauBien?: String;
  seriChuId?: String;
  dangKyTam?: String;

  alert?: String;
  congVanId?: String;
  bienDayDu?: String;

  seriSo?: String;
  daCap?: String;
}

export type IRequestSearchQuanLyBienSoDto = Pick<
  IQuanLyBienSoDto,
  | 'quocGiaId'
  | 'dauBienTheoTinh'
  | 'dauBienQuocGia'
  | 'mauBien'
  | 'seriChuId'
  | 'dangKyTam'
  | 'dayBien'
  | 'page'
  | 'pageSize'
  | 'seriSo'
  | 'dauBienQuocGiaId'
  | 'maQuocGia'
>;

export interface IBienSoDto extends BaseDto {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  seriSo?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  mauBien?: String;
  dangKyTam?: String;
  daCap?: String;
  nghiepVu?: String;
  trangThaiDauGia?: string;
}
export interface IRequestUpdateQuanLyBienSoDto extends IQuanLyBienSoDto {
  id: String;
}

export type IListQuanLyBienSoDto = BasicFetchResult<IQuanLyBienSoDto>;

export type IListBienSoDto = BasicFetchResult<IBienSoDto>;
