import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IDauBienTheoTinhDto extends BaseDto {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  dauBienTheoTinh?: String;
  donViCsgtId?: String;
  ghiChu?: String;


  //search
  maDonViCsgt?: string;
}

export type IRequestSearchDauBienTheoTinhDto = Pick<
  IDauBienTheoTinhDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'dauBienTheoTinh'
  | 'donViCsgtId'
  | 'ghiChu'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
  | 'maDonViCsgt'
>;
export interface IRequestUpdateDauBienTheoTinhDto extends IDauBienTheoTinhDto {
  id: String;
}

export type IListDauBienTheoTinhDto = BasicFetchResult<IDauBienTheoTinhDto>;
