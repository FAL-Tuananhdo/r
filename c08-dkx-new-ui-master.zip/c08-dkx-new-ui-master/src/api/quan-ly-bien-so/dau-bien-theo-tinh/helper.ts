import {
  IDauBienTheoTinhDto,
  IListDauBienTheoTinhDto,
  IRequestSearchDauBienTheoTinhDto,
  IRequestUpdateDauBienTheoTinhDto,
} from './dto';
import {
  ISearchParamDauBienTheoTinh,
  IListDauBienTheoTinh,
  IUpdateParamsDauBienTheoTinh,
  IDauBienTheoTinh,
} from './model';

export const transformDauBienTheoTinhDtoToModel = (dto: IDauBienTheoTinhDto): IDauBienTheoTinh => {
  return {
    id: dto.id,
    ghiChu: dto.ghiChu,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    dauBienTheoTinh: dto.dauBienTheoTinh,
    donViCsgtId: dto.donViCsgtId,
    maDonViCsgt: dto.maDonViCsgt,
  };
};
export const transformListDauBienTheoTinhDtoToModel = (
  list: IListDauBienTheoTinhDto,
): IListDauBienTheoTinh => {
  return {
    ...list,
    items: list.items.map<IDauBienTheoTinh>((item) => transformDauBienTheoTinhDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamDauBienTheoTinh) => {
  const paramSearch: IRequestSearchDauBienTheoTinhDto = {
    dauBienTheoTinh: dto.dauBienTheoTinh,
    donViCsgtId: dto.donViCsgtId,
    status: dto.status,
    ghiChu: dto.ghiChu,
    page: dto.page,
    pageSize: dto.pageSize,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    maDonViCsgt: dto.maDonViCsgt,
  };
  return paramSearch;
};

export const transformDauBienTheoTinhModelToDto = (
  model: IDauBienTheoTinh,
): IDauBienTheoTinhDto => {
  return {
    id: model.id,
    ghiChu: model.ghiChu,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    dauBienTheoTinh: model.dauBienTheoTinh,
    donViCsgtId: model.donViCsgtId,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsDauBienTheoTinh,
): IRequestUpdateDauBienTheoTinhDto => {
  const dtoTransform: IRequestUpdateDauBienTheoTinhDto = {
    ...transformDauBienTheoTinhModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
