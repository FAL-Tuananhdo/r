import { localHttp } from '/@/utils/http/axios';

import { IDauBienTheoTinhDto, IListDauBienTheoTinhDto } from './dto';
import {
  ISearchParamDauBienTheoTinh,
  IListDauBienTheoTinh,
  IUpdateParamsDauBienTheoTinh,
  IDauBienTheoTinh,
} from './model';
import {
  transformDauBienTheoTinhDtoToModel,
  transformListDauBienTheoTinhDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  main = '/v1/dau-bien-theo-tinh',
  getList = '/v1/dau-bien-theo-tinh/getList',
  checkSuDungBienSo = '/v1/dau-bien-theo-tinh/check-su-dung-dau-bien',
}

export const getListDauBienTheoTinh = async (
  params: ISearchParamDauBienTheoTinh,
): Promise<IListDauBienTheoTinh> => {
  const res = await localHttp.get<IListDauBienTheoTinhDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListDauBienTheoTinhDtoToModel(res);
};

export const getListDauBienTheoTinhSelect = async (
  params?: ISearchParamDauBienTheoTinh,
): Promise<any> => {
  const res = await localHttp.get<IListDauBienTheoTinh>({ url: Api.getList, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createDauBienTheoTinh = async (params: IDauBienTheoTinh) => {

  const res = await localHttp.post<IDauBienTheoTinhDto>({ url: Api.main, params: params });
  return res;
};

export const updateDauBienTheoTinh = (params: IUpdateParamsDauBienTheoTinh, id: any) => {
  console.log("values",params)
  console.log("rowId.value",id)

  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};

export const getByIdDauBienTheoTinh = async (id: String): Promise<IDauBienTheoTinh> => {
  const res = await localHttp.get<IDauBienTheoTinhDto>({ url: `${Api.main}/${id}` });
  return transformDauBienTheoTinhDtoToModel(res);
};

export const deleteDauBienTheoTinh = (id?: String) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};

export const checkSuDungDauBien = async (params?: ISearchParamDauBienTheoTinh) => {
  const res = await localHttp.get<IDauBienTheoTinh>({
    url: Api.checkSuDungBienSo,
    params: params,
  });
  return res;
};
