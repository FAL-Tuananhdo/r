import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IDauBienTheoTinh extends BaseModel {
  status?: String;
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  dauBienTheoTinh?: String;
  donViCsgtId?: String;
  ghiChu?: String;

  // search
  maDonViCsgt?: string;
}

export type ISearchParamDauBienTheoTinh = Pick<
  IDauBienTheoTinh,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'dauBienTheoTinh'
  | 'donViCsgtId'
  | 'ghiChu'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
  | 'maDonViCsgt'
>;
export interface IUpdateParamsDauBienTheoTinh extends IDauBienTheoTinh {
  id: String;
}

export type IListDauBienTheoTinh = BasicFetchResult<IDauBienTheoTinh>;
