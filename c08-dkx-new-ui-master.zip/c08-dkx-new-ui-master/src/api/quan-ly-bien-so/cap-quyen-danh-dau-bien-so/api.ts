import { localHttp } from '/@/utils/http/axios';

import { ICapQuyenDdBsDto, IListCapQuyenDdBsDto } from './dto';
import { ISearchParamCapQuyenDdBs, IListCapQuyenDdBs, ICapQuyenDdBs } from './model';
import {
  transformCapQuyenDdBsDtoToModel,
  transformListCapQuyenDdBsDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  main = '/v1/cap-quyen-danh-dau-bien',
  getList = '/v1/dau-bien-theo-tinh/getList',
  createPass = '/v1/cap-quyen-danh-dau-bien/tao-mat-khau',
  detail = '/v1/cap-quyen-danh-dau-bien/detail',
  updateQl = '/v1/cap-quyen-danh-dau-bien/nguoi-quan-ly',
  checkSuDungCongVan = '/v1/cap-quyen-danh-dau-bien/check-su-dung-cong-van',
}

export const getListCapQuyenDdBs = async (
  params?: ISearchParamCapQuyenDdBs,
): Promise<IListCapQuyenDdBs> => {
  const res = await localHttp.get<IListCapQuyenDdBsDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListCapQuyenDdBsDtoToModel(res);
};

export const getListCapQuyenDdBsSelect = async (
  params?: ISearchParamCapQuyenDdBs,
): Promise<any> => {
  const res = await localHttp.get<IListCapQuyenDdBs>({ url: Api.getList, params: params });
  return res;
};

export const createCapQuyenDanhDauBienSo = (params: ICapQuyenDdBs) => {
  const res = localHttp.post({ url: Api.main, params: params });
  return res;
};

export const createMatKhauCapQuyenDanhDau = async () => {
  const res = await localHttp.post<any>({
    url: Api.createPass,
  });
  return res;
};

export const getDetailCapQuyenDanhDau = (params: ICapQuyenDdBs) => {
  const res = localHttp.get({ url: Api.detail, params: params });
  return res;
};

export const getByIdCapQuyenDdBs = async (id: String): Promise<ICapQuyenDdBs> => {
  const res = await localHttp.get<ICapQuyenDdBsDto>({ url: `${Api.main}/${id}` });
  return transformCapQuyenDdBsDtoToModel(res);
};

export const updateCapQuyenDdBs = (params: ICapQuyenDdBs, id: any) => {
  return localHttp.put({ url: `${Api.main}/${id}`, params: params });
};

export const checkSuDungCongVan = (id: any) => {
  return localHttp.get({ url: `${Api.checkSuDungCongVan}/${id}` });
};

export const updateNguoiQuanLy = (params: ICapQuyenDdBs, id: any) => {
  return localHttp.put({ url: `${Api.updateQl}/${id}`, params: params });
};
