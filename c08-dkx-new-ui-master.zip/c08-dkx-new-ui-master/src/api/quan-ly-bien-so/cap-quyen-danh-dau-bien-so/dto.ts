import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface ICapQuyenDdBsDto extends BaseDto {
  id?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  canBoUser?: String;
  tenCanBo?: String;
  nguoiQlKhoBien?: String;
  luongBien?: String;
  soDaDanhDau?: String;

  soCongVanDN?: String;
  ngayCongVanDN?: String;
  nguoiDN?: String;
  noiDungDN?: String;

  soCongVanLDC?: String;
  ngayCongVanLDC?: String;
  nguoiLDC?: String;
  noiDungLDC?: String;

  soCongVanLDB?: String;
  ngayCongVanLDB?: String;
  nguoiLDB?: String;
  noiDungLDB?: String;

  nameCreatedBy?: String;
  matKhau?: String;
  tenNguoiQlKhoBien?: String;

  soCongVan?: String;
  ngayCongVan?: String;
  nguoiDNCV?: String;
  noiDung?: String;
}

export type IRequestSearchCapQuyenDdBsDto = Pick<
  ICapQuyenDdBsDto,
  | 'canBoUser'
  | 'page'
  | 'pageSize'
  | 'tenCanBo'
  | 'tenNguoiQlKhoBien'
  | 'luongBien'
  | 'soDaDanhDau'
  | 'soCongVan'
  | 'ngayCongVan'
  | 'nguoiDNCV'
  | 'noiDung'
>;
export interface IRequestUpdateCapQuyenDdBsDto extends ICapQuyenDdBsDto {
  id: String;
}

export type IListCapQuyenDdBsDto = BasicFetchResult<ICapQuyenDdBsDto>;
