import {
  ICapQuyenDdBsDto,
  IListCapQuyenDdBsDto,
  IRequestSearchCapQuyenDdBsDto,
  IRequestUpdateCapQuyenDdBsDto,
} from './dto';
import {
  ISearchParamCapQuyenDdBs,
  IListCapQuyenDdBs,
  IUpdateParamsCapQuyenDdBs,
  ICapQuyenDdBs,
} from './model';

export const transformCapQuyenDdBsDtoToModel = (dto: ICapQuyenDdBsDto): ICapQuyenDdBs => {
  return {
    id: dto.id,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    message: dto.message,

    canBoId: dto.canBoId,
    tenCanBo: dto.tenCanBo,
    nguoiQlKhoBien: dto.nguoiQlKhoBien,
    luongBien: dto.luongBien,
    soDaDanhDau: dto.soDaDanhDau,

    soCongVanDN: dto.soCongVanDN,
    ngayCongVanDN: dto.ngayCongVanDN,
    nguoiDN: dto.nguoiDN,
    noiDungDN: dto.noiDungDN,

    soCongVanLDC: dto.soCongVanLDC,
    ngayCongVanLDC: dto.ngayCongVanLDC,
    nguoiLDC: dto.nguoiLDC,
    noiDungLDC: dto.noiDungLDC,

    soCongVanLDB: dto.soCongVanLDB,
    ngayCongVanLDB: dto.ngayCongVanLDB,
    nguoiLDB: dto.nguoiLDB,
    noiDungLDB: dto.noiDungLDB,

    nameCreatedBy: dto.nameCreatedBy,
    matKhau: dto.matKhau,
    tenNguoiQlKhoBien: dto.tenNguoiQlKhoBien,
  };
};
export const transformListCapQuyenDdBsDtoToModel = (
  list: IListCapQuyenDdBsDto,
): IListCapQuyenDdBs => {
  return {
    ...list,
    items: list.items.map<ICapQuyenDdBs>((item) => transformCapQuyenDdBsDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto?: ISearchParamCapQuyenDdBs) => {
  const paramSearch: IRequestSearchCapQuyenDdBsDto = {
    canBoId: dto?.canBoId,
    page: dto?.page,
    pageSize: dto?.pageSize,
    tenCanBo: dto?.tenCanBo,
    tenNguoiQlKhoBien: dto?.tenNguoiQlKhoBien,
    luongBien: dto?.luongBien,
    soDaDanhDau: dto?.soDaDanhDau,
    soCongVan: dto?.soCongVan,
    ngayCongVan: dto?.ngayCongVan,
    nguoiDNCV: dto?.nguoiDNCV,
    noiDung: dto?.noiDung,
  };
  return paramSearch;
};

export const transformCapQuyenDdBsModelToDto = (model: ICapQuyenDdBs): ICapQuyenDdBsDto => {
  return {
    id: model.id,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    message: model.message,

    canBoId: model.canBoId,
    tenCanBo: model.tenCanBo,
    nguoiQlKhoBien: model.nguoiQlKhoBien,
    luongBien: model.luongBien,
    soDaDanhDau: model.soDaDanhDau,

    soCongVanDN: model.soCongVanDN,
    ngayCongVanDN: model.ngayCongVanDN,
    nguoiDN: model.nguoiDN,
    noiDungDN: model.noiDungDN,

    soCongVanLDC: model.soCongVanLDC,
    ngayCongVanLDC: model.ngayCongVanLDC,
    nguoiLDC: model.nguoiLDC,
    noiDungLDC: model.noiDungLDC,

    soCongVanLDB: model.soCongVanLDB,
    ngayCongVanLDB: model.ngayCongVanLDB,
    nguoiLDB: model.nguoiLDB,
    noiDungLDB: model.noiDungLDB,

    nameCreatedBy: model.nameCreatedBy,
    matKhau: model.matKhau,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsCapQuyenDdBs,
): IRequestUpdateCapQuyenDdBsDto => {
  const dtoTransform: IRequestUpdateCapQuyenDdBsDto = {
    ...transformCapQuyenDdBsModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
