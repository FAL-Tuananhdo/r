import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface ICapQuyenDdBs extends BaseModel {
  id?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  canBoUser?: String;
  tenCanBo?: String;
  nguoiQlKhoBien?: String;
  luongBien?: String;
  soDaDanhDau?: String;

  soCongVanDN?: String;
  ngayCongVanDN?: String;
  nguoiDN?: String;
  noiDungDN?: String;

  soCongVanLDC?: String;
  ngayCongVanLDC?: String;
  nguoiLDC?: String;
  noiDungLDC?: String;

  soCongVanLDB?: String;
  ngayCongVanLDB?: String;
  nguoiLDB?: String;
  noiDungLDB?: String;

  nameCreatedBy?: String;
  matKhau?: String;
  tenNguoiQlKhoBien?: String;

  soCongVan?: String;
  ngayCongVan?: String;
  nguoiDNCV?: String;
  noiDung?: String;
}

export type ISearchParamCapQuyenDdBs = Pick<
  ICapQuyenDdBs,
  | 'canBoUser'
  | 'page'
  | 'pageSize'
  | 'tenCanBo'
  | 'tenNguoiQlKhoBien'
  | 'luongBien'
  | 'soDaDanhDau'
  | 'soCongVan'
  | 'ngayCongVan'
  | 'nguoiDNCV'
  | 'noiDung'
>;
export interface IUpdateParamsCapQuyenDdBs extends ICapQuyenDdBs {
  id: String;
}

export type IListCapQuyenDdBs = BasicFetchResult<ICapQuyenDdBs>;
