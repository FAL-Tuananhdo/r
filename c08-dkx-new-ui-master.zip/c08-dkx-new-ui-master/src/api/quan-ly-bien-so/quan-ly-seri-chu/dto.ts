import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IQuanLySeriChuDto extends BaseDto {
  seriChu?: String;
  trongNuoc?: String;
  dangKyTam?: String;
  ghiChu?: String;
  status?: boolean;
  nameUpdatedBy?: String;
  id?: String;
  page?: number;
  pageSize?: number;
  message?: String;
  tenCreatedBy?: String;
  tenUpdatedBy?: String;
  nameCreatedBy?: String;

  checkUsed?: boolean;

}

export type IRequestSearchQuanLySeriChuDto = Pick<
  IQuanLySeriChuDto,
  | 'seriChu'
  | 'trongNuoc'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'dangKyTam'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
>;
export interface IRequestUpdateQuanLySeriChuDto extends IQuanLySeriChuDto {
  id: String;
}

export type IListQuanLySeriChuDto = BasicFetchResult<IQuanLySeriChuDto>;
