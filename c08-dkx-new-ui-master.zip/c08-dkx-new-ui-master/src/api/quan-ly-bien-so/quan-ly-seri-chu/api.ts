import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IQuanLySeriChuDto, IListQuanLySeriChuDto } from './dto';
import {
  ISearchParamQuanLySeriChu,
  IListQuanLySeriChu,
  IUpdateParamsQuanLySeriChu,
  IQuanLySeriChu,
} from './model';
import {
  transformQuanLySeriChuDtoToModel,
  transformListQuanLySeriChuDtoToModel,
  transformSearchParamsToDto,
} from './helper';
import { downloadFileExcel } from '/@/hooks/functionHelper/downloadFileExcel';

enum Api {
  main = '/v1/quan-ly-seri-chu',
  getList = '/v1/quan-ly-seri-chu/getList',
  exportExcel = '/v1/quan-ly-seri-chu/export/excel',
}

export const getListQuanLySeriChu = async (
  params: ISearchParamQuanLySeriChu,
): Promise<IListQuanLySeriChu> => {
  const res = await localHttp.get<IListQuanLySeriChuDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListQuanLySeriChuDtoToModel(res);
};

export const exportExcelSeriChu = async (params?: ISearchParamQuanLySeriChu): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.exportExcel,
    params: params,
  });
  downloadFileExcel(res, 'quan_ly_seri_chu');
  return res;
};

export const getListQuanLySeriChuForSelect = async (
  params?: ISearchParamQuanLySeriChu,
): Promise<IListQuanLySeriChuDto> => {
  const res = await localHttp.get<IListQuanLySeriChuDto>({ url: Api.getList, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createQuanLySeriChu = async (params: IQuanLySeriChu) => {
  const res = await localHttp.post<IQuanLySeriChuDto>({ url: Api.main, params: params });
  return res;
};

export const updateQuanLySeriChu = (params: IUpdateParamsQuanLySeriChu, id: any) => {
  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};

export const getByIdQuanLySeriChu = async (id: String): Promise<IQuanLySeriChu> => {
  const res = await localHttp.get<IQuanLySeriChuDto>({ url: `${Api.main}/${id}` });
  return transformQuanLySeriChuDtoToModel(res);
};

export const deleteQuanLySeriChu = (id?: String) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};
