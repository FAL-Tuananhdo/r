import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IQuanLySeriChu extends BaseModel {
  seriChu?: String;
  trongNuoc?: String;
  dangKyTam?: String;
  ghiChu?: String;
  status?: boolean;
  nameUpdatedBy?: String;
  id?: String;
  page?: number;
  pageSize?: number;
  message?: String;
  tenCreatedBy?: String;
  tenUpdatedBy?: String;
  nameCreatedBy?: String;

  checkUsed?: boolean;
}

export type ISearchParamQuanLySeriChu = Pick<
  IQuanLySeriChu,
  | 'seriChu'
  | 'trongNuoc'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'dangKyTam'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
>;
export interface IUpdateParamsQuanLySeriChu extends IQuanLySeriChu {
  id: String;
}

export type IListQuanLySeriChu = BasicFetchResult<IQuanLySeriChu>;
