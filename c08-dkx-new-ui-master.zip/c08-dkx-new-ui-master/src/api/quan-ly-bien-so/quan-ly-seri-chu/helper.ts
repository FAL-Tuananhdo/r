import {
  IQuanLySeriChuDto,
  IListQuanLySeriChuDto,
  IRequestSearchQuanLySeriChuDto,
  IRequestUpdateQuanLySeriChuDto,
} from './dto';
import {
  ISearchParamQuanLySeriChu,
  IListQuanLySeriChu,
  IUpdateParamsQuanLySeriChu,
  IQuanLySeriChu,
} from './model';

export const transformQuanLySeriChuDtoToModel = (dto: IQuanLySeriChuDto): IQuanLySeriChu => {
  return {
    id: dto.id,
    seriChu: dto.seriChu,
    trongNuoc: dto.trongNuoc,
    dangKyTam: dto.dangKyTam,
    ghiChu: dto.ghiChu,
    status: dto.status,
    nameUpdatedBy: dto.nameUpdatedBy,
    nameCreatedBy: dto.nameCreatedBy,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    tenCreatedBy: dto.tenCreatedBy,
    tenUpdatedBy: dto.tenUpdatedBy,
    checkUsed: dto.checkUsed,
  };
};
export const transformListQuanLySeriChuDtoToModel = (
  list: IListQuanLySeriChuDto,
): IListQuanLySeriChu => {
  return {
    ...list,
    items: list.items.map<IQuanLySeriChu>((item) => transformQuanLySeriChuDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamQuanLySeriChu) => {
  const paramSearch: IRequestSearchQuanLySeriChuDto = {
    dangKyTam: dto.dangKyTam,
    seriChu: dto.seriChu,
    trongNuoc: dto.trongNuoc,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
  };
  return paramSearch;
};

export const transformQuanLySeriChuModelToDto = (model: IQuanLySeriChu): IQuanLySeriChuDto => {
  return {
    id: model.id,
    seriChu: model.seriChu,
    trongNuoc: model.trongNuoc,
    dangKyTam: model.dangKyTam,
    ghiChu: model.ghiChu,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsQuanLySeriChu,
): IRequestUpdateQuanLySeriChuDto => {
  const dtoTransform: IRequestUpdateQuanLySeriChuDto = {
    ...transformQuanLySeriChuModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
