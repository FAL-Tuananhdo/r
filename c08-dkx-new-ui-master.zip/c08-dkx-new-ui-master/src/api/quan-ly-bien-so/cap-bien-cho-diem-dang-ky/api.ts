import { localHttp } from '/@/utils/http/axios';

import { ICapBienDiemDkDto, IListCapBienDiemDkDto } from './dto';
import {
  ISearchParamCapBienDiemDk,
  IListCapBienDiemDk,
  IUpdateParamsCapBienDiemDk,
  ICapBienDiemDk,
} from './model';
import {
  transformCapBienDiemDkDtoToModel,
  transformListCapBienDiemDkDtoToModel,
  transformSearchParamsToDto,
} from './helper';
import { useUserStore } from '/@/store/modules/user';

enum Api {
  main = '/v1/cap-bien-diem-dk',
  getList = '/v1/dau-bien-theo-tinh/getList',
}

export const getListCapBienDiemDk = async (
  params: ISearchParamCapBienDiemDk,
): Promise<IListCapBienDiemDk> => {
  const res = await localHttp.get<IListCapBienDiemDkDto>({
    url: Api.main,
    params: transformSearchParamsToDto({
      ...params,
      capHanhChinh: useUserStore().getUserInfo.capHanhChinhDdk,
    }),
  });
  dataExcel = res.items;
  return transformListCapBienDiemDkDtoToModel(res);
};

export const getListCapBienDiemDkSelect = async (
  params?: ISearchParamCapBienDiemDk,
): Promise<any> => {
  const res = await localHttp.get<IListCapBienDiemDk>({ url: Api.getList, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createCapBienDiemDangKy = async (params: ICapBienDiemDk) => {
  const res = await localHttp.post<ICapBienDiemDkDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateCapBienDiemDangKy = (params: IUpdateParamsCapBienDiemDk, id: any) => {
  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};

export const getByIdCapBienDiemDk = async (id: String): Promise<ICapBienDiemDk> => {
  const res = await localHttp.get<ICapBienDiemDkDto>({ url: `${Api.main}/${id}` });
  return transformCapBienDiemDkDtoToModel(res);
};

export const deleteCapBienDiemDk = (id?: String) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};
