import {
  ICapBienDiemDkDto,
  IListCapBienDiemDkDto,
  IRequestSearchCapBienDiemDkDto,
  IRequestUpdateCapBienDiemDkDto,
} from './dto';
import {
  ISearchParamCapBienDiemDk,
  IListCapBienDiemDk,
  IUpdateParamsCapBienDiemDk,
  ICapBienDiemDk,
} from './model';

export const transformCapBienDiemDkDtoToModel = (dto: ICapBienDiemDkDto): ICapBienDiemDk => {
  return {
    id: dto.id,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    message: dto.message,
    nameCreatedBy: dto.nameCreatedBy,
    nameUpdatedBy: dto.nameUpdatedBy,
    dauBienTheoTinh: dto.dauBienTheoTinh,
    seriChu: dto.seriChu,
    quocGiaId: dto.quocGiaId,
    dauBienQuocGiaId: dto.dauBienQuocGiaId,
    dauBienQuocGia: dto.dauBienQuocGia,
    mauBien: dto.mauBien,
    dangKyTam: dto.dangKyTam,
    tuSo: dto.tuSo,
    denSo: dto.denSo,
    diemDangKyId: dto.diemDangKyId,
    seriChuId: dto.seriChuId,
    tongSo: dto.tongSo,
    daCap: dto.daCap,
    conLai: dto.conLai,
    tenQuocGia: dto.tenQuocGia,
    tenDiemDangKy: dto.tenDiemDangKy,
    donViCsgtId: dto.donViCsgtId,
    maQuocGia: dto.maQuocGia,

    maDiemDangKy: dto.maDiemDangKy,
    maDonViCsgt: dto.maDonViCsgt,
    slBienDauGia: dto.slBienDauGia,
    slBienGuiDauGia: dto.slBienGuiDauGia,
    slBienKhongDauGia: dto.slBienKhongDauGia,
  };
};
export const transformListCapBienDiemDkDtoToModel = (
  list: IListCapBienDiemDkDto,
): IListCapBienDiemDk => {
  return {
    ...list,
    items: list.items.map<ICapBienDiemDk>((item) => transformCapBienDiemDkDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamCapBienDiemDk) => {
  const paramSearch: IRequestSearchCapBienDiemDkDto = {
    page: dto.page,
    pageSize: dto.pageSize,
    donViCsgtId: dto.donViCsgtId,
    tenDiemDangKy: dto.tenDiemDangKy,
    dauBienTheoTinh: dto.dauBienTheoTinh,
    tenQuocGia: dto.tenQuocGia,
    seriChuId: dto.seriChuId,
    dauBienQuocGia: dto.dauBienQuocGia,
    mauBien: dto.mauBien,
    dangKyTam: dto.dangKyTam,
    tuSo: dto.tuSo,
    denSo: dto.denSo,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    conLai: dto.conLai,
    daCap: dto.daCap,
    maDonViCsgt: dto.maDonViCsgt,
    capHanhChinh: dto.capHanhChinh,
  };
  return paramSearch;
};

export const transformCapBienDiemDkModelToDto = (model: ICapBienDiemDk): ICapBienDiemDkDto => {
  return {
    id: model.id,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    message: model.message,
    nameCreatedBy: model.nameCreatedBy,
    nameUpdatedBy: model.nameUpdatedBy,
    dauBienTheoTinh: model.dauBienTheoTinh,
    seriChu: model.seriChu,
    quocGiaId: model.quocGiaId,
    dauBienQuocGiaId: model.dauBienQuocGiaId,
    mauBien: model.mauBien,
    dangKyTam: model.dangKyTam,
    tuSo: model.tuSo,
    denSo: model.denSo,
    diemDangKyId: model.diemDangKyId,
    seriChuId: model.seriChuId,
    tongSo: model.tongSo,
    daCap: model.daCap,
    conLai: model.conLai,
    tenDiemDangKy: model.tenDiemDangKy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsCapBienDiemDk,
): IRequestUpdateCapBienDiemDkDto => {
  const dtoTransform: IRequestUpdateCapBienDiemDkDto = {
    ...transformCapBienDiemDkModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
