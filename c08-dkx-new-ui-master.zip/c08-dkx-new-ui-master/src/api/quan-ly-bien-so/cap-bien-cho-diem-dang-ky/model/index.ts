import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface ICapBienDiemDk extends BaseModel {
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  nameCreatedBy?: String;
  nameUpdatedBy?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  quocGiaId?: String;
  tenQuocGia?: String;
  dauBienQuocGiaId?: String;
  mauBien?: String;
  dangKyTam?: String;
  tuSo?: String;
  denSo?: String;
  diemDangKyId?: String;
  seriChuId?: String;

  tongSo?: String;
  daCap?: String;
  conLai?: String;
  slBienDauGia?: string;
  slBienGuiDauGia?: string;
  slBienKhongDauGia?: string;

  tenDiemDangKy?: String;
  donViCsgtId?: String;
  maQuocGia?: String;

  //sửa
  maDonViCsgt?: string;
  maDiemDangKy?: string;
  capHanhChinh?: string;
}

export type ISearchParamCapBienDiemDk = Pick<
  ICapBienDiemDk,
  | 'page'
  | 'pageSize'
  | 'donViCsgtId'
  | 'tenDiemDangKy'
  | 'dauBienTheoTinh'
  | 'tenQuocGia'
  | 'seriChuId'
  | 'dauBienQuocGia'
  | 'mauBien'
  | 'dangKyTam'
  | 'tuSo'
  | 'denSo'
  | 'createdDate'
  | 'updatedDate'
  | 'conLai'
  | 'daCap'
  | 'createdBy'
  | 'updatedBy'
  | 'maDonViCsgt'
  | 'capHanhChinh'
  | 'slBienDauGia'
  | 'slBienGuiDauGia'
  | 'slBienKhongDauGia'
>;
export interface IUpdateParamsCapBienDiemDk extends ICapBienDiemDk {
  id: String;
}

export type IListCapBienDiemDk = BasicFetchResult<ICapBienDiemDk>;
