import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface ICapBienDiemDkDto extends BaseDto {
  id?: String;
  page?: String;
  pageSize?: String;
  message?: String;
  nameCreatedBy?: String;
  nameUpdatedBy?: String;
  dauBienTheoTinh?: String;
  dauBienQuocGia?: String;
  seriChu?: String;
  quocGiaId?: String;
  tenQuocGia?: String;
  dauBienQuocGiaId?: String;
  mauBien?: String;
  dangKyTam?: String;
  tuSo?: String;
  denSo?: String;
  diemDangKyId?: String;
  seriChuId?: String;

  tongSo?: String;
  daCap?: String;
  conLai?: String;
  slBienDauGia?: string;
  slBienGuiDauGia?: string;
  slBienKhongDauGia?: string;

  tenDiemDangKy?: String;
  donViCsgtId?: String;
  maQuocGia?: String;

  //sửa
  maDonViCsgt?: string;
  maDiemDangKy?: string;
  capHanhChinh?: string;
}

export type IRequestSearchCapBienDiemDkDto = Pick<
  ICapBienDiemDkDto,
  | 'page'
  | 'pageSize'
  | 'donViCsgtId'
  | 'tenDiemDangKy'
  | 'dauBienTheoTinh'
  | 'tenQuocGia'
  | 'seriChuId'
  | 'dauBienQuocGia'
  | 'mauBien'
  | 'dangKyTam'
  | 'tuSo'
  | 'denSo'
  | 'createdDate'
  | 'updatedDate'
  | 'conLai'
  | 'daCap'
  | 'createdBy'
  | 'updatedBy'
  | 'maDonViCsgt'
  | 'capHanhChinh'
>;
export interface IRequestUpdateCapBienDiemDkDto extends ICapBienDiemDkDto {
  id: String;
}

export type IListCapBienDiemDkDto = BasicFetchResult<ICapBienDiemDkDto>;
