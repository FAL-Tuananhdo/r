export type ILoaiKy = 1 | 2 | 3 | 4 | 5;

export interface FormKySoModel {
  X: number;
  Y: number;
  dataSign: string;
  h: number;
  mode: ILoaiKy;
  page: number;
  w: number;
}

export interface KySoResponse {
  result: string;
}
