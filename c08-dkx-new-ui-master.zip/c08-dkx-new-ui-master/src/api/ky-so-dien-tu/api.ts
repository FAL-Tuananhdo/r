import { kySoHttp } from '/@/utils/http/axios';
// import { FormKySoDto } from './dto';
import Axios from 'axios';
import { FormKySoModel, KySoResponse } from './model';
import { transFormKySoToDto } from './helpper';
enum Api {
  main = '/signPDF',
}

const dataFake = {
  items: [
    {
      ten: 'Nguyễn Văn A',
      ngay: '20/10/2022',
      bienSo: '34C1-299.56',
    },
    {
      ten: 'Phạm Đức S',
      ngay: '12/02/2022',
      bienSo: '29C1-199.26',
    },
  ],
  total: 2,
};

export const handleKySo = async (params: FormKySoModel): Promise<KySoResponse> => {
  return await kySoHttp.post({
    url: Api.main,
    params: transFormKySoToDto(params),
  });
};

export const dataDemo = async (): Promise<any> => {
  return await dataFake;
};

export const KySoFetchApi = async (params: FormKySoModel): Promise<any> => {
  const requestOptions = {
    method: 'GET',
  };

  fetch('https://localhost:4567/signPDF', requestOptions)
    .then((response) => response.text())
    .catch((error) => console.log('error', error));
};

export const handleKySoAxios = async (params: FormKySoModel): Promise<KySoResponse> => {
  console.log('sss');
  const res = await Axios.post<any>(`https://localhost:4567/signPDF`, params, {
    headers: { 'Content-Type': 'text/plain' },
  });
  return res.data;
};
