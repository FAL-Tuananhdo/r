import { FormKySoDto } from './dto';
import { FormKySoModel } from './model';

export const transFormKySoToDto = (model: FormKySoModel): FormKySoDto => {
  return {
    X: model.X,
    Y: model.Y,
    dataSign: model.dataSign,
    h: model.h,
    mode: model.mode,
    page: model.page,
    w: model.w,
    // X: 371.453125,
    // Y: 347,
    // dataSign: model.dataSign,
    // h: 111,
    // mode: 1,
    // page: 1,
    // w: 126,
  };
};
