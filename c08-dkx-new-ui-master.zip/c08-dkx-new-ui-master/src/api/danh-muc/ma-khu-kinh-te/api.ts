import { localHttp } from '/@/utils/http/axios';

import { IMaKhuKinhTeDto, IListMaKhuKinhTeDto } from './dto';
import {
  ISearchParamMaKhuKinhTe,
  IListMaKhuKinhTe,
  IUpdateParamsMaKhuKinhTe,
  IMaKhuKinhTe,
} from './model';
import {
  transformMaKhuKinhTeDtoToModel,
  transformListMaKhuKinhTeDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  main = '/v1/ma-khu-kinh-te',
  getList = '/v1/ma-khu-kinh-te/get-list',
  exportExcel = '/v1/ma-khu-kinh-te/export/excel',
}
export const getListMaKhuKinhTe = async (
  params: ISearchParamMaKhuKinhTe,
): Promise<IListMaKhuKinhTe> => {
  const res = await localHttp.get<IListMaKhuKinhTeDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListMaKhuKinhTeDtoToModel(res);
};

export const exportExcelMaKhuKinhTe = async (params: any) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export const getListMaKhuKinhTeSelect = async (
  params?: ISearchParamMaKhuKinhTe,
): Promise<IMaKhuKinhTe[]> => {
  const res = await localHttp.get<IMaKhuKinhTe[]>({
    url: Api.getList,
    params: params,
  });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const localhost = `http://localhost:9000/v1/ma-khu-kinh-te`;

export const createMaKhuKinhTe = async (params: IMaKhuKinhTe) => {
  const res = await localHttp.post<IMaKhuKinhTeDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateMaKhuKinhTe = (params: IUpdateParamsMaKhuKinhTe, id: any) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdMaKhuKinhTe = async (id: string): Promise<IMaKhuKinhTe> => {
  const res = await localHttp.get<IMaKhuKinhTeDto>({
    url: `${Api.main}/${id}`,
  });
  return transformMaKhuKinhTeDtoToModel(res);
};

export const deleteMaKhuKinhTe = (id?: string) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};
