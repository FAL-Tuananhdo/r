import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IMaKhuKinhTe extends BaseModel {
  seriChu?: String;
  maDonViCsgt?: string;
  otoSeriChuId?: string;
  dangKyTam?: string;
  ten: string;
  tenEn?: string;
  status?: string;
  id?: string;
  page?: number;
  pageSize?: number;
  message?: string;
  tenDonViCsgt?: string;

  checkUsed?: Boolean;
}

export type ISearchParamMaKhuKinhTe = Pick<
  IMaKhuKinhTe,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ten'
  | 'seriChu'
  | 'maDonViCsgt'
  | 'dangKyTam'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsMaKhuKinhTe extends IMaKhuKinhTe {
  id: string;
}

export type IListMaKhuKinhTe = BasicFetchResult<IMaKhuKinhTe>;
