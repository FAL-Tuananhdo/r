import {
  IMaKhuKinhTeDto,
  IListMaKhuKinhTeDto,
  IRequestSearchMaKhuKinhTeDto,
  IRequestUpdateMaKhuKinhTeDto,
} from './dto';
import {
  ISearchParamMaKhuKinhTe,
  IListMaKhuKinhTe,
  IUpdateParamsMaKhuKinhTe,
  IMaKhuKinhTe,
} from './model';

export const transformMaKhuKinhTeDtoToModel = (dto: IMaKhuKinhTeDto): IMaKhuKinhTe => {
  return {
    id: dto.id,
    ten: dto.ten,
    maDonViCsgt: dto.maDonViCsgt,
    seriChu: dto.seriChu,
    otoSeriChuId: dto.otoSeriChuId,
    dangKyTam: dto.dangKyTam,
    tenEn: dto.tenEn,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    tenDonViCsgt: dto.tenDonViCsgt,
    checkUsed: dto.checkUsed,
  };
};
export const transformListMaKhuKinhTeDtoToModel = (list: IListMaKhuKinhTeDto): IListMaKhuKinhTe => {
  return {
    ...list,
    items: list.items.map<IMaKhuKinhTe>((item) => transformMaKhuKinhTeDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamMaKhuKinhTe) => {
  const paramSearch: IRequestSearchMaKhuKinhTeDto = {
    ten: dto.ten,
    dangKyTam: dto.dangKyTam,
    maDonViCsgt: dto.maDonViCsgt,
    seriChu: dto.seriChu,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformMaKhuKinhTeModelToDto = (model: IMaKhuKinhTe): IMaKhuKinhTeDto => {
  return {
    id: model.id,
    ten: model.ten,
    maDonViCsgt: model.maDonViCsgt,
    seriChu: model.seriChu,
    dangKyTam: model.dangKyTam,
    tenEn: model.tenEn,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsMaKhuKinhTe,
): IRequestUpdateMaKhuKinhTeDto => {
  const dtoTransform: IRequestUpdateMaKhuKinhTeDto = {
    ...transformMaKhuKinhTeModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
