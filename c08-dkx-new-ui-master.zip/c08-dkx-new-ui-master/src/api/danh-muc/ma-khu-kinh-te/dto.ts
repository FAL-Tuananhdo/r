import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IMaKhuKinhTeDto extends BaseDto {
  seriChu?: String;
  maDonViCsgt?: string;
  otoSeriChuId?: string;
  dangKyTam?: string;
  ten: string;
  tenEn?: string;
  status?: string;
  id?: string;
  page?: number;
  pageSize?: number;
  message?: string;
  tenDonViCsgt?: string;

  checkUsed?: Boolean;
}

export type IRequestSearchMaKhuKinhTeDto = Pick<
  IMaKhuKinhTeDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ten'
  | 'seriChu'
  | 'maDonViCsgt'
  | 'dangKyTam'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateMaKhuKinhTeDto extends IMaKhuKinhTeDto {
  id: string;
}

export type IListMaKhuKinhTeDto = BasicFetchResult<IMaKhuKinhTeDto>;
