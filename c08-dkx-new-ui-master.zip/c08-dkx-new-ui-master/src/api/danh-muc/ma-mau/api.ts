import { localHttp } from '/@/utils/http/axios';

import { IMaMauDto, IListMaMauDto } from './dto';
import { ISearchParamMaMau, IListMaMau, IUpdateParamsMaMau, IMaMau } from './model';
import {
  transformMaMauDtoToModel,
  transformListMaMauDtoToModel,
  transformSearchParamsToDto,
} from './helper';
enum Api {
  main = '/v1/ma-mau',
  exportExcel = '/v1/ma-mau/export/excel',
}

export const getListMaMau = async (params: ISearchParamMaMau): Promise<IListMaMau> => {
  const res = await localHttp.get<IListMaMauDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListMaMauDtoToModel(res);
};

export const exportExcelMaMau = async (params: any) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: params,
  });
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createMaMau = async (params: IMaMau) => {
  const res = await localHttp.post<IMaMauDto>({ url: Api.main, params: params });
  return res;
};

export const updateMaMau = (params: IUpdateParamsMaMau, id: any) => {
  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};

export const getByIdMaMau = async (id: string): Promise<IMaMau> => {
  const res = await localHttp.get<IMaMauDto>({ url: `${Api.main}/${id}` });
  return transformMaMauDtoToModel(res);
};

export const deleteMaMau = (id?: string) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};
