import { IMaMauDto, IListMaMauDto, IRequestSearchMaMauDto, IRequestUpdateMaMauDto } from './dto';
import { ISearchParamMaMau, IListMaMau, IUpdateParamsMaMau, IMaMau } from './model';

export const transformMaMauDtoToModel = (dto: IMaMauDto): IMaMau => {
  return {
    id: dto.id,
    tenMau: dto.tenMau,
    maMau: dto.maMau,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    tenUpdatedBy: dto.tenUpdatedBy,
    tenCreatedBy: dto.tenCreatedBy,
    maMau1: dto.maMau1,
    maMau2: dto.maMau2,
    maMau3: dto.maMau3,
    maMau4: dto.maMau4,
    tenMau1: dto.tenMau1,
    tenMau2: dto.tenMau2,
    tenMau3: dto.tenMau3,
    tenMau4: dto.tenMau4,
  };
};
export const transformListMaMauDtoToModel = (list: IListMaMauDto): IListMaMau => {
  return {
    ...list,
    items: list.items.map<IMaMau>((item) => transformMaMauDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamMaMau) => {
  const paramSearch: IRequestSearchMaMauDto = {
    tenMau: dto.tenMau,
    maMau: dto.maMau,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformMaMauModelToDto = (model: IMaMau): IMaMauDto => {
  return {
    id: model.id,
    tenMau: model.tenMau,
    maMau: model.maMau,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsMaMau,
): IRequestUpdateMaMauDto => {
  const dtoTransform: IRequestUpdateMaMauDto = {
    ...transformMaMauModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
