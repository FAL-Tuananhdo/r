import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IMaMauDto extends BaseDto {
  tenMau: String;
  maMau: String;
  status: boolean;
  id?: number;
  page?: number;
  pageSize?: number;
  message?: String;
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
  maMau1?: String;
  maMau2?: String;
  maMau3?: String;
  maMau4?: String;
  tenMau1?: String;
  tenMau2?: String;
  tenMau3?: String;
  tenMau4?: String;
}

export type IRequestSearchMaMauDto = Pick<
  IMaMauDto,
  | 'tenMau'
  | 'maMau'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateMaMauDto extends IMaMauDto {
  id: number;
}

export type IListMaMauDto = BasicFetchResult<IMaMauDto>;
