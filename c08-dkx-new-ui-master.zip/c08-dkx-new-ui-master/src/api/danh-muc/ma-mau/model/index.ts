import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IMaMau extends BaseModel {
  tenMau: String;
  maMau: String;
  status: boolean;
  id?: number;
  page?: number;
  pageSize?: number;
  message?: String;
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
  maMau1?: String;
  maMau2?: String;
  maMau3?: String;
  maMau4?: String;
  tenMau1?: String;
  tenMau2?: String;
  tenMau3?: String;
  tenMau4?: String;
}

export type ISearchParamMaMau = Pick<
  IMaMau,
  | 'tenMau'
  | 'maMau'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsMaMau extends IMaMau {
  id: number;
}

export type IListMaMau = BasicFetchResult<IMaMau>;
