import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { ICoSoDto, IListCoSoDto } from './dto';
import { ISearchParamCoSo, IListCoSo, IUpdateParamsCoSo, ICoSo, ImportExcel } from './model';
import {
  transformCoSoDtoToModel,
  transformListCoSoDtoToModel,
  transformSearchParamsToDto,
} from './helper';
import { downloadFileExcel } from '/@/hooks/functionHelper/downloadFileExcel';
enum Api {
  main = '/v1/co-so-san-xuat',
  exportExcel = '/v1/co-so-san-xuat/export/excel',
  exportTemplateExcel = '/v1/co-so-san-xuat/export-template/excel',
}

export const getListCoSo = async (params: ISearchParamCoSo): Promise<IListCoSo> => {
  const res = await localHttp.get<IListCoSoDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListCoSoDtoToModel(res);
};

export const exportBieuMauExcel = async () => {
  await localHttp.downloadFileExcel({
    url: Api.exportTemplateExcel,
  });
};

export const exportExcelCoSo = async (params: any) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: params,
  });
};

export const createCoSo = async (params: ICoSo) => {
  const res = await localHttp.post<ICoSoDto>({ url: Api.main, params: params });
  return res;
};

export const updateCoSo = (params: IUpdateParamsCoSo, id: any) => {
  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};

export const getByIdCoSo = async (id: string): Promise<ICoSo> => {
  const res = await localHttp.get<ICoSoDto>({ url: `${Api.main}/${id}` });
  return transformCoSoDtoToModel(res);
};

export const deleteCoSo = (id?: string) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};
export async function uploadExcel<T>(body: ImportExcel) {
  const res = await localHttp.uploadFile<T>(
    {
      url: `${Api.main}/import/excel`,
      responseType: 'json',
    },
    {
      file: body.file,
      data: {
        createdBy: body.createdBy,
      },
    },
  );
  return res;
}

export const downloadFileExcelError = async (body: ImportExcel): Promise<void> => {
  const formData = await new window.FormData();
  await formData.append('createdBy', body.createdBy);
  await formData.append('file', body.file);
  const res = await localHttpDownload.post<string>({
    url: `${Api.main}/export-template-error/excel`,
    params: formData,
  });
  downloadFileExcel(res, 'bieu_mau_error');
};
