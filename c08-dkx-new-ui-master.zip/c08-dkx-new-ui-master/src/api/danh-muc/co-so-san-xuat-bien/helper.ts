import { ICoSoDto, IListCoSoDto, IRequestSearchCoSoDto, IRequestUpdateCoSoDto } from './dto';
import { ISearchParamCoSo, IListCoSo, IUpdateParamsCoSo, ICoSo } from './model';

export const transformCoSoDtoToModel = (dto: ICoSoDto): ICoSo => {
  return {
    id: dto.id,
    ten: dto.ten,
    ma: dto.ma,
    diaChi: dto.diaChi,
    status: dto.status,
    ghiChu: dto.ghiChu,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    UpdatedBy: dto.UpdatedBy,
    CreatedBy: dto.CreatedBy,
  };
};
export const transformListCoSoDtoToModel = (list: IListCoSoDto): IListCoSo => {
  return {
    ...list,
    items: list.items.map<ICoSo>((item) => transformCoSoDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamCoSo) => {
  const paramSearch: IRequestSearchCoSoDto = {
    ten: dto.ten,
    ma: dto.ma,
    diaChi: dto.diaChi,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformCoSoModelToDto = (model: ICoSo): ICoSoDto => {
  return {
    id: model.id,
    ten: model.ten,
    ma: model.ma,
    diaChi: model.diaChi,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsCoSo,
): IRequestUpdateCoSoDto => {
  const dtoTransform: IRequestUpdateCoSoDto = {
    ...transformCoSoModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
