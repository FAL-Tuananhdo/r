import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface ICoSoDto extends BaseDto {
  ten: String;
  ma: String;
  diaChi: String;
  status: boolean;
  ghiChu?: string;
  id?: number;
  page?: number;
  pageSize?: number;
  message?: String;
  UpdatedBy?: String;
  CreatedBy?: String;
}

export type IRequestSearchCoSoDto = Pick<
  ICoSoDto,
  | 'ten'
  | 'ma'
  | 'diaChi'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateCoSoDto extends ICoSoDto {
  id: number;
}

export type IListCoSoDto = BasicFetchResult<ICoSoDto>;
