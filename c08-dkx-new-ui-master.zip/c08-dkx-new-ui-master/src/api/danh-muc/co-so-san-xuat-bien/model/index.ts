import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface ICoSo extends BaseModel {
  ten: String;
  ma: String;
  diaChi: String;
  status: boolean;
  ghiChu?: string;
  id?: number;
  page?: number;
  pageSize?: number;
  message?: String;
  UpdatedBy?: String;
  CreatedBy?: String;
}

export type ISearchParamCoSo = Pick<
  ICoSo,
  | 'ten'
  | 'ma'
  | 'diaChi'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsCoSo extends ICoSo {
  id: number;
}

export type IListCoSo = BasicFetchResult<ICoSo>;

export interface ImportExcel {
  file: File;
  createdBy?: string;
}

export interface modelChoseFileExcel {
  file: File;
  method: string;
  filename: string;
}

export interface ResponseImportExcel {
  status?: string;
  message?: string;
  fileError?: {
    type: 'blob';
  };
}

export type ResponseExcelModel = ResponseImportExcel;
