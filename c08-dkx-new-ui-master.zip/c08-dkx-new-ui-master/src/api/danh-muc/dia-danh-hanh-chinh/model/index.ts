import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IDiaDanhHanhChinh extends BaseModel {
  id?: String;
  level?: String;
  tenDiaDanh?: String;
  maDiaDanh?: String;
  ghiChu?: String;
  capHanhChinh?: String;
  status?: String;
  diaDanhCapTren?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  tenEN?: String;
  tienTo?: String;
  tienToVtat?: String;

  tenDiaDanhCapTren?: String;
}

export type ISearchParamDiaDanhHanhChinh = Pick<
  IDiaDanhHanhChinh,
  | 'tenDiaDanh'
  | 'maDiaDanh'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ghiChu'
  | 'capHanhChinh'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsDiaDanhHanhChinh extends IDiaDanhHanhChinh {
  id: string;
}

export type IListDiaDanhHanhChinh = BasicFetchResult<IDiaDanhHanhChinh>;
