import { localHttp } from '/@/utils/http/axios';

import { IDiaDanhHanhChinhDto, IListDiaDanhHanhChinhDto } from './dto';
import {
  ISearchParamDiaDanhHanhChinh,
  IListDiaDanhHanhChinh,
  IUpdateParamsDiaDanhHanhChinh,
  IDiaDanhHanhChinh,
} from './model';
import {
  transformDiaDanhHanhChinhDtoToModel,
  transformDiaDanhHanhChinhDtoToModelForChildren,
  transformListDiaDanhHanhChinhDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  DiaDanhHanhChinh = '/v1/dia-danh-hanh-chinh',
  tinhThanh = '/v1/dia-danh-hanh-chinh/tinh-thanh',
  quanHuyen = '/v1/dia-danh-hanh-chinh/quan-huyen',
  phuongXa = '/v1/dia-danh-hanh-chinh/phuong-xa',
  getListddhc = '/v1/dia-danh-hanh-chinh/getList',
  test = '/ddhc/get',
  exportExcel = '/v1/dia-danh-hanh-chinh/export/excel',
}
export const getListDiaDanhHanhChinh = async (
  params: ISearchParamDiaDanhHanhChinh,
): Promise<IListDiaDanhHanhChinh> => {
  const res = await localHttp.get<IListDiaDanhHanhChinhDto>({
    url: Api.DiaDanhHanhChinh,
    params: transformSearchParamsToDto(params),
  });
  return transformListDiaDanhHanhChinhDtoToModel(res);
};

export const exportExcelDiaDanhHanhChinh = async (params: ISearchParamDiaDanhHanhChinh) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export const getListDiaDanhHanhChinhExcel = async (
  params: ISearchParamDiaDanhHanhChinh,
): Promise<any> => {
  const res = await localHttp.get<IDiaDanhHanhChinh>({
    url: Api.getListddhc,
    params: transformSearchParamsToDto(params),
  });
  return res;
};

export const getListThanhPho = async (): Promise<IDiaDanhHanhChinhDto> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: Api.tinhThanh });
  return res;
};
export const getListDiaDanhHanhChinhApiSelect = async (
  params?: any,
): Promise<IDiaDanhHanhChinhDto> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: Api.getListddhc, params: params });
  return res;
};

export const getListQuanHuyen = async (params: any): Promise<IDiaDanhHanhChinhDto> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: Api.quanHuyen, params: params });
  return res;
};
export const getListPhuongXa = async (params: any): Promise<IDiaDanhHanhChinhDto> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: Api.phuongXa, params: params });
  return res;
};
//
export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};
export const getTest = async (): Promise<IDiaDanhHanhChinhDto> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: Api.test });
  return res;
};

export const createDiaDanhHanhChinh = async (params: IDiaDanhHanhChinh) => {
  const res = await localHttp.post<IDiaDanhHanhChinhDto>({ url: Api.getListddhc, params: params });
  return res;
};

export const updateDiaDanhHanhChinh = (params: IUpdateParamsDiaDanhHanhChinh, id: any) => {
  const res = localHttp.put({ url: `${Api.getListddhc}/${id}`, params: params });
  return res;
};

export const getByIdDiaDanhHanhChinh = async (id: String): Promise<IDiaDanhHanhChinh> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: `${Api.DiaDanhHanhChinh}/${id}` });
  return transformDiaDanhHanhChinhDtoToModel(res);
};

export const getByIdDiaDanhHanhChinhForAddChildren = async (
  id: String,
): Promise<IDiaDanhHanhChinh> => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: `${Api.getListddhc}/${id}` });
  return transformDiaDanhHanhChinhDtoToModelForChildren(res);
};

export const getByIdDiaDanhHanhChinhApiSelect = async (id: String) => {
  const res = await localHttp.get<IDiaDanhHanhChinhDto>({ url: `${Api.getListddhc}/${id}` });
  return res;
};

export const deleteDiaDanhHanhChinh = (id?: String) => {
  return localHttp.delete({ url: `${Api.getListddhc}/${id}` });
};
