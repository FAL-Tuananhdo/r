import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IDiaDanhHanhChinhDto extends BaseDto {
  id?: String;
  level?: String;
  tenDiaDanh?: String;
  maDiaDanh?: String;
  ghiChu?: String;
  capHanhChinh?: String;
  status?: String;
  diaDanhCapTren?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  tenEN?: String;
  tienTo?: String;
  tienToVtat?: String;

  tenDiaDanhCapTren?: String;
}

export type IRequestSearchDiaDanhHanhChinhDto = Pick<
  IDiaDanhHanhChinhDto,
  | 'tenDiaDanh'
  | 'maDiaDanh'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ghiChu'
  | 'capHanhChinh'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateDiaDanhHanhChinhDto extends IDiaDanhHanhChinhDto {
  id: string;
}

export type IListDiaDanhHanhChinhDto = BasicFetchResult<IDiaDanhHanhChinhDto>;
