import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IOtoLoaiXe extends BaseModel {
  tenLoai?: String;
  tenLoaiXeCapTren?: String;
  maLoai?: string;
  nhomXeId?: String;
  inTheoMau?: String;
  nhapLieuTheoMau?: String;
  status?: String;
  dienGiai?: String;
  sapXep?: String;
  sapXepMax?: String;
  level?: String;
  id?: String;
  page?: number;
  pageSize?: number;
  message?: String;
  children?: IOtoLoaiXe[];
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
  tenNhomXe?: String;
  disabled?: String;

  maLoaiCapTren?: string;
  tenMaLoaiCapTren?: string;
  maLoaiCuoi?: string;
  maLoaiDmdc?: string;
  isUpdate?: Boolean;
}

export type ISearchParamOtoLoaiXe = Pick<
  IOtoLoaiXe,
  | 'tenLoai'
  | 'maLoai'
  | 'nhomXeId'
  | 'inTheoMau'
  | 'nhapLieuTheoMau'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'maLoaiCapTren'
  | 'maLoaiDmdc'
>;
export interface IUpdateParamsOtoLoaiXe extends IOtoLoaiXe {
  id: String;
}

export type IListOtoLoaiXe = BasicFetchResult<IOtoLoaiXe>;
