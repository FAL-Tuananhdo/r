import {
  IOtoLoaiXeDto,
  IListOtoLoaiXeDto,
  IRequestSearchOtoLoaiXeDto,
  IRequestUpdateOtoLoaiXeDto,
} from './dto';
import { ISearchParamOtoLoaiXe, IListOtoLoaiXe, IUpdateParamsOtoLoaiXe, IOtoLoaiXe } from './model';

export const transformOtoLoaiXeDtoToModel = (dto: IOtoLoaiXeDto): IOtoLoaiXe => {
  return {
    id: dto.id,
    tenLoai: dto.tenLoai,
    tenLoaiXeCapTren: dto.tenLoaiXeCapTren,
    maLoai: dto.maLoai,
    nhomXeId: dto.nhomXeId,
    status: dto.status,
    dienGiai: dto.dienGiai,
    sapXep: dto.sapXep,
    sapXepMax: dto.sapXepMax,
    inTheoMau: dto.inTheoMau,
    nhapLieuTheoMau: dto.nhapLieuTheoMau,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    children: dto.children,
    tenUpdatedBy: dto.tenUpdatedBy,
    tenCreatedBy: dto.tenCreatedBy,
    tenNhomXe: dto.tenNhomXe,
    level: dto.level,
    maLoaiCapTren: dto.maLoaiCapTren,
    tenMaLoaiCapTren: dto.tenMaLoaiCapTren,
    maLoaiCuoi: dto.maLoaiCuoi,
    maLoaiDmdc: dto.maLoaiDmdc,
    isUpdate: dto.isUpdate,
  };
};
export const transformOtoLoaiXeDtoToModelForChildren = (dto: IOtoLoaiXeDto): IOtoLoaiXe => {
  return {
    id: dto.id,
    nhomXeId: dto.id,
    tenLoaiXeCapTren: dto.tenLoai,
    sapXep: dto.sapXepMax,
  };
};
export const transformListOtoLoaiXeDtoToModel = (list: IListOtoLoaiXeDto): IListOtoLoaiXe => {
  return {
    ...list,
    items: list.items.map<IOtoLoaiXe>((item) => transformOtoLoaiXeDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamOtoLoaiXe) => {
  const paramSearch: IRequestSearchOtoLoaiXeDto = {
    page: dto.page,
    status: dto.status,
    pageSize: dto.pageSize,
    maLoai: dto.maLoai,
    tenLoai: dto.tenLoai,
    nhomXeId: dto.nhomXeId,
    inTheoMau: dto.inTheoMau,
    nhapLieuTheoMau: dto.nhapLieuTheoMau,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    maLoaiCapTren: dto.maLoaiCapTren,
    maLoaiDmdc: dto.maLoaiDmdc,
  };
  return paramSearch;
};

export const transformOtoLoaiXeModelToDto = (model: IOtoLoaiXe): IOtoLoaiXeDto => {
  return {
    inTheoMau: model.inTheoMau,
    nhapLieuTheoMau: model.nhapLieuTheoMau,
    nhomXeId: model.nhomXeId,
    id: model.id,
    tenLoai: model.tenLoai,
    maLoai: model.maLoai,
    status: model.status,
    dienGiai: model.dienGiai,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    children: model.children,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsOtoLoaiXe,
): IRequestUpdateOtoLoaiXeDto => {
  const dtoTransform: IRequestUpdateOtoLoaiXeDto = {
    ...transformOtoLoaiXeModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
