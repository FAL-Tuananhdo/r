import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IOtoLoaiXeDto, IListOtoLoaiXeDto } from './dto';
import { ISearchParamOtoLoaiXe, IListOtoLoaiXe, IUpdateParamsOtoLoaiXe, IOtoLoaiXe } from './model';
import {
  transformOtoLoaiXeDtoToModel,
  transformOtoLoaiXeDtoToModelForChildren,
  transformListOtoLoaiXeDtoToModel,
  // transformRequestUpdateParamsToDto,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  main = '/v1/oto-ma-loai-xe',
  getList = '/v1/oto-ma-loai-xe/get-list',
  exportExcel = '/v1/oto-ma-loai-xe/export/excel',
  checkSuDung = '/v1/oto-ma-loai-xe/check-su-dung',
  getLov = '/v1/oto-ma-loai-xe/getLov',
}

export const getListOtoLoaiXe = async (params: ISearchParamOtoLoaiXe): Promise<IListOtoLoaiXe> => {
  const res = await localHttp.get<IListOtoLoaiXeDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListOtoLoaiXeDtoToModel(res);
};

export const checkSuDungMaLoaiXe = async (params: ISearchParamOtoLoaiXe): Promise<IOtoLoaiXe> => {
  const res = await localHttp.get<IOtoLoaiXe>({
    url: Api.checkSuDung,
    params: transformSearchParamsToDto(params),
  });
  return res;
};

export const getLOVotoMaLoaiXe = async () => {
  const res = await localHttp.get<any>({
    url: Api.getLov,
  });
  return res;
};

export const exportExcelOtoMaLoaiXe = async (params: ISearchParamOtoLoaiXe) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export const getListOtoLoaiXeApiSelect = async (
  params?: ISearchParamOtoLoaiXe,
): Promise<IOtoLoaiXe[]> => {
  const res = await localHttp.get<IOtoLoaiXe[]>({ url: Api.getList, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createOtoLoaiXe = async (params: IOtoLoaiXe) => {
  const res = await localHttp.post<IOtoLoaiXeDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateOtoLoaiXe = (params: IUpdateParamsOtoLoaiXe, id: any) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdOtoLoaiXe = async (id: string): Promise<IOtoLoaiXe> => {
  const res = await localHttp.get<IOtoLoaiXeDto>({
    url: `${Api.main}/${id}`,
  });
  return transformOtoLoaiXeDtoToModel(res);
};

export const getByIdOtoLoaiXeForAddChildren = async (id: string): Promise<IOtoLoaiXe> => {
  const res = await localHttp.get<IOtoLoaiXeDto>({
    url: `${Api.main}/${id}`,
  });
  return transformOtoLoaiXeDtoToModelForChildren(res);
};

export const deleteOtoLoaiXe = (id?: string) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};
