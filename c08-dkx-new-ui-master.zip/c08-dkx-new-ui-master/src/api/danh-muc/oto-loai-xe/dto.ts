import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IOtoLoaiXeDto extends BaseDto {
  tenLoai?: String;
  tenLoaiXeCapTren?: String;
  maLoai?: string;
  nhomXeId?: String;
  inTheoMau?: String;
  nhapLieuTheoMau?: String;
  status?: String;
  dienGiai?: String;
  sapXep?: String;
  sapXepMax?: String;
  level?: String;
  id?: String;
  page?: number;
  pageSize?: number;
  message?: String;
  children?: IOtoLoaiXeDto[];
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
  tenNhomXe?: String;

  maLoaiCapTren?: string;
  tenMaLoaiCapTren?: string;
  maLoaiCuoi?: string;
  maLoaiDmdc?: string;
  isUpdate?: Boolean;
}

export type IRequestSearchOtoLoaiXeDto = Pick<
  IOtoLoaiXeDto,
  | 'tenLoai'
  | 'maLoai'
  | 'status'
  | 'nhomXeId'
  | 'inTheoMau'
  | 'nhapLieuTheoMau'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'maLoaiCapTren'
  | 'maLoaiDmdc'
>;
export interface IRequestUpdateOtoLoaiXeDto extends IOtoLoaiXeDto {
  id: String;
}

export type IListOtoLoaiXeDto = BasicFetchResult<IOtoLoaiXeDto>;
