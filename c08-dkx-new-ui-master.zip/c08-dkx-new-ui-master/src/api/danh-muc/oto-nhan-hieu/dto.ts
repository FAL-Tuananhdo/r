import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IOtoNhanHieuDto extends BaseDto {
  ten?: String;
  ma?: String;
  nhomNhanHieuId?: String;
  kiemSoatSoKhung?: String;
  kiemSoatSoMay?: String;
  status?: String;
  id?: String;
  sapXep?: String;
  ghiChu?: String;
  page?: Number;
  pageSize?: Number;
  error?: String;
  message?: String;
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
}

export type IRequestSearchOtoNhanHieuDto = Pick<
  IOtoNhanHieuDto,
  | 'ten'
  | 'ma'
  | 'nhomNhanHieuId'
  | 'kiemSoatSoKhung'
  | 'kiemSoatSoMay'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateOtoNhanHieuDto extends IOtoNhanHieuDto {
  id: String;
}

export type IListOtoNhanHieuDto = BasicFetchResult<IOtoNhanHieuDto>;
