import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IOtoNhanHieu extends BaseModel {
  ten?: String;
  ma?: String;
  nhomNhanHieuId?: String;
  kiemSoatSoKhung?: String;
  kiemSoatSoMay?: String;
  status?: String;
  id?: String;
  sapXep?: String;
  ghiChu?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
}

export type ISearchParamOtoNhanHieu = Pick<
  IOtoNhanHieu,
  | 'ten'
  | 'ma'
  | 'nhomNhanHieuId'
  | 'kiemSoatSoKhung'
  | 'kiemSoatSoMay'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsOtoNhanHieu extends IOtoNhanHieu {
  id: String;
}

export type IListOtoNhanHieu = BasicFetchResult<IOtoNhanHieu>;
