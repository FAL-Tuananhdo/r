import { localHttp } from '/@/utils/http/axios';

import { IOtoNhanHieuDto, IListOtoNhanHieuDto } from './dto';
import { ISearchParamOtoNhanHieu, IListOtoNhanHieu, IOtoNhanHieu } from './model';
import {
  transformOtoNhanHieuDtoToModel,
  transformListOtoNhanHieuDtoToModel,
  transformSearchParamsToDto,
  transformOtoNhanHieuDtoToModelForChildren,
} from './helper';

enum Api {
  main = '/v1/oto-nhan-hieu',
  getList = '/v1/oto-nhan-hieu/getList',
  exportExcel = '/v1/oto-nhan-hieu/export/excel',
}

export const getListDanhSachOtoNhanHieu = async (
  params: ISearchParamOtoNhanHieu,
): Promise<IListOtoNhanHieu> => {
  console.log(transformSearchParamsToDto(params));
  const res = await localHttp.get<IListOtoNhanHieuDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListOtoNhanHieuDtoToModel(res);
};
export const getListOtoNhanHieu = async (
  params: ISearchParamOtoNhanHieu,
): Promise<IOtoNhanHieuDto> => {
  const res = await localHttp.get<IOtoNhanHieuDto>({
    url: Api.getList,
    params: transformSearchParamsToDto(params),
  });
  return res;
};

export const exportExcelOtoNhanHieu = async (params: ISearchParamOtoNhanHieu) => {
  console.log(transformSearchParamsToDto(params));
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export const getListOtoNhanHieuSelect = async (
  params?: ISearchParamOtoNhanHieu,
): Promise<IOtoNhanHieu[]> => {
  const res = await localHttp.get<IOtoNhanHieu[]>({
    url: Api.getList,
    params: params,
  });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const getNhanHieuByMa = async (ma: string): Promise<IOtoNhanHieu> => {
  const res = await localHttp.get<IOtoNhanHieuDto>({
    url: `${Api.main}/${ma}`,
  });
  return transformOtoNhanHieuDtoToModel(res);
};

export const getByIdOtoNhanHieuForAddChildren = async (id: string): Promise<IOtoNhanHieu> => {
  const res = await localHttp.get<IOtoNhanHieuDto>({
    url: `${Api.main}/${id}`,
  });
  return transformOtoNhanHieuDtoToModelForChildren(res);
};
