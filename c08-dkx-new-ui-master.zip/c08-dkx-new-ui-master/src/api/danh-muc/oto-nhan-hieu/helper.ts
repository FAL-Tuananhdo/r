import {
  IOtoNhanHieuDto,
  IListOtoNhanHieuDto,
  IRequestSearchOtoNhanHieuDto,
  IRequestUpdateOtoNhanHieuDto,
} from './dto';
import {
  ISearchParamOtoNhanHieu,
  IListOtoNhanHieu,
  IUpdateParamsOtoNhanHieu,
  IOtoNhanHieu,
} from './model';

export const transformOtoNhanHieuDtoToModel = (dto: IOtoNhanHieuDto): IOtoNhanHieu => {
  return {
    id: dto.id,
    ten: dto.ten,
    ma: dto.ma,
    nhomNhanHieuId: dto.nhomNhanHieuId,
    status: dto.status,
    kiemSoatSoKhung: dto.kiemSoatSoKhung,
    kiemSoatSoMay: dto.kiemSoatSoMay,
    sapXep: dto.sapXep,
    ghiChu: dto.ghiChu,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    message: dto.message,
    tenUpdatedBy: dto.tenUpdatedBy,
    tenCreatedBy: dto.tenCreatedBy,
  };
};

export const transformOtoNhanHieuDtoToModelForChildren = (dto: IOtoNhanHieuDto): IOtoNhanHieu => {
  return {
    id: dto.id,
    nhomNhanHieuId: dto.id,
    message: dto.message,
  };
};
export const transformListOtoNhanHieuDtoToModel = (list: IListOtoNhanHieuDto): IListOtoNhanHieu => {
  return {
    ...list,
    items: list.items.map<IOtoNhanHieu>((item) => transformOtoNhanHieuDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamOtoNhanHieu) => {
  const paramSearch: IRequestSearchOtoNhanHieuDto = {
    ma: dto.ma,
    ten: dto.ten,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    nhomNhanHieuId: dto.nhomNhanHieuId,
    kiemSoatSoKhung: dto.kiemSoatSoKhung,
    kiemSoatSoMay: dto.kiemSoatSoMay,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformOtoNhanHieuModelToDto = (model: IOtoNhanHieu): IOtoNhanHieuDto => {
  return {
    id: model.id,
    ten: model.ten,
    ma: model.ma,
    nhomNhanHieuId: model.nhomNhanHieuId,
    status: model.status,
    kiemSoatSoKhung: model.kiemSoatSoKhung,
    kiemSoatSoMay: model.kiemSoatSoMay,
    sapXep: model.sapXep,
    ghiChu: model.ghiChu,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsOtoNhanHieu,
): IRequestUpdateOtoNhanHieuDto => {
  const dtoTransform: IRequestUpdateOtoNhanHieuDto = {
    ...transformOtoNhanHieuModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
