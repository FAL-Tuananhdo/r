import { localHttp } from '/@/utils/http/axios';

import { IMaPhanLoaiQuanLyDto, IListMaPhanLoaiQuanLyDto } from './dto';
import {
  ISearchParamMaPhanLoaiQuanLy,
  IListMaPhanLoaiQuanLy,
  IUpdateParamsMaPhanLoaiQuanLy,
  IMaPhanLoaiQuanLy,
} from './model';
import {
  transformMaPhanLoaiQuanLyDtoToModel,
  transformListMaPhanLoaiQuanLyDtoToModel,
  transformSearchParamsToDto,
  transformMaPhanLoaiQuanLyDtoToModelForChildren,
} from './helper';

enum Api {
  main = '/v1/ma-phan-loai-quan-ly',
  exportExcel = '/v1/ma-phan-loai-quan-ly/export/excel',
}
export const getListMaPhanLoaiQuanLy = async (
  params: ISearchParamMaPhanLoaiQuanLy,
): Promise<IListMaPhanLoaiQuanLy> => {
  const res = await localHttp.get<IListMaPhanLoaiQuanLyDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListMaPhanLoaiQuanLyDtoToModel(res);
};

export const exportExcelPhanLoaiQuanLy = async (params: ISearchParamMaPhanLoaiQuanLy) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createMaPhanLoaiQuanLy = async (params: IMaPhanLoaiQuanLy) => {
  const res = await localHttp.post<IMaPhanLoaiQuanLyDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateMaPhanLoaiQuanLy = (params: IUpdateParamsMaPhanLoaiQuanLy, id: any) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdMaPhanLoaiQuanLy = async (id: string): Promise<IMaPhanLoaiQuanLy> => {
  const res = await localHttp.get<IMaPhanLoaiQuanLyDto>({
    url: `${Api.main}/${id}`,
  });
  return transformMaPhanLoaiQuanLyDtoToModel(res);
};

export const getByIdMaPhanLoaiQuanLyForAddChildren = async (
  id: string,
): Promise<IMaPhanLoaiQuanLy> => {
  const res = await localHttp.get<IMaPhanLoaiQuanLyDto>({
    url: `${Api.main}/${id}`,
  });
  return transformMaPhanLoaiQuanLyDtoToModelForChildren(res);
};

export const deleteMaPhanLoaiQuanLy = (id?: string) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};
