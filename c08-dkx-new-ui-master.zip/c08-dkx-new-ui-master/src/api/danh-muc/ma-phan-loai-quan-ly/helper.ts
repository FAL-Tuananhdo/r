import {
  IMaPhanLoaiQuanLyDto,
  IListMaPhanLoaiQuanLyDto,
  IRequestSearchMaPhanLoaiQuanLyDto,
  IRequestUpdateMaPhanLoaiQuanLyDto,
} from './dto';
import {
  ISearchParamMaPhanLoaiQuanLy,
  IListMaPhanLoaiQuanLy,
  IUpdateParamsMaPhanLoaiQuanLy,
  IMaPhanLoaiQuanLy,
} from './model';

export const transformMaPhanLoaiQuanLyDtoToModel = (
  dto: IMaPhanLoaiQuanLyDto,
): IMaPhanLoaiQuanLy => {
  return {
    id: dto.id,
    tenPhanLoai: dto.tenPhanLoai,
    maPhanLoai: dto.maPhanLoai,
    loaiDoiTuong: dto.loaiDoiTuong,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    ghiChu: dto.ghiChu,
    nhomQuanLyId: dto.nhomQuanLyId,
    coBienNvu: dto.coBienNvu,
    tenUpdatedBy: dto.tenUpdatedBy,
    tenCreatedBy: dto.tenCreatedBy,
    tenNhomQuanLy: dto.tenNhomQuanLy,
    level: dto.level,
    checkUsed: dto.checkUsed,
    checkChildren: dto.checkChildren,
  };
};

export const transformMaPhanLoaiQuanLyDtoToModelForChildren = (
  dto: IMaPhanLoaiQuanLyDto,
): IMaPhanLoaiQuanLy => {
  return {
    id: dto.id,
    nhomQuanLyId: dto.id,
    tenNhomQuanLy: dto.tenPhanLoai,
  };
};
export const transformListMaPhanLoaiQuanLyDtoToModel = (
  list: IListMaPhanLoaiQuanLyDto,
): IListMaPhanLoaiQuanLy => {
  return {
    ...list,
    items: list.items.map<IMaPhanLoaiQuanLy>((item) => transformMaPhanLoaiQuanLyDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamMaPhanLoaiQuanLy) => {
  const paramSearch: IRequestSearchMaPhanLoaiQuanLyDto = {
    tenPhanLoai: dto.tenPhanLoai,
    maPhanLoai: dto.maPhanLoai,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    loaiDoiTuong: dto.loaiDoiTuong,
    coBienNvu: dto.coBienNvu,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformMaPhanLoaiQuanLyModelToDto = (
  model: IMaPhanLoaiQuanLy,
): IMaPhanLoaiQuanLyDto => {
  return {
    id: model.id,
    tenPhanLoai: model.tenPhanLoai,
    maPhanLoai: model.maPhanLoai,
    loaiDoiTuong: model.loaiDoiTuong,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    ghiChu: model.ghiChu,
    nhomQuanLyId: model.nhomQuanLyId,
    coBienNvu: model.coBienNvu,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsMaPhanLoaiQuanLy,
): IRequestUpdateMaPhanLoaiQuanLyDto => {
  const dtoTransform: IRequestUpdateMaPhanLoaiQuanLyDto = {
    ...transformMaPhanLoaiQuanLyModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
