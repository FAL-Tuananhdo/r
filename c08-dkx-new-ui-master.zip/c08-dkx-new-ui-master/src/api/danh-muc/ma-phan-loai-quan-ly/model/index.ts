import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IMaPhanLoaiQuanLy extends BaseModel {
  tenPhanLoai?: String;
  maPhanLoai?: String;
  status?: boolean;
  id?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  nhomQuanLyId?: String;
  loaiDoiTuong?: Number;
  ghiChu?: String;
  coBienNvu?: Number;
  children?: IMaPhanLoaiQuanLy[];
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
  tenNhomQuanLy?: String;
  level?: String;

  checkUsed?: Boolean;
  checkChildren?: Boolean;
}

export type ISearchParamMaPhanLoaiQuanLy = Pick<
  IMaPhanLoaiQuanLy,
  | 'tenPhanLoai'
  | 'maPhanLoai'
  | 'loaiDoiTuong'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'coBienNvu'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsMaPhanLoaiQuanLy extends IMaPhanLoaiQuanLy {
  id: String;
}

export type IListMaPhanLoaiQuanLy = BasicFetchResult<IMaPhanLoaiQuanLy>;
