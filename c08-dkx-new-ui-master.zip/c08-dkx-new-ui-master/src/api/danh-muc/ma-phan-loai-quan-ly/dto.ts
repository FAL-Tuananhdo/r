import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IMaPhanLoaiQuanLyDto extends BaseDto {
  tenPhanLoai?: String;
  maPhanLoai?: String;
  status?: boolean;
  id?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  nhomQuanLyId?: String;
  loaiDoiTuong?: Number;
  ghiChu?: String;
  coBienNvu?: Number;
  children?: IMaPhanLoaiQuanLyDto[];
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
  tenNhomQuanLy?: String;
  level?: String;

  checkUsed?: Boolean;
  checkChildren?: Boolean;
}

export type IRequestSearchMaPhanLoaiQuanLyDto = Pick<
  IMaPhanLoaiQuanLyDto,
  | 'tenPhanLoai'
  | 'maPhanLoai'
  | 'loaiDoiTuong'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'coBienNvu'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateMaPhanLoaiQuanLyDto extends IMaPhanLoaiQuanLyDto {
  id: String;
}

export type IListMaPhanLoaiQuanLyDto = BasicFetchResult<IMaPhanLoaiQuanLyDto>;
