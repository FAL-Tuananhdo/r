import { IQuocGiaDto, IListQuocGiaDto, IRequestSearchQuocGiaDto } from './dto';
import { IQuocGia, IRequestSearchQuocGiaModel, IListQuocGia } from './model';

export const transformQuocGiaDtoToModel = (dto: IQuocGiaDto): IQuocGia => {
  return {
    id: dto.id,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    tenQuocGia: dto.tenQuocGia,
    maQuocGia: dto.maQuocGia,
    laToChuc: dto.laToChuc,
    ghiChu: dto.ghiChu,
    status: dto.status,
    tienTo: dto.tienTo,
    tenEn: dto.tenEn,
    tienToVtat: dto.tienToVtat,
    nameCreatedBy: dto.nameCreatedBy,
    nameUpdatedBy: dto.nameUpdatedBy,
  };
};

export const transformListQuocGiaDtoToModel = (list: IListQuocGiaDto): IListQuocGia => {
  return {
    ...list,
    items: list.items.map<IQuocGia>((item) => transformQuocGiaDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: IRequestSearchQuocGiaModel) => {
  const paramSearch: IRequestSearchQuocGiaDto = {
    page: dto.page,
    status: dto.status,
    pageSize: dto.pageSize,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    maQuocGia: dto.maQuocGia,
    tenQuocGia: dto.tenQuocGia,
    ghiChu: dto.ghiChu,
    laToChuc: dto.laToChuc,
  };
  return paramSearch;
};
