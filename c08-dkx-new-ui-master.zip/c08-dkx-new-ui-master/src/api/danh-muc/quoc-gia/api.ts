import { localHttp } from '/@/utils/http/axios';
import { IListQuocGiaDto } from './dto';
import { IListQuocGia, IRequestSearchQuocGiaModel, IQuocGia } from './model';
import { transformListQuocGiaDtoToModel, transformSearchParamsToDto } from './helper';
enum Api {
  getlist = '/v1/quoc-gia/getList',
  main = '/v1/quoc-gia',
  exportExcel = '/v1/quoc-gia/export/excel',
  getLov = '/v1/quoc-gia/getLov',
}

export const getListQuocGia = async (params: IRequestSearchQuocGiaModel): Promise<IListQuocGia> => {
  const res = await localHttp.get<IListQuocGiaDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListQuocGiaDtoToModel(res);
};

export const getListQuocGiaSelect = async () => {
  const res = await localHttp.get<any>({ url: Api.getLov });
  return res;
};

export const getQuocGiaById = async (id: any) => {
  const res = await localHttp.get<IQuocGia>({ url: `${Api.main}/${id}` });
  return res;
};

export const exportExcel = async (params: IRequestSearchQuocGiaModel) => {
  // const res = await 
  localHttp.downloadFileExcel({ url: Api.exportExcel, params: params });
  // const fileURL = window.URL.createObjectURL(new Blob([res]));
  // const fileLink = document.createElement('a');
  // fileLink.href = fileURL;
  // fileLink.setAttribute('download', 'danh_sach_quoc_gia.xlsx');
  // document.body.appendChild(fileLink);

  // fileLink.click();
  // return res;
};
