import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IQuocGia extends BaseModel {
  id?: String;
  status?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  tenQuocGia?: String;
  maQuocGia?: String;
  ghiChu?: String;
  laToChuc?: String;
  tenEn?: String;
  tienTo?: String;
  tienToVtat?: String;
  nameCreatedBy?: String;
  nameUpdatedBy?: String;
}

export type IRequestSearchQuocGiaModel = Pick<
  IQuocGia,
  | 'page'
  | 'pageSize'
  | 'maQuocGia'
  | 'tenQuocGia'
  | 'laToChuc'
  | 'ghiChu'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'status'
>;

export type IListQuocGia = BasicFetchResult<IQuocGia>;
