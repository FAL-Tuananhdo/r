import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IQuocGiaDto extends BaseDto {
  id?: String;
  status?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  tenQuocGia?: String;
  maQuocGia?: String;
  ghiChu?: String;
  laToChuc?: String;
  tenEn?: String;
  tienTo?: String;
  tienToVtat?: String;
  nameCreatedBy?: String;
  nameUpdatedBy?: String;
}

export type IRequestSearchQuocGiaDto = Pick<
  IQuocGiaDto,
  | 'page'
  | 'pageSize'
  | 'maQuocGia'
  | 'tenQuocGia'
  | 'laToChuc'
  | 'ghiChu'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'status'
>;

export type IListQuocGiaDto = BasicFetchResult<IQuocGiaDto>;
