import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IXeTamDungDk extends BaseModel {
  id?: string;
  trangThai?: string;
  ngayBao?: string;
  noiBao?: string;
  coQuanBaoMat?: string;
  diaChiBaoMat?: string;
  chungTuNguonGoc?: string;
  nguonGoc?: string;
  soChungTu?: string;
  ngayCapChungTu?: string;
  coQuanCapChungTu?: string;
  loaiXe?: string;
  nhanHieu?: string;
  soLoai?: string;
  soMay?: string;
  soKhung?: string;
  donViCsgtId?: string;
  canBoId?: string;
}
export interface IXeChuaDangKy extends BaseModel {
  id?: string;
  coquanCapchungtu?: string;
  coQuanCapChungTu?: string;
  diaChi?: string;
  chungtuNguongoc?: string;
  ngayBao?: string;
  ngaySua?: string;
  ngayTao?: string;
  ngaycapChungtu?: string;
  ngayCapChungTu?: string;
  nguoiSua?: string;
  nguoiTao?: string;
  tenNguoiSua?: string;
  tenNguoiTao?: string;
  noiBao?: string;
  noiDung?: string;
  soChungTu?: string;
  soKhung?: string;
  soMay?: string;
  nhanHieu?: string;
  loaiXe?: string;
  nguonGoc?: string;
  donVi?: string;
  coQuanBaoMat?: string;
  diaChiBaoMat?: string;
  trangThai?: string;
  soLoai?: string;

  // search
  donViCsgtId?: string;
  tuNgay?: string;
  denNgay?: string;
  page?: string;
  pageSize?: string;

  status?: string;
  message?: string;
}

export type ISearchParamXeTamDungDk = Pick<IXeTamDungDk, 'donViCsgtId'>;
export type ISearchParamXeChuaDangKy = Pick<
  IXeChuaDangKy,
  'soMay' | 'soKhung' | 'donViCsgtId' | 'tuNgay' | 'denNgay' | 'page' | 'pageSize'
>;

export interface IUpdateParamsXeTamDungDk extends IXeTamDungDk {
  id: string;
}

export type IListXeTamDungDk = BasicFetchResult<IXeTamDungDk>;
export interface IdataResponse extends BaseModel {
  id?: string;
  soKhung?: string;
  soMay?: string;
  tonTai?: string;
}
export interface IXeTamDungDkResponse extends BaseModel {
  data?: IdataResponse;
  message?: string;
  status?: string;
}
