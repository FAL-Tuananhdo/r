import { localHttp, localHttpDownload } from '/@/utils/http/axios';
import { IXeChuaDangKyDto } from './dto';
import {
  //ISearchParamXeTamDungDk,
  //IListXeTamDungDk,
  //IUpdateParamsXeTamDungDk,
  IXeTamDungDk,
  IXeTamDungDkResponse,
  ISearchParamXeChuaDangKy,
  //IXeChuaDangKy,
} from './model';
import {
  //transformXeTamDungDkDtoToModel,
  //transformXeTamDungDkDtoToModelForChildren,
  //transformListXeTamDungDkDtoToModel,
  transformSearchParamsToDto,
  transformXeChuaDangKyDtoToModel,
} from './helper';
import { downloadFileExcel } from '/@/hooks/functionHelper/downloadFileExcel';
import { ImportExcel } from '../../danh-muc/co-so-san-xuat-bien';
import { resolve } from 'dns';

enum Api {
  luuXeTamDungDangKy = '/v1/o-tien-ich/xe-tam-dung-dang-ky',
  traCuu = '/v1/o-tien-ich/xe-tam-dung-dang-ky/tra-cuu',
  exportExcel = '/v1/o-tien-ich/xe-tam-dung-dang-ky/tra-cuu/excel',
  timKiemCapNhap = '/v1/o-tien-ich/xe-tam-dung-dang-ky/tim-kiem',
  getInfoXeChuaDk = '/v1/o-tien-ich/xe-tam-dung-dang-ky',
  putInfoXeChuaDk = '/v1/o-tien-ich/xe-tam-dung-dang-ky',
  importFile = '/v1/nhap-xe-tam-dung-dk/import',
  capNhatTrangThaiXeChuaDk = '/v1/o-tien-ich/xe-tam-dung-dang-ky/trang-thai',
  capNhatTrangThaiXe = '/v1/o-tien-ich/cap-nhat-trang-thai-xe',
  exportExcelTemplate = '/v1/nhap-xe-tam-dung-dk/export-template/excel',
}

export const luuNhapXeChuaDangKy = async (params: IXeTamDungDk) => {
  const res = await localHttp.post<IXeTamDungDkResponse>({
    url: Api.luuXeTamDungDangKy,
    params: params,
  });
  return res;
};
export const traCuuXeChuaDangKy = async (
  params: ISearchParamXeChuaDangKy,
): Promise<IXeChuaDangKyDto> => {
  const res = await localHttp.get<IXeChuaDangKyDto>({
    url: Api.traCuu,
    params: transformSearchParamsToDto(params),
  });
  return res;
};
export const exportExcelTraCuuXeChuaDangKy = async (
  params: ISearchParamXeChuaDangKy,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
  downloadFileExcel(res, 'danh_sach_xe_chua_dang_ky');
  return res;
};

export const timKiemCapNhap = async (params: IXeTamDungDk) => {
  const res = await localHttp.get<IXeChuaDangKyDto>({ url: Api.timKiemCapNhap, params: params });
  return res;
};
export const getInfoXeChuaDk = async (id: String) => {
  const res = await localHttp.get<IXeChuaDangKyDto>({ url: `${Api.getInfoXeChuaDk}/${id}` });
  return transformXeChuaDangKyDtoToModel(res);
};
export const capNhatTrangThaiXeChuaDk = async (id: String, params: any) => {
  const res = await localHttp.put<IXeChuaDangKyDto>({
    url: `${Api.capNhatTrangThaiXeChuaDk}/${id}`,
    params: params,
  });
  return transformXeChuaDangKyDtoToModel(res);
};

export const capNhatTrangThaiXe = async (id: String, params: any) => {
  const res = await localHttp.put<IXeChuaDangKyDto>({
    url: `${Api.capNhatTrangThaiXe}/${id}`,
    params: params,
  });
  return res;
};

export const putInfoXeChuaDk = async (id: String, params: any) => {
  const res = await localHttp.put<IXeChuaDangKyDto>({
    url: `${Api.putInfoXeChuaDk}/${id}`,
    params: params,
  });
  return res;
};

export async function uploadExcelXeTamDungDk<T>(body: ImportExcel, active: boolean) {
  const res = await localHttp.uploadFile<T>(
    {
      url: `${Api.importFile}?active=${active}`,
      responseType: 'json',
    },
    {
      file: body.file,
    },
  );
  return res;
}

export async function uploadExcelTemplateXeTamDungDk() {
  await localHttp.downloadFileExcel({
    url: Api.exportExcelTemplate,
  });
}
