import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IXeTamDungDkDto extends BaseDto {
  id?: string;
  trangThai?: string;
  ngayBao?: string;
  noiBao?: string;
  coQuanBaoMat?: string;
  diaChiBaoMat?: string;
  chungTuNguonGoc?: string;
  nguonGoc?: string;
  soChungTu?: string;
  ngayCapChungTu?: string;
  coQuanCapChungTu?: string;
  loaiXe?: string;
  nhanHieu?: string;
  soLoai?: string;
  soMay?: string;
  soKhung?: string;
  donViCsgtId?: string;
  canBoId?: string;
}
export interface IXeChuaDangKyDto {
  id?: string;
  coquanCapchungtu?: string;
  diaChi?: string;
  chungtuNguongoc?: string;
  ngayBao?: string;
  ngaySua?: string;
  ngayTao?: string;
  ngaycapChungtu?: string;
  nguoiSua?: string;
  nguoiTao?: string;
  tenNguoiSua?: string;
  tenNguoiTao?: string;
  noiBao?: string;
  noiDung?: string;
  soChungTu?: string;
  soKhung?: string;
  soMay?: string;
  nhanHieu?: string;
  loaiXe?: string;
  nguonGoc?: string;
  donVi?: string;
  coQuanBaoMat?: string;
  diaChiBaoMat?: string;
  trangThai?: string;
  soLoai?: string;
  // search
  donViCsgtId?: string;
  tuNgay?: string;
  denNgay?: string;
  page?: string;
  pageSize?: string;
  status?: string;
  message?: string;
}

export type IRequestSearchXeTamDungDkDto = Pick<IXeTamDungDkDto, 'donViCsgtId'>;
export type ISearchParamXeChuaDangKyDto = Pick<
  IXeChuaDangKyDto,
  'soMay' | 'soKhung' | 'donViCsgtId' | 'tuNgay' | 'denNgay' | 'page' | 'pageSize'
>;
export interface IRequestUpdateXeTamDungDkDto extends IXeTamDungDkDto {
  id: string;
}

export type IListXeTamDungDkDto = BasicFetchResult<IXeTamDungDkDto>;
