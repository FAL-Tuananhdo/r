import { ISearchParamXeChuaDangKyDto, IXeChuaDangKyDto } from './dto';
import { ISearchParamXeChuaDangKy, IXeChuaDangKy } from './model';
export const transformSearchParamsToDto = (dto: ISearchParamXeChuaDangKy) => {
  const paramSearch: ISearchParamXeChuaDangKyDto = {
    tuNgay: dto.tuNgay,
    denNgay: dto.denNgay,
    donViCsgtId: dto.donViCsgtId,
    soMay: dto.soMay,
    soKhung: dto.soKhung,
    page: dto.page,
    pageSize: dto.pageSize,
  };

  return paramSearch;
};
export const transformXeChuaDangKyDtoToModel = (dto: IXeChuaDangKyDto) => {
  const data: IXeChuaDangKy = {
    trangThai: dto.trangThai,
    coQuanBaoMat: dto.noiDung,
    diaChiBaoMat: dto.diaChi,
    ngayBao: dto.ngayBao,
    noiBao: dto.noiBao,
    nguonGoc: dto.nguonGoc,
    chungtuNguongoc: dto.chungtuNguongoc,
    soChungTu: dto.soChungTu,
    ngayCapChungTu: dto.ngaycapChungtu,
    coQuanCapChungTu: dto.coquanCapchungtu,
    loaiXe: dto.loaiXe,
    nhanHieu: dto.nhanHieu,
    soLoai: dto.soLoai,
    soMay: dto.soMay,
    soKhung: dto.soKhung,
    status: dto.status,
    message: dto.message,
  };

  return data;
};
