import { localHttp } from '/@/utils/http/axios';

import { IHoSoScanDto, IListHoSoScanDto } from './dto';
import { ISearchParamHoSoScan, IListHoSoScan, IHoSoScan } from './model';
import {
  transformHoSoScanDtoToModel,
  transformListHoSoScanDtoToModel,
  transformSearchParamsToDto,
} from './helper';
enum Api {
  main = '/v1/ma-mau',
  download = '/v1/ho-so-scan/download',
  taiLieu = '/v1/ho-so-scan/tai-lieu',
}

export const getListHoSoScan = async (params: ISearchParamHoSoScan): Promise<IListHoSoScan> => {
  const res = await localHttp.get<IListHoSoScanDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListHoSoScanDtoToModel(res);
};

export const getListTaiLieu = async (params: ISearchParamHoSoScan): Promise<IListHoSoScan> => {
  const res = await localHttp.get<IListHoSoScanDto>({
    url: Api.taiLieu,
    params: transformSearchParamsToDto(params),
  });
  return transformListHoSoScanDtoToModel(res);
};

export const getByIdHoSoScan = async (id: string): Promise<IHoSoScan> => {
  const res = await localHttp.get<IHoSoScanDto>({ url: `${Api.main}/${id}` });
  return transformHoSoScanDtoToModel(res);
};

export const deleteHoSoScan = (id?: string) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};

export const downloadAllHoSoScan = async (): Promise<IHoSoScan> => {
  const res = await localHttp.get<IHoSoScanDto>({ url: `${Api.download}` });
  return res;
};

export const downloadHoSoScanById = async (id: String): Promise<IHoSoScan> => {
  const res = await localHttp.get<IHoSoScanDto>({ url: `${Api.download}/${id}` });
  return res;
};
