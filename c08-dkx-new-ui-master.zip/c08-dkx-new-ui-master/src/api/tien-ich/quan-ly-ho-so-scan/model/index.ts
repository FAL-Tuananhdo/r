import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IHoSoScan extends BaseModel {
  donViCsgt: String;
  diemDangKy: String;
  bienSo: String;
  mauBien: String;
  soMay: String;
  soKhung: String;
  ngayTaiLenTu: String;
  ngayTaiLenDen: String;
  status: String;
}

export type ISearchParamHoSoScan = Pick<
  IHoSoScan,
  | 'donViCsgt'
  | 'diemDangKy'
  | 'status'
  | 'bienSo'
  | 'mauBien'
  | 'soMay'
  | 'soKhung'
  | 'ngayTaiLenTu'
  | 'ngayTaiLenDen'
>;

export type IListHoSoScan = BasicFetchResult<IHoSoScan>;
