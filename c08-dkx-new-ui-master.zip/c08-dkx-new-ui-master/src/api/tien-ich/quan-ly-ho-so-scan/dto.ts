import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IHoSoScanDto extends BaseDto {
  donViCsgt: String;
  diemDangKy: String;
  bienSo: String;
  mauBien: String;
  soMay: String;
  soKhung: String;
  ngayTaiLenTu: String;
  ngayTaiLenDen: String;
  status: String;
}

export type IRequestSearchHoSoScanDto = Pick<
  IHoSoScanDto,
  | 'donViCsgt'
  | 'diemDangKy'
  | 'status'
  | 'bienSo'
  | 'mauBien'
  | 'soMay'
  | 'soKhung'
  | 'ngayTaiLenTu'
  | 'ngayTaiLenDen'
>;
export interface IRequestUpdateHoSoScanDto extends IHoSoScanDto {
  id: number;
}

export type IListHoSoScanDto = BasicFetchResult<IHoSoScanDto>;
