import { IHoSoScanDto, IListHoSoScanDto, IRequestSearchHoSoScanDto } from './dto';
import { ISearchParamHoSoScan, IListHoSoScan, IHoSoScan } from './model';

export const transformHoSoScanDtoToModel = (dto: IHoSoScanDto): IHoSoScan => {
  return {
    donViCsgt: dto.donViCsgt,
    diemDangKy: dto.diemDangKy,
    bienSo: dto.bienSo,
    mauBien: dto.mauBien,
    soMay: dto.soMay,
    soKhung: dto.soKhung,
    ngayTaiLenTu: dto.ngayTaiLenTu,
    ngayTaiLenDen: dto.ngayTaiLenDen,
    status: dto.status,
  };
};
export const transformListHoSoScanDtoToModel = (list: IListHoSoScanDto): IListHoSoScan => {
  return {
    ...list,
    items: list.items.map<IHoSoScan>((item) => transformHoSoScanDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamHoSoScan) => {
  const paramSearch: IRequestSearchHoSoScanDto = {
    donViCsgt: dto.donViCsgt,
    diemDangKy: dto.diemDangKy,
    bienSo: dto.bienSo,
    mauBien: dto.mauBien,
    soMay: dto.soMay,
    soKhung: dto.soKhung,
    ngayTaiLenTu: dto.ngayTaiLenTu,
    ngayTaiLenDen: dto.ngayTaiLenDen,
    status: dto.status,
  };
  return paramSearch;
};

export const transformHoSoScanModelToDto = (model: IHoSoScan): IHoSoScanDto => {
  return {
    donViCsgt: model.donViCsgt,
    diemDangKy: model.diemDangKy,
    bienSo: model.bienSo,
    mauBien: model.mauBien,
    soMay: model.soMay,
    soKhung: model.soKhung,
    ngayTaiLenTu: model.ngayTaiLenTu,
    ngayTaiLenDen: model.ngayTaiLenDen,
    status: model.status,
  };
};
