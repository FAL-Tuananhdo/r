import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { ITraCuuXacMinhDto, IListTraCuuXacMinhDto } from './dto';
import {
  ISearchParamTraCuuXacMinh,
  IListTraCuuXacMinh,
  IUpdateParamsTraCuuXacMinh,
  ITraCuuXacMinh,
} from './model';
import {
  transformTraCuuXacMinhDtoToModel,
  transformTraCuuXacMinhDtoToModelForChildren,
  transformListTraCuuXacMinhDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  TraCuuXacMinh = '/v1/dia-danh-hanh-chinh',
  tinhThanh = '/v1/dia-danh-hanh-chinh/tinh-thanh',
  quanHuyen = '/v1/dia-danh-hanh-chinh/quan-huyen',
  phuongXa = '/v1/dia-danh-hanh-chinh/phuong-xa',
  getListddhc = '/v1/dia-danh-hanh-chinh/get-list',
  test = '/ddhc/get',
  exportExcel = '/v1/dia-danh-hanh-chinh/export/excel',
}
export const getListTraCuuXacMinh = async (
  params: ISearchParamTraCuuXacMinh,
): Promise<IListTraCuuXacMinh> => {
  const res = await localHttp.get<IListTraCuuXacMinhDto>({
    url: Api.TraCuuXacMinh,
    params: transformSearchParamsToDto(params),
  });
  return transformListTraCuuXacMinhDtoToModel(res);
};

export const exportExcelTraCuuXacMinh = async (
  params: ISearchParamTraCuuXacMinh,
): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
  const fileURL = window.URL.createObjectURL(new Blob([res]));
  const fileLink = document.createElement('a');
  fileLink.href = fileURL;
  fileLink.setAttribute('download', 'danh_sach_dia_danh_hanh_chinh.xlsx');
  document.body.appendChild(fileLink);

  fileLink.click();
  return res;
};

export const getListTraCuuXacMinhExcel = async (
  params: ISearchParamTraCuuXacMinh,
): Promise<any> => {
  const res = await localHttp.get<ITraCuuXacMinh>({
    url: Api.getListddhc,
    params: transformSearchParamsToDto(params),
  });
  return res;
};

export const getListThanhPho = async (): Promise<ITraCuuXacMinhDto> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: Api.tinhThanh });
  return res;
};
export const getListTraCuuXacMinhApiSelect = async (params?: any): Promise<ITraCuuXacMinhDto> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: Api.getListddhc, params: params });
  return res;
};

export const getListQuanHuyen = async (params: any): Promise<ITraCuuXacMinhDto> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: Api.quanHuyen, params: params });
  return res;
};
export const getListPhuongXa = async (params: any): Promise<ITraCuuXacMinhDto> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: Api.phuongXa, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};
export const getTest = async (): Promise<ITraCuuXacMinhDto> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: Api.test });
  return res;
};

export const createTraCuuXacMinh = async (params: ITraCuuXacMinh) => {
  const res = await localHttp.post<ITraCuuXacMinhDto>({ url: Api.getListddhc, params: params });
  return res;
};

export const updateTraCuuXacMinh = (params: IUpdateParamsTraCuuXacMinh, id: any) => {
  const res = localHttp.put({ url: `${Api.getListddhc}/${id}`, params: params });
  return res;
};

export const getByIdTraCuuXacMinh = async (id: String): Promise<ITraCuuXacMinh> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: `${Api.TraCuuXacMinh}/${id}` });
  return transformTraCuuXacMinhDtoToModel(res);
};

export const getByIdTraCuuXacMinhForAddChildren = async (id: String): Promise<ITraCuuXacMinh> => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: `${Api.getListddhc}/${id}` });
  return transformTraCuuXacMinhDtoToModelForChildren(res);
};

export const getByIdTraCuuXacMinhApiSelect = async (id: String) => {
  const res = await localHttp.get<ITraCuuXacMinhDto>({ url: `${Api.getListddhc}/${id}` });
  return res;
};

export const deleteTraCuuXacMinh = (id?: String) => {
  return localHttp.delete({ url: `${Api.getListddhc}/${id}` });
};
