import {
  ITraCuuXacMinhDto,
  IListTraCuuXacMinhDto,
  IRequestSearchTraCuuXacMinhDto,
  IRequestUpdateTraCuuXacMinhDto,
} from './dto';
import {
  ISearchParamTraCuuXacMinh,
  IListTraCuuXacMinh,
  IUpdateParamsTraCuuXacMinh,
  ITraCuuXacMinh,
} from './model';

export const transformTraCuuXacMinhDtoToModel = (dto: ITraCuuXacMinhDto): ITraCuuXacMinh => {
  return {
    id: dto.id,
    capHanhChinh: dto.capHanhChinh,
    tenDiaDanh: dto.tenDiaDanh,
    maDiaDanh: dto.maDiaDanh,
    diaDanhCapTren: dto.diaDanhCapTren,
    ghiChu: dto.ghiChu,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    level: dto.level,
    status: dto.status,
    tienTo: dto.tienTo,
    tenEN: dto.tenEN,
    tienToVtat: dto.tienToVtat,
  };
};
export const transformTraCuuXacMinhDtoToModelForChildren = (
  dto: ITraCuuXacMinhDto,
): ITraCuuXacMinh => {
  return {
    id: dto.id,
    capHanhChinh: dto.capHanhChinh,
    diaDanhCapTren: dto.id,
  };
};
export const transformListTraCuuXacMinhDtoToModel = (
  list: IListTraCuuXacMinhDto,
): IListTraCuuXacMinh => {
  return {
    ...list,
    items: list.items.map<ITraCuuXacMinh>((item) => transformTraCuuXacMinhDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamTraCuuXacMinh) => {
  const paramSearch: IRequestSearchTraCuuXacMinhDto = {
    status: dto.status,
    tenDiaDanh: dto.tenDiaDanh,
    capHanhChinh: dto.capHanhChinh,
    maDiaDanh: dto.maDiaDanh,
    ghiChu: dto.ghiChu,
    page: dto.page,
    pageSize: dto.pageSize,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformTraCuuXacMinhModelToDto = (model: ITraCuuXacMinh): ITraCuuXacMinhDto => {
  return {
    id: model.id,
    capHanhChinh: model.capHanhChinh,
    tenDiaDanh: model.tenDiaDanh,
    maDiaDanh: model.maDiaDanh,
    diaDanhCapTren: model.diaDanhCapTren,
    ghiChu: model.ghiChu,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    level: model.level,
    status: model.status,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsTraCuuXacMinh,
): IRequestUpdateTraCuuXacMinhDto => {
  const dtoTransform: IRequestUpdateTraCuuXacMinhDto = {
    ...transformTraCuuXacMinhModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
