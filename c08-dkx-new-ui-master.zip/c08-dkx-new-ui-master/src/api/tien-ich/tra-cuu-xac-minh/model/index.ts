import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface ITraCuuXacMinh extends BaseModel {
  id?: String;
  level?: String;
  tenDiaDanh?: String;
  maDiaDanh?: String;
  ghiChu?: String;
  capHanhChinh?: String;
  status?: String;
  diaDanhCapTren?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  tenEN?: String;
  tienTo?: String;
  tienToVtat?: String;
}

export type ISearchParamTraCuuXacMinh = Pick<
  ITraCuuXacMinh,
  | 'tenDiaDanh'
  | 'maDiaDanh'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ghiChu'
  | 'capHanhChinh'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsTraCuuXacMinh extends ITraCuuXacMinh {
  id: string;
}

export type IListTraCuuXacMinh = BasicFetchResult<ITraCuuXacMinh>;
