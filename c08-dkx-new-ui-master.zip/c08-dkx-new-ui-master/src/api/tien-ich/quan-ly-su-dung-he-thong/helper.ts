import { ISDHeThongDto, IListSDHeThongDto, IRequestSearchSDHeThongDto } from './dto';
import { ISearchParamSDHeThong, IListSDHeThong, ISDHeThong } from './model';

export const transformSDHeThongDtoToModel = (dto: ISDHeThongDto): ISDHeThong => {
  return {
    id: dto.id,
    donViCsgt: dto.donViCsgt,
    bienSo: dto.bienSo,
    tenCanBo: dto.tenCanBo,
    tuNgay: dto.tuNgay,
    denNgay: dto.denNgay,
    moTa: dto.moTa,
    chucNangSuDung: dto.chucNangSuDung,
    thoiGianThaoTac: dto.thoiGianThaoTac,
    page: dto.page,
    pageSize: dto.pageSize,
  };
};
export const transformListSDHeThongDtoToModel = (list: IListSDHeThongDto): IListSDHeThong => {
  return {
    ...list,
    items: list.items.map<ISDHeThong>((item) => transformSDHeThongDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamSDHeThong) => {
  const paramSearch: IRequestSearchSDHeThongDto = {
    donViCsgt: dto.donViCsgt,
    bienSo: dto.bienSo,
    tenCanBo: dto.tenCanBo,
    tuNgay: dto.tuNgay,
    moTa: dto.moTa,
    denNgay: dto.denNgay,
    chucNangSuDung: dto.chucNangSuDung,
    thoiGianThaoTac: dto.thoiGianThaoTac,
    page: dto.page,
    pageSize: dto.pageSize,
  };
  return paramSearch;
};

export const transformSDHeThongModelToDto = (model: ISDHeThong): ISDHeThongDto => {
  return {
    id: model.id,
    donViCsgt: model.donViCsgt,
    bienSo: model.bienSo,
    tenCanBo: model.tenCanBo,
    tuNgay: model.tuNgay,
    moTa: model.moTa,
    denNgay: model.denNgay,
    chucNangSuDung: model.chucNangSuDung,
    thoiGianThaoTac: model.thoiGianThaoTac,
    page: model.page,
    pageSize: model.pageSize,
  };
};
