import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface ISDHeThongDto extends BaseDto {
  id?: String;
  donViCsgt?: String;
  bienSo?: String;
  tenCanBo?: String;
  tuNgay?: String;
  denNgay?: String;
  moTa?: String;
  chucNangSuDung?: String;
  thoiGianThaoTac?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
}

export type IRequestSearchSDHeThongDto = Pick<
  ISDHeThongDto,
  | 'donViCsgt'
  | 'bienSo'
  | 'tenCanBo'
  | 'tuNgay'
  | 'denNgay'
  | 'moTa'
  | 'chucNangSuDung'
  | 'thoiGianThaoTac'
  | 'page'
  | 'pageSize'
>;
export interface IRequestUpdateSDHeThongDto extends ISDHeThongDto {
  id: String;
}

export type IListSDHeThongDto = BasicFetchResult<ISDHeThongDto>;
