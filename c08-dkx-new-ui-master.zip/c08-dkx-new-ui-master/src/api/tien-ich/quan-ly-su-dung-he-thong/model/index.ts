import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface ISDHeThong extends BaseModel {
  donViCsgt?: String;
  id?: String;
  bienSo?: String;
  tenCanBo?: String;
  tuNgay?: String;
  denNgay?: String;
  moTa?: String;
  chucNangSuDung?: String;
  thoiGianThaoTac?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
}

export type ISearchParamSDHeThong = Pick<
  ISDHeThong,
  | 'donViCsgt'
  | 'bienSo'
  | 'tenCanBo'
  | 'tuNgay'
  | 'denNgay'
  | 'moTa'
  | 'chucNangSuDung'
  | 'thoiGianThaoTac'
  | 'page'
  | 'pageSize'
>;

export type IListSDHeThong = BasicFetchResult<ISDHeThong>;
