import { localHttp } from '/@/utils/http/axios';

import { ISDHeThongDto, IListSDHeThongDto } from './dto';
import { ISearchParamSDHeThong, IListSDHeThong, ISDHeThong } from './model';
import {
  transformSDHeThongDtoToModel,
  transformListSDHeThongDtoToModel,
  transformSearchParamsToDto,
} from './helper';
enum Api {
  main = '/v1/quan-ly-sd-he-thong',
  download = '/v1/quan-ly-sd-he-thong/export/excel',
}

export const getListSDHeThong = async (params: ISearchParamSDHeThong): Promise<IListSDHeThong> => {
  const res = await localHttp.get<IListSDHeThongDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListSDHeThongDtoToModel(res);
};

export const getByIdSDHeThong = async (id: string): Promise<ISDHeThong> => {
  const res = await localHttp.get<ISDHeThongDto>({ url: `${Api.main}/${id}` });
  return transformSDHeThongDtoToModel(res);
};

export const exportExcel = async (params: ISearchParamSDHeThong) => {
  await localHttp.downloadFileExcel({
    url: Api.download,
    params: transformSearchParamsToDto(params),
  });
};
