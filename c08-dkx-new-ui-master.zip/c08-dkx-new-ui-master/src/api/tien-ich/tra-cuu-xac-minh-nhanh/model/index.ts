import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface ITraCuuXacMinhNhanh extends BaseModel {
  id?: String;
  level?: String;
  tenDiaDanh?: String;
  maDiaDanh?: String;
  ghiChu?: String;
  capHanhChinh?: String;
  status?: String;
  diaDanhCapTren?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  tenEN?: String;
  tienTo?: String;
  tienToVtat?: String;
}

export type ISearchParamTraCuuXacMinhNhanh = Pick<
  ITraCuuXacMinhNhanh,
  | 'tenDiaDanh'
  | 'maDiaDanh'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ghiChu'
  | 'capHanhChinh'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IUpdateParamsTraCuuXacMinhNhanh extends ITraCuuXacMinhNhanh {
  id: string;
}

export type IListTraCuuXacMinhNhanh = BasicFetchResult<ITraCuuXacMinhNhanh>;
