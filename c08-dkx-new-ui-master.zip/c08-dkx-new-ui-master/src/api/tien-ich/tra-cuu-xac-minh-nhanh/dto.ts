import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface ITraCuuXacMinhNhanhDto extends BaseDto {
  id?: String;
  level?: String;
  tenDiaDanh?: String;
  maDiaDanh?: String;
  ghiChu?: String;
  capHanhChinh?: String;
  status?: String;
  diaDanhCapTren?: String;
  message?: String;
  page?: String;
  pageSize?: String;
  tenEN?: String;
  tienTo?: String;
  tienToVtat?: String;
}

export type IRequestSearchTraCuuXacMinhNhanhDto = Pick<
  ITraCuuXacMinhNhanhDto,
  | 'tenDiaDanh'
  | 'maDiaDanh'
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ghiChu'
  | 'capHanhChinh'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
>;
export interface IRequestUpdateTraCuuXacMinhNhanhDto extends ITraCuuXacMinhNhanhDto {
  id: string;
}

export type IListTraCuuXacMinhNhanhDto = BasicFetchResult<ITraCuuXacMinhNhanhDto>;
