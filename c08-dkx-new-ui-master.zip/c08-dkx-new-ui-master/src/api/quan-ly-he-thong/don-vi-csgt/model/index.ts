import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IDonViCsgt extends BaseModel {
  status?: string;
  id?: string;
  page?: number;
  pageSize?: number;
  message?: string;
  tenDonVi?: string;
  maDonVi?: string;
  capDonVi?: number;
  maDonViCsgtCapTren?: number;
  diaChi?: string;
  maDiaDanhHanhChinh?: string;
  tenDiaDanhHanhChinh?: string;
  khoangCachIn?: number;
  children?: IDonViCsgt[];
  ghiChu?: string;

  maKhuKinhTe?: Boolean;
  maKhuKinhTeId?: string;
}

export type ISearchParamDonViCsgt = Pick<
  IDonViCsgt,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'tenDonVi'
  | 'maDonVi'
  | 'createdBy'
  | 'createdDate'
  | 'updatedBy'
  | 'updatedDate'
  | 'maKhuKinhTeId'
>;
export interface IUpdateParamsDonViCsgt extends IDonViCsgt {
  id: string;
}

export type IListDonViCsgt = BasicFetchResult<IDonViCsgt>;

export interface IDiaDiemDk extends BaseModel {
  ma?: string;
  ten?: string;
}
