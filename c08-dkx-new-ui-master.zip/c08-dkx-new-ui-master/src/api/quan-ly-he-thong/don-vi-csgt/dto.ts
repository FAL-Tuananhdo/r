import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IDonViCsgtDto extends BaseDto {
  status?: string;
  id?: string;
  page?: number;
  pageSize?: number;
  message?: string;
  tenDonVi?: string;
  maDonVi?: string;
  capDonVi?: number;
  maDonViCsgtCapTren?: number;
  diaChi?: string;
  maDiaDanhHanhChinh?: string;
  tenDiaDanhHanhChinh?: string;
  khoangCachIn?: number;
  children?: IDonViCsgtDto[];
  ghiChu?: string;

  maKhuKinhTe?: Boolean;
  maKhuKinhTeId?: string;
}

export type IRequestSearchDonViCsgtDto = Pick<
  IDonViCsgtDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'tenDonVi'
  | 'maDonVi'
  | 'createdBy'
  | 'createdDate'
  | 'updatedBy'
  | 'updatedDate'
>;
export interface IRequestUpdateDonViCsgtDto extends IDonViCsgtDto {
  id: string;
}

export type IListDonViCsgtDto = BasicFetchResult<IDonViCsgtDto>;
