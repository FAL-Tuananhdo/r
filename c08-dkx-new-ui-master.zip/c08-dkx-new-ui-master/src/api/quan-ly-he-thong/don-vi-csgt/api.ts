import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IDonViCsgtDto, IListDonViCsgtDto } from './dto';
import {
  ISearchParamDonViCsgt,
  IListDonViCsgt,
  IUpdateParamsDonViCsgt,
  IDonViCsgt,
  IDiaDiemDk,
} from './model';
import {
  transformDonViCsgtDtoToModel,
  transformListDonViCsgtDtoToModel,
  transformSearchParamsToDto,
} from './helper';
import { downloadFileExcel } from '/@/hooks/functionHelper/downloadFileExcel';

enum Api {
  main = '/v1/don-vi-csgt',
  getList = '/v1/don-vi-csgt/getList',
  exportExcel = '/v1/don-vi-csgt/export/excel',
  getListDiaDiemDk = '/v1/o-bao-cao/get-dia-diem-dk-by-don-vi',
}

export const getListDonViCsgt = async (params: ISearchParamDonViCsgt): Promise<IListDonViCsgt> => {
  const res = await localHttp.get<IListDonViCsgtDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListDonViCsgtDtoToModel(res);
};

export const getListDiaDiemDk = async (donVi: any): Promise<IDiaDiemDk[]> => {
  const res = (await localHttp.get<IDiaDiemDk>({ url: Api.getListDiaDiemDk, params: donVi })) as [];
  if (!donVi['donVi']) return res;
  return res.filter((s) => s['maDonViCsgt'] === donVi['donVi']);
};
// `${Api.getListDiaDiemDk}?donVi=${ma.ma}`;
export const exportExcelDonViCsgt = async (params: ISearchParamDonViCsgt): Promise<string> => {
  const res = await localHttpDownload.get<string>({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
  downloadFileExcel(res, 'danh_sach_don_vi_CSGT');
  return res;
};

export const getListDonViCsgtSelect = async (params?: ISearchParamDonViCsgt) => {
  const res = await localHttp.get<IDonViCsgt>({ url: Api.getList, params: params });
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const updateDonViCsgt = (params: IUpdateParamsDonViCsgt, id: any) => {
  const res = localHttp.put({ url: `${Api.main}/${id}`, params: params });
  return res;
};
export const getData = async () => {
  const res = await getByIdDonViCsgt('1');
  return res;
};

export const getByIdDonViCsgt = async (id: String): Promise<IDonViCsgt> => {
  const res = await localHttp.get<IDonViCsgtDto>({ url: `${Api.main}/${id}` });
  return transformDonViCsgtDtoToModel(res);
};

export const deleteDonViCsgt = (id?: String) => {
  return localHttp.delete({ url: `${Api.main}/${id}` });
};
