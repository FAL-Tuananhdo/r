import {
  IDonViCsgtDto,
  IListDonViCsgtDto,
  IRequestSearchDonViCsgtDto,
  IRequestUpdateDonViCsgtDto,
} from './dto';
import { ISearchParamDonViCsgt, IListDonViCsgt, IUpdateParamsDonViCsgt, IDonViCsgt } from './model';

export const transformDonViCsgtDtoToModel = (dto: IDonViCsgtDto): IDonViCsgt => {
  return {
    id: dto.id,
    tenDonVi: dto.tenDonVi,
    maDonVi: dto.maDonVi,
    capDonVi: dto.capDonVi,
    maDonViCsgtCapTren: dto.maDonViCsgtCapTren,
    maDiaDanhHanhChinh: dto.maDiaDanhHanhChinh,
    tenDiaDanhHanhChinh: dto.tenDiaDanhHanhChinh,
    diaChi: dto.diaChi,
    ghiChu: dto.ghiChu,
    status: dto.status,
    khoangCachIn: dto.khoangCachIn,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
  };
};
export const transformListDonViCsgtDtoToModel = (list: IListDonViCsgtDto): IListDonViCsgt => {
  return {
    ...list,
    items: list.items.map<IDonViCsgt>((item) => transformDonViCsgtDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamDonViCsgt) => {
  const paramSearch: IRequestSearchDonViCsgtDto = {
    tenDonVi: dto.tenDonVi,
    maDonVi: dto.maDonVi,
    status: dto.status,
    createdBy: dto.createdBy,
    createdDate: dto.createdDate,
    updatedBy: dto.updatedBy,
    updatedDate: dto.updatedDate,
    page: dto.page,
    pageSize: dto.pageSize,
  };
  return paramSearch;
};

export const transformDonViCsgtModelToDto = (model: IDonViCsgt): IDonViCsgtDto => {
  return {
    id: model.id,
    tenDonVi: model.tenDonVi,
    maDonVi: model.maDonVi,
    capDonVi: model.capDonVi,
    maDonViCsgtCapTren: model.maDonViCsgtCapTren,
    maDiaDanhHanhChinh: model.maDiaDanhHanhChinh,
    tenDiaDanhHanhChinh: model.tenDiaDanhHanhChinh,
    diaChi: model.diaChi,
    ghiChu: model.ghiChu,
    status: model.status,
    khoangCachIn: model.khoangCachIn,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsDonViCsgt,
): IRequestUpdateDonViCsgtDto => {
  const dtoTransform: IRequestUpdateDonViCsgtDto = {
    ...transformDonViCsgtModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
