import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IQuanLyLoaiXeVaSeri extends BaseModel {
  id?: string;
  status?: string;
  page?: Number;
  pageSize?: Number;
  message?: string;

  maLoaiXe?: string;
  tenMaLoaiXe?: string;
  dangKyTam?: string;
  mauBien?: string;
  ghiChu?: string;
  otoSeriChuId?: string;
  tenOtoSeriChu?: string;

  // search
  loaiXe?: string;
  otoSeriChu?: string;
  seriChu?: string;
}

export type ISearchParamQuanLyLoaiXeVaSeri = Pick<
  IQuanLyLoaiXeVaSeri,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'mauBien'
  | 'ghiChu'
  | 'loaiXe'
  | 'seriChu'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
  | 'dangKyTam'
>;
export interface IUpdateParamsQuanLyLoaiXeVaSeri extends IQuanLyLoaiXeVaSeri {
  id: string;
}

export type IListQuanLyLoaiXeVaSeri = BasicFetchResult<IQuanLyLoaiXeVaSeri>;
