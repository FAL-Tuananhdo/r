import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IQuanLyLoaiXeVaSeriDto extends BaseDto {
  id?: string;
  status?: string;
  page?: Number;
  pageSize?: Number;
  message?: string;

  maLoaiXe?: string;
  tenMaLoaiXe?: string;
  dangKyTam?: string;
  mauBien?: string;
  ghiChu?: string;
  otoSeriChuId?: string;
  tenOtoSeriChu?: string;

  // search
  loaiXe?: string;
  otoSeriChu?: string;
  seriChu?: string;
}

export type IRequestSearchQuanLyLoaiXeVaSeriDto = Pick<
  IQuanLyLoaiXeVaSeriDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'mauBien'
  | 'ghiChu'
  | 'loaiXe'
  | 'seriChu'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
  | 'dangKyTam'
>;
export interface IRequestUpdateQuanLyLoaiXeVaSeriDto extends IQuanLyLoaiXeVaSeriDto {
  id: string;
}

export type IListQuanLyLoaiXeVaSeriDto = BasicFetchResult<IQuanLyLoaiXeVaSeriDto>;
