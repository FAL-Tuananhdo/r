import {
  IQuanLyLoaiXeVaSeriDto,
  IListQuanLyLoaiXeVaSeriDto,
  IRequestSearchQuanLyLoaiXeVaSeriDto,
  IRequestUpdateQuanLyLoaiXeVaSeriDto,
} from './dto';
import {
  ISearchParamQuanLyLoaiXeVaSeri,
  IListQuanLyLoaiXeVaSeri,
  IUpdateParamsQuanLyLoaiXeVaSeri,
  IQuanLyLoaiXeVaSeri,
} from './model';

export const transformQuanLyLoaiXeVaSeriDtoToModel = (
  dto: IQuanLyLoaiXeVaSeriDto,
): IQuanLyLoaiXeVaSeri => {
  return {
    id: dto.id,
    mauBien: dto.mauBien,
    ghiChu: dto.ghiChu,
    maLoaiXe: dto.maLoaiXe,
    tenMaLoaiXe: dto.tenMaLoaiXe,
    otoSeriChuId: dto.otoSeriChuId,
    tenOtoSeriChu: dto.tenOtoSeriChu,
    dangKyTam: dto.dangKyTam,
    status: dto.status,
    message: dto.message,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
  };
};
export const transformListQuanLyLoaiXeVaSeriDtoToModel = (
  list: IListQuanLyLoaiXeVaSeriDto,
): IListQuanLyLoaiXeVaSeri => {
  return {
    ...list,
    items: list.items.map<IQuanLyLoaiXeVaSeri>((item) =>
      transformQuanLyLoaiXeVaSeriDtoToModel(item),
    ),
  };
};
export const transformSearchParamsToDto = (model: ISearchParamQuanLyLoaiXeVaSeri) => {
  const paramSearch: IRequestSearchQuanLyLoaiXeVaSeriDto = {
    mauBien: model.mauBien,
    ghiChu: model.ghiChu,
    loaiXe: model.loaiXe,
    seriChu: model.seriChu,
    dangKyTam: model.dangKyTam,
    status: model.status,
    page: model.page,
    pageSize: model.pageSize,
    createdDate: model.createdDate,
    updatedDate: model.updatedDate,
    createdBy: model.createdBy,
    updatedBy: model.updatedBy,
  };
  return paramSearch;
};

export const transformQuanLyLoaiXeVaSeriModelToDto = (
  model: IQuanLyLoaiXeVaSeri,
): IQuanLyLoaiXeVaSeriDto => {
  return {
    id: model.id,
    mauBien: model.mauBien,
    ghiChu: model.ghiChu,
    maLoaiXe: model.maLoaiXe,
    otoSeriChuId: model.otoSeriChuId,
    dangKyTam: model.dangKyTam,
    status: model.status,
    message: model.message,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsQuanLyLoaiXeVaSeri,
): IRequestUpdateQuanLyLoaiXeVaSeriDto => {
  const dtoTransform: IRequestUpdateQuanLyLoaiXeVaSeriDto = {
    ...transformQuanLyLoaiXeVaSeriModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
