import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IQuanLyLoaiXeVaSeriDto, IListQuanLyLoaiXeVaSeriDto } from './dto';
import {
  ISearchParamQuanLyLoaiXeVaSeri,
  IListQuanLyLoaiXeVaSeri,
  IUpdateParamsQuanLyLoaiXeVaSeri,
  IQuanLyLoaiXeVaSeri,
} from './model';
import {
  transformQuanLyLoaiXeVaSeriDtoToModel,
  transformListQuanLyLoaiXeVaSeriDtoToModel,
  transformSearchParamsToDto,
} from './helper';

enum Api {
  main = '/v1/quan-ly-loai-xe-va-seri',
  exportExcel = '/v1/quan-ly-loai-xe-va-seri/export/excel',
}

export const getListQuanLyLoaiXeVaSeri = async (
  params: ISearchParamQuanLyLoaiXeVaSeri,
): Promise<IListQuanLyLoaiXeVaSeri> => {
  const res = await localHttp.get<IListQuanLyLoaiXeVaSeriDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  return transformListQuanLyLoaiXeVaSeriDtoToModel(res);
};

export const exportExcelLoaiXeVaSeri = async (params: ISearchParamQuanLyLoaiXeVaSeri) => {
  localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createQuanLyLoaiXeVaSeri = async (params: IQuanLyLoaiXeVaSeri) => {
  const res = await localHttp.post<IQuanLyLoaiXeVaSeriDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateQuanLyLoaiXeVaSeri = (params: IUpdateParamsQuanLyLoaiXeVaSeri, id) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdQuanLyLoaiXeVaSeri = async (id: string): Promise<IQuanLyLoaiXeVaSeri> => {
  const res = await localHttp.get<IQuanLyLoaiXeVaSeriDto>({
    url: `${Api.main}/${id}`,
  });
  return transformQuanLyLoaiXeVaSeriDtoToModel(res);
};

export const deleteQuanLyLoaiXeVaSeri = (id?: string) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};
