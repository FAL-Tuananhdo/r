import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IDiemDangKy extends BaseModel {
  status?: string;
  id?: string;
  page?: Number;
  pageSize?: Number;
  message?: String;
  ten?: string;
  maDiemDangKy?: string;
  diaChi?: string;
  loaiPTDK?: string;

  maDonViCsgt?: string;
  tenDonViCsgt?: string;

  maDiaDanhHanhChinh?: string;
  tenDiaDanhHanhChinh?: string;

  soLuongBien?: String;
  dong1?: String;
  dong2?: String;
  dong3?: String;
  tcxmTieuDe1?: String;
  tcxmTieuDe2?: String;

  capHanhChinh?: string;
  maTinhThanh?: string;
  tenTinhThanh?: string;
  maQuanHuyen?: string;
  tenQuanHuyen?: string;
  maDiemDangKyMoi?: string;
  diaDanhHanhChinh?: string;

  chucDanhNk1?: string;
  chucDanhNk2?: string;
  chucDanhNk3?: string;
  tenNk1?: string;
  tenNk2?: string;
  tenNk3?: string;
}
export interface diemDangKyMoi {
  maDiemDangKyMoi?: string;
}

export type ISearchParamDiemDangKy = Pick<
  IDiemDangKy,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ten'
  | 'diaChi'
  | 'maDonViCsgt'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'capHanhChinh'
  | 'maDiemDangKy'
  | 'diaDanhHanhChinh'
  | 'loaiPTDK'
>;
export interface IUpdateParamsDiemDangKy extends IDiemDangKy {
  id: string;
}

export type IListDiemDangKy = BasicFetchResult<IDiemDangKy>;
