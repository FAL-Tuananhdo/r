import { localHttp } from '/@/utils/http/axios';

import { IDiemDangKyDto, IListDiemDangKyDto } from './dto';
import {
  ISearchParamDiemDangKy,
  IListDiemDangKy,
  IUpdateParamsDiemDangKy,
  IDiemDangKy,
} from './model';
import {
  transformDiemDangKyDtoToModel,
  transformListDiemDangKyDtoToModel,
  transformSearchParamsToDto,
} from './helper';
import { useUserStore } from '/@/store/modules/user';

enum Api {
  main = '/v1/diem-dang-ky',
  getList = '/v1/diem-dang-ky/getList',
  exportExcel = '/v1/diem-dang-ky/export/excel',
  layMaDdkMoi = '/v1/diem-dang-ky/getMaDiemDangKy',
  checkSuDung = '/v1/diem-dang-ky/check-su-dung',
}

export const getListDiemDangKy = async (
  params: ISearchParamDiemDangKy,
): Promise<IListDiemDangKy> => {
  const res = await localHttp.get<IListDiemDangKyDto>({
    url: Api.main,
    params: transformSearchParamsToDto({
      ...params,
      capHanhChinh: useUserStore().getUserInfo.capHanhChinhDdk,
    }),
  });
  return transformListDiemDangKyDtoToModel(res);
};

export const getMaDiemDangKyMoi = async (params: ISearchParamDiemDangKy): Promise<IDiemDangKy> => {
  const res = await localHttp.get<IDiemDangKy>({
    url: Api.layMaDdkMoi,
    params: transformSearchParamsToDto(params),
  });

  return res;
};
export const checkSuDungDdk = async (params: ISearchParamDiemDangKy): Promise<IDiemDangKy> => {
  const res = await localHttp.get<IDiemDangKy>({
    url: Api.checkSuDung,
    params: transformSearchParamsToDto(params),
  });

  return res;
};

export const exportExcelDiemDangKy = async (params: ISearchParamDiemDangKy) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto({
      ...params,
      capHanhChinh: useUserStore().getUserInfo.capHanhChinhDdk,
    }),
  });
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createDiemDangKy = async (params: IDiemDangKy) => {
  const res = await localHttp.post<IDiemDangKyDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateDiemDangKy = (params: IUpdateParamsDiemDangKy, id: any) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdDiemDangKy = async (id: String): Promise<IDiemDangKy> => {
  const res = await localHttp.get<IDiemDangKyDto>({
    url: `${Api.main}/${id}`,
  });
  return transformDiemDangKyDtoToModel(res);
};

export const deleteDiemDangKy = (id?: String) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};

export const getListDiemDangKySelect = async (
  params: ISearchParamDiemDangKy,
): Promise<IDiemDangKy> => {
  const res = await localHttp.get<IDiemDangKy>({
    url: Api.getList,
    params: transformSearchParamsToDto(params),
  });
  return res;
};
