import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IDiemDangKyDto extends BaseDto {
  status?: string;
  id?: string;
  page?: Number;
  pageSize?: Number;
  message?: String;
  ten?: string;
  maDiemDangKy?: string;
  diaChi?: string;
  loaiPTDK?: string;

  maDonViCsgt?: string;
  tenDonViCsgt?: string;

  maDiaDanhHanhChinh?: string;
  tenDiaDanhHanhChinh?: string;

  soLuongBien?: String;
  dong1?: String;
  dong2?: String;
  dong3?: String;
  tcxmTieuDe1?: String;
  tcxmTieuDe2?: String;

  capHanhChinh?: string;
  maTinhThanh?: string;
  tenTinhThanh?: string;
  maQuanHuyen?: string;
  tenQuanHuyen?: string;
  maDiemDangKyMoi?: string;
  diaDanhHanhChinh?: string;

  chucDanhNk1?: string;
  chucDanhNk2?: string;
  chucDanhNk3?: string;
  tenNk1?: string;
  tenNk2?: string;
  tenNk3?: string;
}

export type IRequestSearchDiemDangKyDto = Pick<
  IDiemDangKyDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'ten'
  | 'diaChi'
  | 'maDonViCsgt'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'capHanhChinh'
  | 'maDiemDangKy'
  | 'diaDanhHanhChinh'
  | 'loaiPTDK'
>;
export interface IRequestUpdateDiemDangKyDto extends IDiemDangKyDto {
  id: string;
}

export type IListDiemDangKyDto = BasicFetchResult<IDiemDangKyDto>;
