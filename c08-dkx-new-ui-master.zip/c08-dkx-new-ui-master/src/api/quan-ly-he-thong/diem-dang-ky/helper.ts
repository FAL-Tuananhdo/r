import {
  IDiemDangKyDto,
  IListDiemDangKyDto,
  IRequestSearchDiemDangKyDto,
  IRequestUpdateDiemDangKyDto,
} from './dto';
import {
  ISearchParamDiemDangKy,
  IListDiemDangKy,
  IUpdateParamsDiemDangKy,
  IDiemDangKy,
} from './model';

export const transformDiemDangKyDtoToModel = (dto: IDiemDangKyDto): IDiemDangKy => {
  return {
    id: dto.id,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    ten: dto.ten,
    maDiemDangKy: dto.maDiemDangKy,
    diaChi: dto.diaChi,
    loaiPTDK: dto.loaiPTDK,
    maDonViCsgt: dto.maDonViCsgt,
    tenDonViCsgt: dto.tenDonViCsgt,
    soLuongBien: dto.soLuongBien,
    dong1: dto.dong1,
    dong2: dto.dong2,
    dong3: dto.dong3,
    tcxmTieuDe1: dto.tcxmTieuDe1,
    tcxmTieuDe2: dto.tcxmTieuDe2,

    capHanhChinh: dto.capHanhChinh,
    maTinhThanh: dto.maTinhThanh,
    tenTinhThanh: dto.tenTinhThanh,
    maQuanHuyen: dto.maQuanHuyen,
    tenQuanHuyen: dto.tenQuanHuyen,
    maDiaDanhHanhChinh: dto.maDiaDanhHanhChinh,
    tenDiaDanhHanhChinh: dto.tenDiaDanhHanhChinh,

    chucDanhNk1: dto.chucDanhNk1,
    chucDanhNk2: dto.chucDanhNk2,
    chucDanhNk3: dto.chucDanhNk3,
    tenNk1: dto.tenNk1,
    tenNk2: dto.tenNk2,
    tenNk3: dto.tenNk3,
  };
};
export const transformListDiemDangKyDtoToModel = (list: IListDiemDangKyDto): IListDiemDangKy => {
  return {
    ...list,
    items: list.items.map<IDiemDangKy>((item) => transformDiemDangKyDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamDiemDangKy) => {
  const paramSearch: IRequestSearchDiemDangKyDto = {
    ten: dto.ten,
    diaChi: dto.diaChi,
    status: dto.status,
    page: dto.page,
    pageSize: dto.pageSize,
    maDonViCsgt: dto.maDonViCsgt,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    capHanhChinh: dto.capHanhChinh,
    maDiemDangKy: dto.maDiemDangKy,
    diaDanhHanhChinh: dto.diaDanhHanhChinh,
    loaiPTDK: dto.loaiPTDK,
  };
  return paramSearch;
};

export const transformDiemDangKyModelToDto = (model: IDiemDangKy): IDiemDangKyDto => {
  return {
    id: model.id,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    ten: model.ten,
    diaChi: model.diaChi,
    loaiPTDK: model.loaiPTDK,
    maDonViCsgt: model.maDonViCsgt,
    maDiaDanhHanhChinh: model.maDiaDanhHanhChinh,
    soLuongBien: model.soLuongBien,
    dong1: model.dong1,
    dong2: model.dong2,
    dong3: model.dong3,
    tcxmTieuDe1: model.tcxmTieuDe1,
    tcxmTieuDe2: model.tcxmTieuDe1,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsDiemDangKy,
): IRequestUpdateDiemDangKyDto => {
  const dtoTransform: IRequestUpdateDiemDangKyDto = {
    ...transformDiemDangKyModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
