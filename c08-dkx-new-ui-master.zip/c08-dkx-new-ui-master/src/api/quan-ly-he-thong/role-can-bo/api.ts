import { localHttp } from '/@/utils/http/axios';

import { IRoleTable } from './model';

enum Api {
  main = '/v1/role',
  getList = '/v1/role/getList',
}

export const getListRoleSelect = async (): Promise<IRoleTable> => {
  const res = await localHttp.get<IRoleTable>({
    url: Api.getList,
  });
  return res;
};
