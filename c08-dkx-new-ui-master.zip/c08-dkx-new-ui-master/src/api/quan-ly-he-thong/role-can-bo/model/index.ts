import { BaseModel } from '/@/api/model/baseModel';

export interface IRoleTable extends BaseModel {
  id?: String;
  tenRole?: String;
  ghiChu?: String;
  roleMacDinh?: String;
  status?: String;
}
