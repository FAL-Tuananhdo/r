import { localHttp, localHttpDownload } from '/@/utils/http/axios';

import { IBangThamSoDto, IListBangThamSoDto } from './dto';
import {
  ISearchParamBangThamSo,
  IListBangThamSo,
  IUpdateParamsBangThamSo,
  IBangThamSo,
} from './model';
import {
  transformBangThamSoDtoToModel,
  transformListBangThamSoDtoToModel,
  transformSearchParamsToDto,
} from './helper';
import { downloadFileExcel } from '/@/hooks/functionHelper/downloadFileExcel';
export let dataInput: any[];

export const getDataInput = () => {
  return dataInput;
};
enum Api {
  main = '/v1/bang-tham-so',
  exportExcel = '/v1/bang-tham-so/export/excel',
  trangThaiKichHoat = '/v1/bang-tham-so/trang-thai-kich-hoat',
  kiemSoatSoKhung = '/v1/bang-tham-so/kiem-soat-so-khung',
  kiemSoatSoMay = '/v1/bang-tham-so/kiem-soat-so-may',
  caNhanToChuc = '/v1/bang-tham-so/canhan-tochuc',
  coBienNghiepVu = '/v1/bang-tham-so/cobien-nghiepvu',
  dangKyTam = '/v1/bang-tham-so/dang-ky-tam',
  nhapLieuTheoMau = '/v1/bang-tham-so/nhap-lieu-theo-mau',
  inTheoMau = '/v1/bang-tham-so/in-theo-mau',
  loaiThamSo = '/v1/bang-tham-so/loai-tham-so',
  maMauBien = '/v1/bang-tham-so/ma-mau-bien',
  seriChuTrongNuoc = '/v1/bang-tham-so/get?vungDuLieu=SERI CHU TRONG NUOC',
  trangThaiCanBo = '/v1/bang-tham-so/get?vungDuLieu=TRANG THAI CAN BO',
  loaiPTDK = '/v1/bang-tham-so/get?vungDuLieu=LOAI PHUONG TIEN',
  truongPhongDuyetCanBo = '/v1/bang-tham-so/get?vungDuLieu=TRUONG_PHONG_DUYET_CANBO',
  cucTruongDuyetCanBo = '/v1/bang-tham-so/get?vungDuLieu=CUC_TRUONG_DUYET_CANBO',
  QuocGiaToChucQuocTe = '/v1/bang-tham-so/get?vungDuLieu=QUOCGIA TOCHUCQT',
  loaiDangKyTam = '/v1/bang-tham-so/get?vungDuLieu=LOAI_DANG_KY_TAM',
  maNguonGoc = '/v1/bang-tham-so/get?vungDuLieu=MA_NGUON_GOC',
  maMauSon = '/v1/bang-tham-so/get?vungDuLieu=MA_MAU_SON',
  trangThaiHoSo = '/v1/bang-tham-so/get?vungDuLieu=TRANG_THAI_HO_SO',
  trangThaiDk = '/v1/bang-tham-so/get?vungDuLieu=TRANG_THAI_DANG_KY',
  trangThaiXe = '/v1/bang-tham-so/get?vungDuLieu=TRANG_THAI_XE',
  loaiCaiTao = '/v1/bang-tham-so/get?vungDuLieu=MA_CAI_TAO',
  loaiDoiCap = '/v1/bang-tham-so/get?vungDuLieu=LY_DO_DOI_CAP',
}

export const getListBangThamSo = async (
  params: ISearchParamBangThamSo,
): Promise<IListBangThamSo> => {
  const res = await localHttp.get<IListBangThamSoDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });
  dataExcel = res.items;
  return transformListBangThamSoDtoToModel(res);
};

export const exportExcelBangThamSo = async (params: ISearchParamBangThamSo) => {
  const res = await localHttpDownload.get<string>({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
  downloadFileExcel(res, 'danh_sach_tham_so_he_thong');
  return res;
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const createBangThamSo = async (params: IBangThamSo) => {
  const res = await localHttp.post<IBangThamSoDto>({
    url: Api.main,
    params: params,
  });
  return res;
};

export const updateBangThamSo = (params: IUpdateParamsBangThamSo, id: any) => {
  const res = localHttp.put({
    url: `${Api.main}/${id}`,
    params: params,
  });
  return res;
};

export const getByIdBangThamSo = async (id: String): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSoDto>({
    url: `${Api.main}/${id}`,
  });
  return transformBangThamSoDtoToModel(res);
};

export const deleteBangThamSo = (id?: String) => {
  return localHttp.delete({
    url: `${Api.main}/${id}`,
  });
};

export const getListTrangThaiKichHoat = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.trangThaiKichHoat });
  return res;
};

export const getListKiemSoatSoKhung = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.kiemSoatSoKhung });
  return res;
};

export const getListKiemSoatSoMay = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.kiemSoatSoMay });
  return res;
};

export const getListLoaiDoiTuong = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.caNhanToChuc });
  return res;
};

export const getListBienNghiepVu = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.coBienNghiepVu });
  return res;
};
export const getListDangKyTam = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.dangKyTam });
  return res;
};
export const getListNhapLieuTheoMau = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.nhapLieuTheoMau });
  return res;
};

export const getListInTheoMau = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.inTheoMau });
  return res;
};
export const getListLoaiThamSo = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.loaiThamSo });
  return res;
};
export const getListMaMauBien = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.maMauBien });
  return res;
};

export const getListLoaiSeriChu = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.seriChuTrongNuoc });
  return res;
};

export const getListTrangThaiCanBo = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.trangThaiCanBo });
  return res;
};

export const getListLoaiPhuongTien = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.loaiPTDK });
  return res;
};

export const getListTruongphongDuyetCanBo = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.truongPhongDuyetCanBo });
  return res;
};

export const getListCucTruongDuyetCanBo = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.cucTruongDuyetCanBo });
  return res;
};

export const getListQuocGiaToChucQuocTe = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.QuocGiaToChucQuocTe });
  return res;
};

export const getListDangKyTamDkx = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.loaiDangKyTam });
  return res;
};

export const getListMaNguonGoc = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.maNguonGoc });
  return res;
};

export const getListMaMauSon = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.maMauSon });
  return res;
};

export const getListTrangThaiHoSo = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.trangThaiHoSo });
  return res;
};

export const getListTrangThaiDk = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.trangThaiDk });
  return res;
};

export const getListTrangThaiXe = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.trangThaiXe });
  return res;
};

export const getListLoaiCaiTao = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.loaiCaiTao });
  return res;
};

export const getListLoaiDoiCap = async (): Promise<IBangThamSo> => {
  const res = await localHttp.get<IBangThamSo>({ url: Api.loaiDoiCap });
  return res;
};
