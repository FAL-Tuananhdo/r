import {
  IBangThamSoDto,
  IListBangThamSoDto,
  IRequestSearchBangThamSoDto,
  IRequestUpdateBangThamSoDto,
} from './dto';
import {
  ISearchParamBangThamSo,
  IListBangThamSo,
  IUpdateParamsBangThamSo,
  IBangThamSo,
} from './model';

export const transformListBangThamSoDtoToModel = (list: IListBangThamSoDto): IListBangThamSo => {
  return {
    ...list,
    items: list.items.map<IBangThamSo>((item) => transformBangThamSoDtoToModel(item)),
  };
};

export const transformBangThamSoDtoToModel = (dto: IBangThamSoDto): IBangThamSo => {
  return {
    id: dto.id,
    vungDuLieu: dto.vungDuLieu,
    maThamSo: dto.maThamSo,
    dienGiai: dto.dienGiai,
    thamSoNguoiDung: dto.thamSoNguoiDung,
    bangThamSoId: dto.bangThamSoId,
    sapXep: dto.sapXep,
    ghiChu: dto.ghiChu,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    tenUpdatedBy: dto.tenUpdatedBy,
    tenCreatedBy: dto.tenCreatedBy,
  };
};

export const transformSearchParamsToDto = (dto: ISearchParamBangThamSo) => {
  const paramSearch: IRequestSearchBangThamSoDto = {
    vungDuLieu: dto.vungDuLieu,
    maThamSo: dto.maThamSo,
    dienGiai: dto.dienGiai,
    status: dto.status,
    thamSoNguoiDung: dto.thamSoNguoiDung,
    page: dto.page,
    pageSize: dto.pageSize,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
  };
  return paramSearch;
};

export const transformBangThamSoModelToDto = (model: IBangThamSo): IBangThamSoDto => {
  return {
    id: model.id,
    vungDuLieu: model.vungDuLieu,
    maThamSo: model.maThamSo,
    dienGiai: model.dienGiai,
    thamSoNguoiDung: model.thamSoNguoiDung,
    bangThamSoId: model.bangThamSoId,
    ghiChu: model.ghiChu,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsBangThamSo,
): IRequestUpdateBangThamSoDto => {
  const dtoTransform: IRequestUpdateBangThamSoDto = {
    ...transformBangThamSoModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
