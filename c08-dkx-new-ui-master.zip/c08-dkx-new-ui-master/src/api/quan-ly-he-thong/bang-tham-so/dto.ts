import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IBangThamSoDto extends BaseDto {
  vungDuLieu?: String;
  maThamSo?: String;
  dienGiai?: String;
  status?: string;
  thamSoNguoiDung?: Number;
  id?: String;
  bangThamSoId?: Number;
  sapXep?: String;
  ghiChu?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
}

export type IRequestSearchBangThamSoDto = Pick<
  IBangThamSoDto,
  | 'page'
  | 'pageSize'
  | 'dienGiai'
  | 'vungDuLieu'
  | 'maThamSo'
  | 'status'
  | 'thamSoNguoiDung'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
>;
export interface IRequestUpdateBangThamSoDto extends IBangThamSoDto {
  id: String;
}

export type IListBangThamSoDto = BasicFetchResult<IBangThamSoDto>;
