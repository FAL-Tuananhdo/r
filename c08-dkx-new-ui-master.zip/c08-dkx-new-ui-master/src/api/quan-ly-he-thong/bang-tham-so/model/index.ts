import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IBangThamSo extends BaseModel {
  vungDuLieu?: String;
  maThamSo?: String;
  dienGiai?: String;
  status?: string;
  thamSoNguoiDung?: Number;
  id?: String;
  bangThamSoId?: Number;
  sapXep?: String;
  ghiChu?: String;
  page?: Number;
  pageSize?: Number;
  message?: String;
  tenUpdatedBy?: String;
  tenCreatedBy?: String;
}

export type ISearchParamBangThamSo = Pick<
  IBangThamSo,
  | 'page'
  | 'pageSize'
  | 'dienGiai'
  | 'vungDuLieu'
  | 'maThamSo'
  | 'status'
  | 'thamSoNguoiDung'
  | 'createdDate'
  | 'updatedDate'
  | 'createdBy'
  | 'updatedBy'
>;

export interface IUpdateParamsBangThamSo extends IBangThamSo {
  id: String;
}

export type IListBangThamSo = BasicFetchResult<IBangThamSo>;
