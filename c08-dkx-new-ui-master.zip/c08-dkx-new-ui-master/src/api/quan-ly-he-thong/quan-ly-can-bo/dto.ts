import { BaseDto } from '../../dto/baseDto';
import { BasicFetchResult } from '../../model/baseModel';

export interface IQuanLyCanBoDto extends BaseDto {
  status?: string;
  id?: string;
  page?: Number;
  pageSize?: Number;
  message?: string;
  userName?: string;
  realName?: string;
  chucVu?: string;
  ghiChu?: string;
  roleId?: string;

  email?: string;
  soHieu?: string;
  soDienThoai?: string;
  maDonViCsgt?: string;
  tenDonViCsgt?: string;
  maDiemDangKy?: string;
  tenDiemDangKy?: string;
  nhomQuyen?: string;

  loaiPTDK?: string;
  lanhDaoDuyet?: string;
  truongPhongDuyet?: string;
  yKienTruongPhong?: string;
  tenDiemDangKyId?: string;
  tenRoleId?: string;
  tenDonViCsgtId?: string;
  timKiemNhanh?: string;
}

export type IRequestSearchQuanLyCanBoDto = Pick<
  IQuanLyCanBoDto,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'realName'
  | 'userName'
  | 'email'
  | 'loaiPTDK'
  | 'nhomQuyen'
  | 'lanhDaoDuyet'
  | 'truongPhongDuyet'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'tenDiemDangKy'
  | 'maDonViCsgt'
>;
export interface IRequestUpdateQuanLyCanBoDto extends IQuanLyCanBoDto {
  id: string;
}

export type IListQuanLyCanBoDto = BasicFetchResult<IQuanLyCanBoDto>;
