import {
  IQuanLyCanBoDto,
  IListQuanLyCanBoDto,
  IRequestSearchQuanLyCanBoDto,
  IRequestUpdateQuanLyCanBoDto,
} from './dto';
import {
  ISearchParamQuanLyCanBo,
  IListQuanLyCanBo,
  IUpdateParamsQuanLyCanBo,
  IQuanLyCanBo,
} from './model';

export const transformQuanLyCanBoDtoToModel = (dto: IQuanLyCanBoDto): IQuanLyCanBo => {
  return {
    id: dto.id,
    status: dto.status,
    updatedDate: dto.updatedDate,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    createdBy: dto.createdBy,
    userName: dto.userName,
    realName: dto.realName,
    soDienThoai: dto.soDienThoai,
    soHieu: dto.soHieu,
    maDonViCsgt: dto.maDonViCsgt,
    tenDonViCsgt: dto.tenDonViCsgt,
    maDiemDangKy: dto.maDiemDangKy,
    tenDiemDangKy: dto.tenDiemDangKy,
    email: dto.email,
    nhomQuyen: dto.nhomQuyen,
    loaiPTDK: dto.loaiPTDK,
  };
};
export const transformListQuanLyCanBoDtoToModel = (list: IListQuanLyCanBoDto): IListQuanLyCanBo => {
  return {
    ...list,
    items: list.items.map<IQuanLyCanBo>((item) => transformQuanLyCanBoDtoToModel(item)),
  };
};
export const transformSearchParamsToDto = (dto: ISearchParamQuanLyCanBo) => {
  const paramSearch: IRequestSearchQuanLyCanBoDto = {
    status: dto.status,
    userName: dto.userName,
    realName: dto.realName,
    email: dto.email,
    tenDiemDangKy: dto.tenDiemDangKy,
    maDonViCsgt: dto.maDonViCsgt,
    loaiPTDK: dto.loaiPTDK,
    nhomQuyen: dto.nhomQuyen,
    page: dto.page,
    pageSize: dto.pageSize,
    createdBy: dto.createdBy,
    updatedBy: dto.updatedBy,
    createdDate: dto.createdDate,
    updatedDate: dto.updatedDate,
  };
  return paramSearch;
};

export const transformQuanLyCanBoModelToDto = (model: IQuanLyCanBo): IQuanLyCanBoDto => {
  return {
    id: model.id,
    status: model.status,
    updatedDate: model.updatedDate,
    updatedBy: model.updatedBy,
    createdDate: model.createdDate,
    createdBy: model.createdBy,
    soHieu: model.soHieu,
    email: model.email,
    chucVu: model.chucVu,
    ghiChu: model.ghiChu,
    roleId: model.roleId,
    loaiPTDK: model.loaiPTDK,
    lanhDaoDuyet: model.lanhDaoDuyet,
    truongPhongDuyet: model.truongPhongDuyet,
    yKienTruongPhong: model.yKienTruongPhong,
    tenDiemDangKyId: model.tenDiemDangKyId,
    tenDonViCsgtId: model.tenDonViCsgtId,
    tenRoleId: model.tenRoleId,
  };
};
export const transformRequestUpdateParamsToDto = (
  model: IUpdateParamsQuanLyCanBo,
): IRequestUpdateQuanLyCanBoDto => {
  const dtoTransform: IRequestUpdateQuanLyCanBoDto = {
    ...transformQuanLyCanBoModelToDto(model),
    id: model.id,
  };
  return dtoTransform;
};
