import { BaseModel, BasicFetchResult } from '/@/api/model/baseModel';

export interface IQuanLyCanBo extends BaseModel {
  status?: string;
  id?: string;
  page?: Number;
  pageSize?: Number;
  message?: string;
  userName?: string;
  realName?: string;
  chucVu?: string;
  ghiChu?: string;
  roleId?: string;

  email?: string;
  soHieu?: string;
  soDienThoai?: string;
  maDonViCsgt?: string;
  tenDonViCsgt?: string;
  maDiemDangKy?: string;
  tenDiemDangKy?: string;
  nhomQuyen?: string;

  loaiPTDK?: string;
  lanhDaoDuyet?: string;
  truongPhongDuyet?: string;
  yKienTruongPhong?: string;
  tenDiemDangKyId?: string;
  tenRoleId?: string;
  tenDonViCsgtId?: string;
  timKiemNhanh?: string;
}

export type ISearchParamQuanLyCanBo = Pick<
  IQuanLyCanBo,
  | 'status'
  | 'page'
  | 'pageSize'
  | 'realName'
  | 'userName'
  | 'email'
  | 'loaiPTDK'
  | 'nhomQuyen'
  | 'lanhDaoDuyet'
  | 'truongPhongDuyet'
  | 'createdBy'
  | 'updatedBy'
  | 'createdDate'
  | 'updatedDate'
  | 'tenDiemDangKy'
  | 'maDonViCsgt'
>;
export interface IUpdateParamsQuanLyCanBo extends IQuanLyCanBo {
  id: string;
}

export type IListQuanLyCanBo = BasicFetchResult<IQuanLyCanBo>;

export interface CanBoInfo {
  userName: string;
  fullName: string;
  ngaySinh: string;
  email: string;
  maDonVi: string;
  soDienThoai: string;
  maDiemDangKy: string;
  tenDiemDangKy: string;
  capHanhChinhDdk: string;
}
