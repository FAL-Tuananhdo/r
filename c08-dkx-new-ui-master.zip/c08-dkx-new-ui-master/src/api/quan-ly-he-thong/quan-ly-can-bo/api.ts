import { localHttp } from '/@/utils/http/axios';

import { IListQuanLyCanBoDto } from './dto';
import { ISearchParamQuanLyCanBo, IListQuanLyCanBo, IQuanLyCanBo, CanBoInfo } from './model';
import { transformListQuanLyCanBoDtoToModel, transformSearchParamsToDto } from './helper';
enum Api {
  main = '/v1/quan-ly-can-bo',
  getList = '/v1/quan-ly-can-bo/getList',
  exportExcel = '/v1/quan-ly-can-bo/export/excel',
  getInfo = '/v1/quan-ly-can-bo/getInfo',
}

export const getListQuanLyCanBo = async (
  params: ISearchParamQuanLyCanBo,
): Promise<IListQuanLyCanBo> => {
  const res = await localHttp.get<IListQuanLyCanBoDto>({
    url: Api.main,
    params: transformSearchParamsToDto(params),
  });

  dataExcel = res.items;
  return transformListQuanLyCanBoDtoToModel(res);
};

export const exportExcelQlyCanBo = async (params: ISearchParamQuanLyCanBo) => {
  await localHttp.downloadFileExcel({
    url: Api.exportExcel,
    params: transformSearchParamsToDto(params),
  });
};

export let dataExcel: any[];

export const getDataExcel = () => {
  return dataExcel;
};

export const getListCanBoSelect = async (params?: IQuanLyCanBo) => {
  const res = await localHttp.get<IQuanLyCanBo[]>({ url: Api.getList, params: params });
  return res;
};

export const getCanBoInfo = async (userName: string) => {
  const res = await localHttp.get<CanBoInfo>({ url: Api.getInfo, params: { userName: userName } });
  return res;
};
