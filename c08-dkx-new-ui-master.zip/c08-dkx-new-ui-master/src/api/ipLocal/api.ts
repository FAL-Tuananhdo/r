// export default function getApiLocal() {
//   return new Promise((resolve, reject) => {
//     fetch('https://api.ipify.org?format=json')
//       .then((response) => resolve(response.json()))
//       .catch((error) => reject(error));
//   });
// }
//api.ipdata.co
export default function getApiLocal() {
  return new Promise((resolve, reject) => {
    fetch('https://api.ipify.org?format=json')
      .then((response) => resolve(response.json()))
      .catch((error) => reject(error));
  });
}
