import { MockMethod } from 'vite-plugin-mock';

import { resultPageSuccess } from '../_util';

const ListDiaDanhHanhChinh = [
  {
    id: 1,
    capHanhChinh: 1,
    tenDiaDanh: 'Hà Nội',
    maBca: '01',
    maTinhThanh: '01',
    maQuanHuyen: '01',
    maPhuongXa: '01',
    status: true,
    updateDate: new Date(),
    tienTo: 'H01',
    tenHieu: 'HaNoi',
    tenTiengAnh:
      'Ha NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa Ha NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa NoiHa Noi',
    ghiChu: 'Hà Nội không vội được đâu',
    updateBy: 'phucnx',
    children: [
      {
        id: 2,
        capHanhChinh: 2,
        tenDiaDanh: 'Cầu Giấy',
        maBca: '01',
        maTinhThanh: '01',
        maQuanHuyen: '001',
        maPhuongXa: '01',
        status: true,
        updateDate: new Date(),
        updateBy: 'phucnx',
        children: [
          {
            id: 3,
            capHanhChinh: 3,
            tenDiaDanh: 'Dịch Vọng Hậu',
            maBca: '01',
            maTinhThanh: '01',
            maQuanHuyen: '001',
            maPhuongXa: '0001',
            status: true,
            updateDate: new Date(),
            updateBy: 'phucnx',
          },
          {
            id: 4,
            capHanhChinh: 3,
            tenDiaDanh: 'Dịch Vọng',
            maBca: '01',
            maTinhThanh: '01',
            maQuanHuyen: '001',
            maPhuongXa: '0002',
            status: true,
            updateDate: new Date(),
            updateBy: 'phucnx',
          },
        ],
      },
      {
        id: 5,
        capHanhChinh: 2,
        tenDiaDanh: 'Hoàng Mai',
        maBca: '01',
        maTinhThanh: '01',
        maQuanHuyen: '002',
        status: true,
        updateDate: new Date(),
        updateBy: 'phucnx',
        children: [
          {
            id: 6,
            capHanhChinh: 3,
            tenDiaDanh: 'Hoàng Liệt',
            maBca: '01',
            maTinhThanh: '01',
            maQuanHuyen: '002',
            maPhuongXa: '0003',
            status: true,
            updateDate: new Date(),
            updateBy: 'phucnx',
          },
          {
            id: 7,
            capHanhChinh: 3,
            tenDiaDanh: 'Yên Sở',
            maBca: '01',
            maTinhThanh: '01',
            maQuanHuyen: '002',
            maPhuongXa: '0004',
            status: true,
            updateDate: new Date(),
            updateBy: 'phucnx',
          },
        ],
      },
    ],
  },
  {
    id: 8,
    capHanhChinh: 1,
    tenDiaDanh: 'Nha Trang',
    maBca: '01',
    maTinhThanh: '02',
    status: true,
    updateDate: new Date(),
    updateBy: 'phucnx',
    children: [
      {
        id: 9,
        capHanhChinh: 2,
        tenDiaDanh: 'Thành phố Nha Trang',
        maBca: '01',
        maTinhThanh: '02',
        maQuanHuyen: '003',
        status: 0,
        updateDate: new Date(),
        updateBy: 'phucnx',
        children: [
          {
            id: 10,
            capHanhChinh: 3,
            tenDiaDanh: 'Ngọc Hiệp',
            maBca: '01',
            maTinhThanh: '02',
            maQuanHuyen: '003',
            maPhuongXa: '0005',
            status: 0,
            updateDate: new Date(),
            updateBy: 'phucnx',
          },
          {
            id: 11,
            capHanhChinh: 3,
            tenDiaDanh: 'Phước Tân',
            maBca: '01',
            maTinhThanh: '02',
            maQuanHuyen: '003',
            maPhuongXa: '0006',
            status: 0,
            updateDate: new Date(),
            updateBy: 'phucnx',
          },
        ],
      },
    ],
  },
];

export default [
  {
    url: '/basic-api/ddhc',
    timeout: 1000,
    method: 'get',
    response: ({ query }) => {
      const { page = 1, pageSize = 20 } = query;
      return resultPageSuccess(page, pageSize, ListDiaDanhHanhChinh).result;
    },
  },
  {
    url: '/basic-api/ddhc/:id',
    timeout: 500,
    method: 'put',
    response: () => 'success',
  },
  {
    url: '/basic-api/ddhc',
    timeout: 500,
    method: 'post',
    response: () => 'success',
  },
  {
    url: '/basic-api/ddhc/:id',
    method: 'get',
    timeout: 500,
    response: () => {
      return ListDiaDanhHanhChinh[0];
    },
  },
  {
    url: '/basic-api/ddhc/:id',
    method: 'delete',
    timeout: 500,
    response: () => 'success',
  },
] as MockMethod[];

// export default function createApi({ url, method }) {
//   const request = (payload = null, paths = null, queries = null) => {
//     console.log(payload, paths, queries, 'requestttt');
//     const config = {};
//     config.url = url;
//     config.method = method;

//     if (paths) {
//       config.url = `${config.url}/${paths}`;
//     }
//     if (queries) {
//       console.log(config.url, 'url goc');
//       console.log(`${config.url}`, 'urlllllll templetstring');
//       config.url = Object.keys(queries).reduce(
//         (prev, curr) => prev + `${curr}=${queries[curr]}`,
//         `${config.url}?`
//       );
//     }

//     if (payload) {
//       config.data = payload;
//     }

//     return Axios(config)
//       .then((res) => res.data)
//       .catch((res) => res.error);
//   };

//   return request;
// }
