import { resultPageSuccess } from '../_util';
import { MockMethod } from 'vite-plugin-mock';

const listNoiCapGiayTo = [
  {
    id: 1,
    loai_tang_vat: "Giấy phép kinh doanh",
    noi_cap_giay_to: "Tổng công ty bảo hiểm di động PVI",
    dia_chi: "Số 8 Láng hạ",
    quan_huyen: "Hà Nội",
    district: "Ba Đình",
    phone: "0898560570",
    trang_thai: false,
    createdBy: "hiepnn",
    createdDate: "11-5-2020",
  },
  {
    id: 2,
    loai_tang_vat: "Giấy phép kinh doanh",
    noi_cap_giay_to: "Tổng công ty bảo hiểm di động PVI",
    dia_chi: "Số 8 Láng hạ",
    quan_huyen: "Hà Nội",
    district: "Ba Đình",
    phone: "0898560570",
    trang_thai: true,
    createdBy: "hiepnn",
    createdDate: "11-5-2020",
  },
  {
    id: 3,
    loai_tang_vat: "Giấy phép kinh doanh",
    noi_cap_giay_to: "Tổng công ty bảo hiểm di động PVI",
    dia_chi: "Số 8 Láng hạ",
    quan_huyen: "Hà Nội",
    district: "Ba Đình",
    phone: "0898560570",
    trang_thai: false,
    createdBy: "hiepnn",
    createdDate: "11-5-2020",
  },
];


export default [
  {
    url: '/basic-api/noi-cap-giay-to',
    timeout: 1000,
    method: 'get',
    response: ({ query }) => {
      const { page = 1, pageSize = 20 } = query;
      return resultPageSuccess(page, pageSize, listNoiCapGiayTo).result;
    },
  }
] as MockMethod[];
